/**
 * @author rstxua
 * @version 1.1.0
 * @since 1.0.0
 * 
 * Класс, представляющий букву классом с инкапсулированым полем. 
 */
public class Letter {
	private char letter;
	
	public char getLetter(){
		return letter;
	}
	public void setLetter(char letter){
		this.letter = letter;
	}
	

	public Letter(char charAt) {
		setLetter(charAt);
	}
}
