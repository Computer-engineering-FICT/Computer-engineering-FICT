/**
 * @author rstxua
 * @version 1.1.0
 * @since 1.0.0
 * 
 * Класс, представляющий текст массивом пар слово-пунктуация. 
 */
public class Text {
	private Pair[] text;
	
	public void setText(StringBuilder text){
		int countOfWords = 0;
		for (int i = 0; i < text.length(); i++)
			if (text.charAt(i) == ' ')
				countOfWords++;
		Pair[] buildedText = new Pair[countOfWords];
		
		int currentWord = 0;
		int pairStart = 0;
		int pairEnd = 0;
		for (int i = 0; i < text.length(); i++) {
			if (text.charAt(i) == ' '){
				pairEnd = i + 1;
				buildedText[currentWord] = new Pair(new StringBuilder(text.substring(pairStart, pairEnd)));
				if (pairEnd < text.length())
					pairStart = pairEnd;
				i++;
				currentWord++;
			}
		}
		this.text = buildedText;
	}
	public Pair[] getText(){
		return text;
	}
	public void output(){
		for (int i = 0; i < text.length; i++) {
			text[i].output();
		} 
	}
	public Text(StringBuilder text){
		setText(text);
	}

	@Override
	public String toString(){
		StringBuilder result = new StringBuilder("");
		for (int i = 0; i < text.length; i++){
			result.append(text[i].getWordOfPair().toString());
			result.append(text[i].getPunctuationOfPair().getPunctuation());
		}
		return result.toString();
	}
}
