/**
 * @author rstxua
 * @version 1.1.0
 * @since 1.0.0
 * 
 * Класс, представляющий пару слово-пунктуация. 
 */
public class Pair {
	private Word word;
	private Punctuation punctuation;
	public char[] letters = 
		{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 
		 'r', 's', 't', 'u', 'v', 'w', 'y', 'x', 'z', 
		 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 
		 'R', 'S', 'T', 'U', 'V', 'W', 'Y', 'X', 'Z'
		};
	
	public void setPair(StringBuilder pair){
		for (int i = 0; i < pair.length(); i++) {
			boolean check = false;
			int punctuationStartPoint = 0;
			for (int j = 0; j < letters.length; j++){
				if (pair.charAt(i) == letters[j])
					check = true;
			}
			if (check == false){
				punctuationStartPoint = i;
				this.word = new Word(new StringBuilder(pair.substring(0, punctuationStartPoint)));
				this.punctuation = new Punctuation(new StringBuilder(pair.substring(punctuationStartPoint, pair.length())));
				break;
			}
		}
	}
	public void output(){
		word.output();
		punctuation.output();
	}
	public Word getWordOfPair(){
		return word;
	}
	public Punctuation getPunctuationOfPair(){
		return punctuation;
	}
	
	public Pair(StringBuilder text){
		setPair(text);
	}
	public Pair(){
		this.word = null;
		this.punctuation = null;
	}
}
