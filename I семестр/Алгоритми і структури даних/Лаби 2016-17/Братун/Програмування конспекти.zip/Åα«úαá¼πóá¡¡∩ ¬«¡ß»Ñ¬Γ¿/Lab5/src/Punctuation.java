/**
 * @author rstxua
 * @version 1.1.0
 * @since 1.0.0
 * 
 * Класс, представляющий пунктуацию. 
 */
public class Punctuation {
	private StringBuilder punctuation;
	
	public void setPunctuation(StringBuilder punctuation){
		this.punctuation = punctuation;
	}
	public StringBuilder getPunctuation(){
		return punctuation;
	}
	
	public void output(){
		System.out.println(getPunctuation());
	}
	public Punctuation(StringBuilder punctuation){
		this.punctuation = punctuation;
	}
}
