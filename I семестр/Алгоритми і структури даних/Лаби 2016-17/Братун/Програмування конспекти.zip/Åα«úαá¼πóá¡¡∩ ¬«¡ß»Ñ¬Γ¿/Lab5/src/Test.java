public class Test {
	public static void main(String[] args) {
		StringBuilder text = new StringBuilder("A little    bit              test.");
		System.out.println("Before: ");
		System.out.println("  " + text);
		text = Do.format(text);
		Text test = new Text(text);
		System.out.println("After: ");
		System.out.println("  " + test.toString());
		System.out.println();
		Do.seekForTheLongestWord(test);
		
	}
}
