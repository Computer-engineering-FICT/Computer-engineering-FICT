/**
 * @author rstxua
 * @version 1.1.0
 * @since 1.0.0
 * 
 * Класс, делающий левую работу. Умеет форматироать текст (удалять лишние пробелы) и искать слово наибольшей длинны. 
 */
public class Do {
	public static StringBuilder format(StringBuilder text){
		StringBuilder formatedText = new StringBuilder();
		formatedText = text;
		
		for (int i = 0; i < formatedText.length() - 1; i++){
			if ((formatedText.charAt(i) == ' ') && (formatedText.charAt(i + 1) == ' ')){
				formatedText.deleteCharAt(i + 1);
				i--;
			}
		}
		
		if (formatedText.charAt(formatedText.length() - 1) != ' ') {
			formatedText.append(' ');
		}
		return formatedText;
	}
	
	public static Word seekForTheLongestWord(Text text){
		Word result = new Word();
		int countOfLetters = 0;
		int position = 0;
		
		for (int i = 0; i < text.getText().length; i++){
			if (text.getText()[i].getWordOfPair().getWord().length >= countOfLetters){
				countOfLetters = text.getText()[i].getWordOfPair().getWord().length;
				position = i;
			}
		}
		System.out.println("The longest word is '" + text.getText()[position].getWordOfPair().toString() + "' on " + (position + 1) + " position.");
		result = text.getText()[position].getWordOfPair();
		return result;
	}
}
