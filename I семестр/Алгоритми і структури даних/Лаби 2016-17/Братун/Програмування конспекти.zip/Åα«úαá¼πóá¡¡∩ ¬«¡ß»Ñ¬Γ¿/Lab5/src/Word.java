/**
 * @author rstxua
 * @version 1.1.0
 * @since 1.0.0
 * 
 * Класс, представляющий слово классом, содержащим массив букв. 
 */
public class Word {
	private Letter[] word;
	
	public Letter[] getWord(){
		return word;
	}
	public void setWord(Letter[] word){
		this.word = word;
	}
	
	public void output(){
		for (int i = 0; i < word.length; i++){
			System.out.print(word[i].getLetter());
		}
		System.out.println();
	}
	
	@Override
	public String toString(){
		StringBuilder result = new StringBuilder("");
		for (int i = 0; i < word.length; i++){
			result.append(word[i].getLetter());
		}
		return result.toString();
	}
	
	public Word(StringBuilder word){
		Letter[] buildedWord = new Letter[word.length()];
		for (int i = 0; i < word.length(); i++){
			buildedWord[i] = new Letter(word.charAt(i));
		}
		this.word = buildedWord;
	}
	public Word(){
		this.word = null;
	}
}
