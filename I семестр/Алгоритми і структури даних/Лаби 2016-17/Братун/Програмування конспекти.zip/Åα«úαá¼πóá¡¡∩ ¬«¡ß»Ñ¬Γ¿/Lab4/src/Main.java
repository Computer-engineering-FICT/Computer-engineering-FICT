/**
 * @author rstxua
 * @version 0.9.2
 * @since 1.0.0
 * 
 * Главный класс.
 */
public class Main {
	/**
	 * Главный метод.
	 */
	public static void main(String[] args) {
		Car[] fleet = new Car[5];
		fleet[0] = new Car();
		fleet[1] = new Car("Lada", "Priora", 90, "Red", 110);
		fleet[2] = new Car("Chevrolet", "Camaro", 190, "Light blue", 180);
		fleet[3] = new Car("Shelby", "GT500", 800, "White", 519);
		fleet[4] = new Car("Mitsubishi", "Eclipse", 250, "Black", 230);
		
		System.out.println("Unsorted array:");
		System.out.println();
		Output.outputNicely(fleet);
		Sort.sortByPower(fleet, "Down");
		System.out.println();
		System.out.println("Sorted array:");
		System.out.println();
		Output.outputNicely(fleet);
	}
}
