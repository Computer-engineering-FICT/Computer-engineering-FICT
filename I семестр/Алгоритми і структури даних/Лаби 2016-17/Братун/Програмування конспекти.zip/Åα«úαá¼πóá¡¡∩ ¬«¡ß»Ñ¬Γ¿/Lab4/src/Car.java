/**
 * @author rstxua
 * @version 0.9.2
 * @since 1.0.0
 * 
 * Класс, абстрагирующий автомобиль до 5 полей. Содержит поля и два конструктора.
 */
public class Car {	
	/**
	 * Поле, описывающее марку автомобиля.
	 */
	String mark;
	/**
	 * Поле, описывающее модель автомобиля.
	 */
	String model;
	/**
	 * Поле, описывающее мощность автомобиля.
	 */
	int power;
	/**
	 * Поле, описывающее цвет автомобиля.
	 */
	String color;
	/**
	 * Поле, описывающее максимальную скорость автомобиля.
	 */
	int maxSpeed;
	
	/**
	 * Стандартный конструктор, создающий додж неон с мощностью 110 л.с., темно-зеленого цвета и макс. скоростью в 170 км\ч.
	 */
	public Car(){
		mark = "Dodge";
		model = "Neon";
		power = 110;
		color = "Dark green";
		maxSpeed = 170;
	}
	
	/**
	 * Конструктор, создающий специфический аавтомобиль и принимающий 5 полей, специфицирующих оный.
	 * 
	 * @param mark - марка автомобиля.
	 * @param model - модель автомобиля.
	 * @param power - мощность автомобиля.
	 * @param color - цвет автомобиля.
	 * @param max_speed - максимальная скорость
	 */
	public Car(String mark, String model, int power, String color, int maxSpeed){
		this.mark = mark;
		this.model = model;
		this.power = power;
		this.color = color;
		this.maxSpeed = maxSpeed;
	}
}
