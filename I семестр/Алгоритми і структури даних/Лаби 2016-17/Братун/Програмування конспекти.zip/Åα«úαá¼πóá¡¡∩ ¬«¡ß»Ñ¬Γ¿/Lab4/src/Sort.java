/**
  @author rstxua
 * @version 0.9.8
 * @since 1.0.0
 * 
 * Класс, используемый для сортировки массива объектов стандартными библиотечными методами.
 */
public class Sort{
	/**
	 * 
	 * @param fleet - массив, содержащий автомобили.
	 * @param direction - направление. Up - по возрастанию, Down - по убыванию.
	 * @return - отсортированый масив при корректно заданых значениях.
	 */
	public static Car[] sortByPower(Car[] fleet, String direction){
		if ((direction != "Up") && (direction != "Down")){
			//Возвращаем неотсортированный масив.
			return fleet;
		} else {
			if (direction == "Up"){
				Car buffer = null;
				for (int c = 0; c < (fleet.length - 1); c++) {
				      for (int d = 0; d < fleet.length - c - 1; d++) {
				    	  if (fleet[d].power < fleet[d + 1].power)
				          	  {
				    		  	buffer = fleet[d];
				    		  	fleet[d] = fleet[d+1];
				    		  	fleet[d+1] = buffer;
				          	  }
				      }
				}
			    return fleet;
			} else {
				Car buffer = null;
				for (int c = 0; c < (fleet.length - 1); c++) {
				      for (int d = 0; d < fleet.length - c - 1; d++) {
				    	  if (fleet[d].power > fleet[d + 1].power)
				          	  {
				    		  	buffer = fleet[d];
				    		  	fleet[d] = fleet[d+1];
				    		  	fleet[d+1] = buffer;
				          	  }
				      }
				}
			    return fleet;
			}
		}
	}
}
