/**
 * @author rstxua
 * @version 0.9.1
 * @since 1.0.0
 * 
 * Класс для вывода массива.
 */
public class Output {
	/**
	 * Метод для няшного вывода массива автомобилей.
	 * 
	 * @param fleet - Массив автомобилей.
	 */
	public static void outputNicely(Car[] fleet){
		for (int i = 0; i < fleet.length; i++){
			System.out.println("Car #" + i);
			System.out.println("  Mark: " + fleet[i].mark);
			System.out.println("  Model: " + fleet[i].model);
			System.out.println("  Power: " + fleet[i].power);
			System.out.println("  Color: " + fleet[i].color);
			System.out.println("  Max speed: " + fleet[i].maxSpeed);
		}
	}
}
