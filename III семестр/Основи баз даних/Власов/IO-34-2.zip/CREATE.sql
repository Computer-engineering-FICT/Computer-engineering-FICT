SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

DROP SCHEMA IF EXISTS `IO-34_2Team` ;
CREATE SCHEMA IF NOT EXISTS `IO-34_2Team` DEFAULT CHARACTER SET utf8 ;
USE `IO-34_2Team` ;

-- -----------------------------------------------------
-- Table `IO-34_2Team`.`User`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `IO-34_2Team`.`User` ;

CREATE  TABLE IF NOT EXISTS `IO-34_2Team`.`User` (
  `user_id` INT NOT NULL AUTO_INCREMENT ,
  `user_name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`user_id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IO-34_2Team`.`Mail`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `IO-34_2Team`.`Mail` ;

CREATE  TABLE IF NOT EXISTS `IO-34_2Team`.`Mail` (
  `mail_id` INT NOT NULL AUTO_INCREMENT ,
  `mail_read` TINYINT(1) NULL DEFAULT 0 ,
  `mail_type` VARCHAR(45) NOT NULL ,
  `User_user_id` INT NOT NULL ,
  PRIMARY KEY (`mail_id`, `User_user_id`) ,
  INDEX `fk_Mail_User1` (`User_user_id` ASC) ,
  CONSTRAINT `fk_Mail_User1`
    FOREIGN KEY (`User_user_id` )
    REFERENCES `IO-34_2Team`.`User` (`user_id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `IO-34_2Team`.`Receiver`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `IO-34_2Team`.`Receiver` ;

CREATE  TABLE IF NOT EXISTS `IO-34_2Team`.`Receiver` (
  `receiver_id` INT NOT NULL ,
  `Mail_mail_id` INT NOT NULL ,
  `User_user_id` INT NOT NULL ,
  PRIMARY KEY (`Mail_mail_id`, `User_user_id`) ,
  INDEX `fk_Receiver_User1` (`User_user_id` ASC) ,
  CONSTRAINT `fk_Receiver_Mail`
    FOREIGN KEY (`Mail_mail_id` )
    REFERENCES `IO-34_2Team`.`Mail` (`mail_id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Receiver_User1`
    FOREIGN KEY (`User_user_id` )
    REFERENCES `IO-34_2Team`.`User` (`user_id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `IO-34_2Team`.`User`
-- -----------------------------------------------------
START TRANSACTION;
USE `IO-34_2Team`;
INSERT INTO `IO-34_2Team`.`User` (`user_id`, `user_name`) VALUES (1, 'First User');
INSERT INTO `IO-34_2Team`.`User` (`user_id`, `user_name`) VALUES (2, 'Second User');
INSERT INTO `IO-34_2Team`.`User` (`user_id`, `user_name`) VALUES (3, 'Third User');

COMMIT;

-- -----------------------------------------------------
-- Data for table `IO-34_2Team`.`Mail`
-- -----------------------------------------------------
START TRANSACTION;
USE `IO-34_2Team`;
INSERT INTO `IO-34_2Team`.`Mail` (`mail_id`, `mail_read`, `mail_type`, `User_user_id`) VALUES (1, 0, 'Inbox', 1);
INSERT INTO `IO-34_2Team`.`Mail` (`mail_id`, `mail_read`, `mail_type`, `User_user_id`) VALUES (2, 1, 'Inbox', 1);
INSERT INTO `IO-34_2Team`.`Mail` (`mail_id`, `mail_read`, `mail_type`, `User_user_id`) VALUES (3, 0, 'Spam', 1);
INSERT INTO `IO-34_2Team`.`Mail` (`mail_id`, `mail_read`, `mail_type`, `User_user_id`) VALUES (4, 1, 'Spam', 2);
INSERT INTO `IO-34_2Team`.`Mail` (`mail_id`, `mail_read`, `mail_type`, `User_user_id`) VALUES (5, 1, 'Drafts', 3);

COMMIT;

-- -----------------------------------------------------
-- Data for table `IO-34_2Team`.`Receiver`
-- -----------------------------------------------------
START TRANSACTION;
USE `IO-34_2Team`;
INSERT INTO `IO-34_2Team`.`Receiver` (`receiver_id`, `Mail_mail_id`, `User_user_id`) VALUES (1, 1, 1);
INSERT INTO `IO-34_2Team`.`Receiver` (`receiver_id`, `Mail_mail_id`, `User_user_id`) VALUES (1, 2, 1);
INSERT INTO `IO-34_2Team`.`Receiver` (`receiver_id`, `Mail_mail_id`, `User_user_id`) VALUES (2, 3, 1);

COMMIT;
