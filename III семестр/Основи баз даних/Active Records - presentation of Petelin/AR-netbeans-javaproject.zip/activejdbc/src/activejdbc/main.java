/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package activejdbc;

import java.util.List;
import org.javalite.activejdbc.Base;

/**
 *
 * @author administrator
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Base.open("com.mysql.jdbc.Driver", "jdbc:mysql://localhost/testjdbc", "root", "");
        /*
         * CREATE TABLE people (
         *  pid  int(11) NOT NULL auto_increment PRIMARY KEY,
         *  name VARCHAR(56) NOT NULL,
         *  last_name VARCHAR(56),
         *  dob DATE,
         *  graduation_date DATE,
         *  created_at DATETIME,
           updated_at DATETIME
         );
         
        /* SELECT */
        List<Person> people1 = Person.where("name = ?", "John");
        Person aJohn = people1.get(0);
        String johnsLastName = aJohn.getString("last_name");
        
        /* SELECT lvl2 */
        List<Person> people2 = Person.where("name = ?", "John")
        .offset(21)
        .limit(10)
        .orderBy("created_at desc");
        
        /* CREATE */
        
        Person p = new Person();
        p.set("name", "Marilyn");
        p.set("last_name", "Monroe");
        p.set("dob", "1935-12-06");
        p.saveIt();
        
        /* UPDATE */
        
        List<Person> people3 = Person.where("name = ?", "John");
        people3.get(0).set("last_name", "Steinbeck").saveIt();
        
        /* DELETE */
        
        List<Person> people4 = Person.where("name = ?", "John");
        people4.get(0).delete();
        
        /* EAT & SLEEP & RAVE & REPEAT */
        /* SELECT & UPDATE & CREATE & DELETE */
        
    }
    
}
