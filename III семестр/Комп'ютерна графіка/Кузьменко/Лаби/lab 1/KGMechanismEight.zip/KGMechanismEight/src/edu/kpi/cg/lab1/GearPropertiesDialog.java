package edu.kpi.cg.lab1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class GearPropertiesDialog extends JDialog {

	private JComboBox<String> elements;
	private JColorChooser cc;
	private JSpinner rotation;
	private JCheckBox textureSwitch;
	private JSpinner cogCount;
	private JButton applyButton;
	private JButton cancelButton;
	private JButton okButton;

	private MechanismModel model;
	private Gear gear, source;

	GearPropertiesDialog(JFrame parent, MechanismModel model) {
		super(parent);
		setTitle("Gear Properties");
		setModal(true);
		setLocationRelativeTo(parent);
		setResizable(false);

		this.model = model;
		gear = model.getSelectedGear();
		if (gear != null) {
			source = new Gear();
			source.assign(gear);

			setLayout(null);
			setSize(500, 585);
			JLabel label = new JLabel("Color of");
			label.setBorder(null);
			label.setBounds(5, 5, getWidth() - 5, 25);
			add(label);
			elements = new JComboBox<String>();
			String elementNames[] = { "Wheel", "Axle", "Texture", "Contour" };
			ComboBoxModel<String> listModel = new DefaultComboBoxModel<String>(
					elementNames);
			elements.setModel(listModel);
			elements.setSelectedIndex(0);
			elements.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					switch (elements.getSelectedIndex()) {
					case 0: {
						cc.setColor(gear.getWheelColor());
						break;
					}
					case 1: {
						cc.setColor(gear.getAxleColor());
						break;
					}
					case 2: {
						cc.setColor(gear.getTextureColor());
						break;
					}
					case 3: {
						cc.setColor(gear.getLineColor());
						break;
					}
					}
				}
			});
			elements.setBounds(5, 31, getWidth() - 5, 25);
			add(elements);

			cc = new JColorChooser(gear.getWheelColor());
			cc.getSelectionModel().addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					switch (elements.getSelectedIndex()) {
					case 0: {
						gear.setWheelColor(cc.getColor());
						break;
					}
					case 1: {
						gear.setAxleColor(cc.getColor());
						break;
					}
					case 2: {
						gear.setTextureColor(cc.getColor());
						break;
					}
					case 3: {
						gear.setLineColor(cc.getColor());
						break;
					}
					}
				}
			});
			cc.setBounds(5, 57, getWidth() - 5, 300);
			add(cc);

			label = new JLabel("Rotation Angle:");
			label.setBounds(5, 357, getWidth() - 5, 25);
			add(label);

			rotation = new JSpinner();
			SpinnerModel degreesModel = new SpinnerNumberModel(
					gear.getRotation() * 180 / Math.PI, -360, 360, 1);
			rotation.setModel(degreesModel);
			JFormattedTextField tfr = ((JSpinner.DefaultEditor) rotation
					.getEditor()).getTextField();
			tfr.setEditable(false);
			rotation.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					gear.setRotation(((Number)rotation.getValue()).doubleValue() * Math.PI
							/ 180);
				}
			});
			rotation.setBounds(5, 383, getWidth() - 5, 25);
			add(rotation);
			
			label = new JLabel("Gear Cogs:");
			label.setBounds(5, 414, getWidth() - 5, 25);
			add(label);
			cogCount = new JSpinner();
			SpinnerModel cogsModel = new SpinnerNumberModel(
					gear.getCogCount(), 0, 360, 1);
			cogCount.setModel(cogsModel);
			JFormattedTextField tfc = ((JSpinner.DefaultEditor) cogCount
					.getEditor()).getTextField();
			tfc.setEditable(false);
			cogCount.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					gear.setCogCount(((Number)cogCount.getValue()).intValue());
				}
			});
			cogCount.setEnabled(!gear.isTextureEnabled());
			cogCount.setBounds(5, 435, getWidth() - 5, 25);
			add(cogCount); 
			
			textureSwitch = new JCheckBox();
			textureSwitch.setText("Enable texture");
			textureSwitch.setSelected(gear.isTextureEnabled());
			textureSwitch.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					cogCount.setEnabled(!textureSwitch.isSelected());
					gear.setTextureEnabled(textureSwitch.isSelected());
				}
			});
			textureSwitch.setBounds(5, 466, getWidth() - 5, 25);
			add(textureSwitch);

			applyButton = new JButton("Apply");
			applyButton.setIcon(new ImageIcon("res/icons/apply.png"));
			applyButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					GearPropertiesDialog.this.model.changeGear(gear);
				}
			});
			applyButton.setBounds(getWidth() - 145, 510, 120, 30);
			add(applyButton);
			
			okButton = new JButton("OK");
			okButton.setIcon(new ImageIcon("res/icons/ok.png"));
			okButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					GearPropertiesDialog.this.model.changeGear(gear);
					GearPropertiesDialog.this.dispose();
				}
			});
			okButton.setBounds(25, 510, 120, 30);
			add(okButton);
			
			cancelButton = new JButton("Cancel");
			cancelButton.setIcon(new ImageIcon("res/icons/cancel.png"));
			cancelButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					gear.assign(source);
					GearPropertiesDialog.this.model.changeGear(gear);
					GearPropertiesDialog.this.dispose();
				}
			});
			cancelButton.setBounds(165, 510, 120, 30);
			add(cancelButton);
		} else {
			add(new JLabel("No gear selected"));
		}
	}

}
