package edu.kpi.cg.lab1;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MechanismViewController extends JPanel 
	implements MouseListener, MouseMotionListener, MouseWheelListener,
			   ComponentListener, ActionListener {
	
	private static int GEAR_MIN_SIZE = 50;
	private static double SCALE_PER_REVOLUTION = 0.05;
	
	private MechanismModel model;
	
	private JPanel toolbar;
	private JPanel workbench;
	private JButton propertiesButton;
	private JButton removeButton;
	private JButton addButton;
	
	private boolean adding;
	private int xG, yG, xGS, yGS, radiusG;
	
	public MechanismViewController(MechanismModel model) {
		this.model = model;
		this.setLayout(new BorderLayout());
		
		toolbar = new JPanel();
		toolbar.setLayout(new FlowLayout());
		toolbar.setPreferredSize(new Dimension(60, 40));
		
		propertiesButton = new JButton();
		propertiesButton.setIcon(new ImageIcon("res/icons/properties.png"));
		propertiesButton.setSize(32, 32);
		propertiesButton.setEnabled(false);
		propertiesButton.addActionListener(this);
		
		addButton = new JButton();
		addButton.setIcon(new ImageIcon("res/icons/add.png"));
		addButton.setSelectedIcon(new ImageIcon("res/icons/add-selected.png"));
		addButton.setSize(32, 32);
		addButton.setEnabled(true);
		addButton.addActionListener(this);
		
		removeButton = new JButton();
		removeButton.setIcon(new ImageIcon("res/icons/remove.png"));
		removeButton.setSize(32, 32);
		removeButton.setEnabled(false);
		removeButton.addActionListener(this);
		
		toolbar.add(addButton);
		toolbar.add(removeButton);
		toolbar.add(propertiesButton);
		this.add(toolbar, BorderLayout.NORTH);
		
		workbench = new JPanel();
		workbench.setLayout(null);
		workbench.addMouseListener(this);
		workbench.addMouseMotionListener(this);
		workbench.addMouseWheelListener(this);
		this.add(workbench, BorderLayout.CENTER);
		this.componentResized(new ComponentEvent(this, ComponentEvent.COMPONENT_RESIZED));
		adding = false;
	}
	
	public void paint(Graphics g) {
		super.paint(g);
	}

	public void gearAdded(Gear gear) {
		workbench.add(gear);
		repaint();
	}
	
	public void gearRemoved(Gear gear) {
		workbench.remove(gear);
		repaint();
	}
	
	public void gearChanged(Gear gear) {
		repaint();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == addButton) {
			addButton.setSelected(!addButton.isSelected());
			adding = addButton.isSelected();
		}
		if (e.getSource() == removeButton) {
			if (model.getSelectedGear() != null) {
				model.removeGear(model.getSelectedGear());
				removeButton.setEnabled(false);
				propertiesButton.setEnabled(false);
			}
		}
		if (e.getSource() == propertiesButton) {
			if (model.getSelectedGear() != null) {
				Container parentWindow = this.getTopLevelAncestor();
				if (parentWindow instanceof JFrame) {
					GearPropertiesDialog dialog = 
							new GearPropertiesDialog((JFrame) parentWindow, 
							model);
					dialog.setVisible(true);
				}
				model.changeGear(model.getSelectedGear());
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (adding) {
			int currentXS = e.getXOnScreen();
			int currentYS = e.getYOnScreen();
			radiusG = (int) Math.sqrt(Math.pow(xGS  - currentXS, 2) +
					Math.pow(yGS  - currentYS, 2));
			if (radiusG < GEAR_MIN_SIZE) {
				radiusG = GEAR_MIN_SIZE;
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (adding) {
			xG = e.getX();
			yG = e.getY();
			xGS = e.getXOnScreen();
			yGS = e.getYOnScreen();
			radiusG = GEAR_MIN_SIZE;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (adding) {
			Gear gr = new Gear();
			gr.setLocation(xG - radiusG / 2, yG - radiusG / 2);
			gr.setSize(radiusG, radiusG);
			gr.addMouseWheelListener(this);
			gr.addMouseListener(new MouseListener() {
				@Override
				public void mousePressed(MouseEvent e) {
					model.selectGear((Gear)e.getSource());
					removeButton.setEnabled(true);
					propertiesButton.setEnabled(true);
				}
				@Override
				public void mouseClicked(MouseEvent e) {
				}
				@Override
				public void mouseReleased(MouseEvent e) {	
				}
				@Override
				public void mouseEntered(MouseEvent e) {	
				}
				@Override
				public void mouseExited(MouseEvent e) {
				}
			});
			model.addGear(gr);
			adding = false;
			addButton.setSelected(adding);
		}
	}
	
	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		Gear gr = model.getSelectedGear();
		if (gr != null) {
			double scale = - e.getWheelRotation() * SCALE_PER_REVOLUTION;
			int dx = (int)(gr.getWidth() * scale);
			int dy = (int)(gr.getHeight() * scale);
			if (gr.getWidth() + dx > GEAR_MIN_SIZE) {
				gr.setSize(gr.getWidth() + dx, gr.getHeight());
				gr.setLocation(gr.getX() - dx / 2, gr.getY());
			}
			if (gr.getHeight() + dy > GEAR_MIN_SIZE) {
				gr.setSize(gr.getWidth(), gr.getHeight() + dy);
				gr.setLocation(gr.getX(), gr.getY() - dy / 2);
			}
			model.changeGear(gr);
		}
	}
	
	@Override
	public void componentResized(ComponentEvent e) {
		toolbar.setSize(this.getWidth(), toolbar.getPreferredSize().height);
		workbench.setSize(this.getWidth(), this.getHeight() - toolbar.getHeight());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {	
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {	
	}

	@Override
	public void componentMoved(ComponentEvent e) {
	}

	@Override
	public void componentShown(ComponentEvent e) {
	}

	@Override
	public void componentHidden(ComponentEvent e) {
	}
	
}
