package edu.kpi.cg.lab1;

import java.awt.Graphics;

import javax.swing.JFrame;

public class MechanismMain extends JFrame {
	
	static MechanismMain frame;
	
	MechanismMain() {
		super("Mechanism Eight");
	}
	
	public void paint(Graphics g) {
		super.paint(g);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		frame = new MechanismMain();
		MechanismModel model = new MechanismModel();
		MechanismViewController controller = new MechanismViewController(model);
		model.addView(controller);
		frame.add(controller);
		frame.setSize(700, 700);
		
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
