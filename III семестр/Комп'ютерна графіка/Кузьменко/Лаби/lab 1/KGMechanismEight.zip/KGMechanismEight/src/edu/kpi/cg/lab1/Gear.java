package edu.kpi.cg.lab1;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.GeneralPath;

public class Gear extends Component {
	
	/**
	 * Відношення кутових розмірів основи та вершини зубця
	 */
	private static double cogConstr = 0.55;
	/**
	 * Відношення висоти зубця до загального радіусу колеса
	 */
	private static double cogHeight = 0.25;
	/**
	 * Глибина рекурсії при малюванні фрактала "сніжинка Коха"
	 */
	private static int iterations = 5;
	/**
	 * Кількість зубців колеса при малюванні фрактала "сніжинка Коха" на поверхні
	 */
	private static int texturedGearCogs = 6;
	
	private int cogCount;
	private boolean textureEnabled;
	private Color wheelColor; 
	private Color lineColor; 
	private Color axleColor;
	private Color textureColor; 
	private double rotation;
	
	
	public Gear() {
		super();
		cogCount = 6;
		textureEnabled = true;
		lineColor = axleColor = Color.BLACK;
		wheelColor = Color.GRAY;
		textureColor = Color.RED;
		rotation = 0;
		cogCount = 6;
		cogConstr = 0.55;
		cogHeight = 0.25;
		iterations = 5;
	}
	
	/**
	 * @return the cogCount
	 */
	public int getCogCount() {
		return cogCount;
	}

	/**
	 * @param cogCount the cogCount to set
	 */
	public void setCogCount(int cogCount) {
		this.cogCount = cogCount;
	}

	/**
	 * @return the textureEnabled
	 */
	public boolean isTextureEnabled() {
		return textureEnabled;
	}

	/**
	 * @param textureEnabled the textureEnabled to set
	 */
	public void setTextureEnabled(boolean textureEnabled) {
		this.textureEnabled = textureEnabled;
	}
	
	/**
	 * @return Кут повороту зубчастого колеса у радіанах
	 */
	public double getRotation() {
		return rotation;
	}

	/**
	 * Повертає зубчасте колесо на заданий кут
	 * @param rotation значення кута у радіанах
	 */
	public void setRotation(double rotation) {
		this.rotation = rotation;
	}

	/**
	 * @return the wheelColor
	 */
	public Color getWheelColor() {
		return wheelColor;
	}

	/**
	 * @param wheelColor the wheelColor to set
	 */
	public void setWheelColor(Color wheelColor) {
		this.wheelColor = wheelColor;
	}

	/**
	 * @return the lineColor
	 */
	public Color getLineColor() {
		return lineColor;
	}

	/**
	 * @param lineColor the lineColor to set
	 */
	public void setLineColor(Color lineColor) {
		this.lineColor = lineColor;
	}

	/**
	 * @return the axleColor
	 */
	public Color getAxleColor() {
		return axleColor;
	}

	/**
	 * @param axleColor the axleColor to set
	 */
	public void setAxleColor(Color axleColor) {
		this.axleColor = axleColor;
	}

	/**
	 * @return the textureColor
	 */
	public Color getTextureColor() {
		return textureColor;
	}

	/**
	 * @param textureColor the textureColor to set
	 */
	public void setTextureColor(Color textureColor) {
		this.textureColor = textureColor;
	}
	
	public void assign(Gear gear) {
		wheelColor = gear.wheelColor; 
		lineColor = gear.lineColor; 
		axleColor = gear.axleColor;
		textureColor = gear.textureColor; 
		rotation = gear.rotation;
	}

	public void paint(Graphics gr) {
		Graphics2D g = (Graphics2D) gr;
		int w = this.getWidth();
		int h = this.getHeight();
		int x = w / 2;
		int y = h / 2;
		int radius = Math.max(w, h) / 2 - 5;
		int axleRadius = radius / 4;
		Point a = new Point(x, y - radius);
		Point b = new Point(x + (int)(radius * Math.cos(Math.PI / 6)), y + radius / 2);
		Point c = new Point(x - (int)(radius * Math.cos(Math.PI / 6)), y + radius / 2);
		int innerRadius = 
				(int) Math.sqrt(Math.pow((a.x + 2*c.x) / 3 - x, 2) 
						- Math.pow((a.y + 2*c.y) / 3 - y, 2));
		
		// Побудова контуру зубчатої передачі
		int cogs = texturedGearCogs;
		if (!textureEnabled) {
			cogs = cogCount;
		}
		GeneralPath p = new GeneralPath();
		double angleBase = 2 * Math.PI / cogs;
		double angleTop = angleBase * cogConstr;
		double angle = rotation;
		p.moveTo(x + (int)(innerRadius*Math.cos(angle)),
				y + (int)(innerRadius*Math.sin(angle)));
		for (int i = 0; i < cogs; i++) {
			/*if (i == 0) {
			 	// Контрольні лінії
				g.drawLine(x, y,
						x + (int)(innerRadius*Math.cos(angle)),
						y + (int)(innerRadius*Math.sin(angle)));
				g.drawLine(x, y,
						x + (int)(radius * Math.cos((angle + (angleBase - angleTop) / 2))),
						y + (int)(radius * Math.sin((angle + (angleBase - angleTop) / 2))));
				g.drawLine(x, y,
						x + (int)(radius * Math.cos((angle + angleBase - (angleBase - angleTop) / 2))),
						y + (int)(radius * Math.sin((angle + angleBase - (angleBase - angleTop) / 2))));
				g.drawLine(x, y,
						x + (int)(innerRadius*Math.cos(angle + angleBase)),
						y + (int)(innerRadius*Math.sin(angle + angleBase)));
				g.drawLine(x, y, x, y - radius);
				g.drawLine(x, y, x - (int)(innerRadius*Math.cos(Math.PI / 4)), 
						(int)(y - innerRadius*Math.sin(Math.PI/4)));
				g.drawOval(x - radius, y - radius, 2*radius, 2*radius);
				g.drawOval(x - innerRadius, y - innerRadius, 2*innerRadius, 2*innerRadius);
			}*/
			p.lineTo(x + (int)(radius * Math.cos((angle + (angleBase - angleTop) / 2))),
					y + (int)(radius * Math.sin((angle + (angleBase - angleTop) / 2))));
			p.curveTo(x + (int)(radius * 1.03 * Math.cos((angle + angleBase/2))),
					y + (int)(radius * 1.03 * Math.sin((angle + angleBase/2))),
					x + (int)(radius * 1.03 * Math.cos((angle + angleBase/2))),
					y + (int)(radius * 1.03 * Math.sin((angle + angleBase/2))),
					x + (int)(radius * Math.cos((angle + angleBase - (angleBase - angleTop) / 2))),
					y + (int)(radius * Math.sin((angle + angleBase - (angleBase - angleTop) / 2))));
			p.lineTo(x + (int)(innerRadius*Math.cos(angle + angleBase)),
					y + (int)(innerRadius*Math.sin(angle + angleBase)));
			angle += angleBase;
		}
		p.closePath();
		
		// Малювання зубчатої передачі
		g.setPaint(lineColor);
		g.drawOval((int) (x - radius * (1 - cogHeight)),
				(int) (y - radius * (1 - cogHeight)), 
				(int) (2 * radius * (1 - cogHeight)), 
				(int) (2 * radius * (1 - cogHeight)));
		g.draw(p);
		g.setPaint(wheelColor);
		g.fill(p);
		g.fillOval((int) (x - radius * (1 - cogHeight)),
				(int) (y - radius * (1 - cogHeight)), 
				(int) (2 * radius * (1 - cogHeight)), 
				(int) (2 * radius * (1 - cogHeight)));
		if (textureEnabled) {
			// Малювання фрактала "сніжинка Коха" на поверхні колеса
			g.setColor(textureColor);
			drawKochSnowflake(g, a, b, c, iterations);
		}
		// Малювання вісі зубчатої передачі
		g.setColor(axleColor);
		g.fillOval(x - axleRadius, y - axleRadius, axleRadius * 2, axleRadius * 2);
	}
	
    private void drawKochSnowflake(Graphics g, Point p1, Point p2, Point p3, int iterations) {
    	drawKochLine(g, p1, p2, p3, iterations);
    	drawKochLine(g, p2, p3, p1, iterations);
    	drawKochLine(g, p3, p1, p2, iterations);
    }
    
    private void drawKochLine(Graphics g, Point p1, Point p2, Point p3, int n) {
    	Point p1R = rotatePoint(p1, rotation);
    	Point p2R = rotatePoint(p2, rotation);
    	g.drawLine(p1R.x, p1R.y, p2R.x, p2R.y);
    	 if (n == 0) {
             return;
         }
         Point p4 = new Point((p2.x + 2 * p1.x) / 3, (p2.y + 2 * p1.y) / 3);
         Point p5 = new Point((p1.x + 2 * p2.x) / 3, (p1.y + 2 * p2.y) / 3);
         Point ps = new Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
         Point pn = new Point((4 * ps.x - p3.x) / 3, (4 * ps.y - p3.y) / 3);

         drawKochLine(g, p1, p4, new Point((2 * p1.x + p3.x) / 3, (2 * p1.y + p3.y) / 3), n - 1);
         drawKochLine(g, p4, pn, p5,n-1);
         drawKochLine(g, pn, p5, p4, n-1);
         drawKochLine(g, p5, p2, new Point((2 * p2.x + p3.x) / 3, (2 * p2.y + p3.y) / 3), n - 1);
    }
    
    private Point rotatePoint(Point p, double angle) {
    	int x = this.getWidth() / 2;
		int y = this.getHeight() / 2;
    	double xt=x+(p.x-x) * Math.cos(angle)+(y-p.y) * Math.sin(angle);
    	double yt=y+(p.x-x) * Math.sin(angle)+(p.y-y) * Math.cos(angle);
    	return new Point((int)xt, (int)yt);
    }
}
