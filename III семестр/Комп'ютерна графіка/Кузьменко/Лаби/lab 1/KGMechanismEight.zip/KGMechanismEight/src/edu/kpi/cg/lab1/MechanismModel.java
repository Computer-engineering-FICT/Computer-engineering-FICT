package edu.kpi.cg.lab1;

import java.util.ArrayList;

public class MechanismModel {
	
	private ArrayList<Gear> gears;
	private ArrayList<MechanismViewController> views;
	
	private Gear selectedGear;
	
	public MechanismModel() {
		gears = new ArrayList<Gear>();
		views = new ArrayList<MechanismViewController>();
		selectedGear = null;
	}
	
	public void addView(MechanismViewController view) {
		views.add(view);
	}
	
	public boolean removeView(MechanismViewController view) {
		return views.remove(view);
	}
	
	public void addGear(Gear gear) {
		gears.add(gear);
		for (MechanismViewController view : views) {
			view.gearAdded(gear);
		}
	}
	
	public boolean removeGear(Gear gear) {
		if (gears.remove(gear)) {
			if (gear == selectedGear) {
				selectedGear = null;
			}
			for (MechanismViewController view : views) {
				view.gearRemoved(gear);
			}
			return true;
		} else {
			return false;
		}
	}
	
	public void changeGear(Gear gear) {
		if (!gears.contains(gear)) {
			addGear(gear);
		}
		for (MechanismViewController view : views) {
			view.gearChanged(gear);
		}
	}
	
	public boolean selectGear(Gear gear) {
		if (gears.contains(gear)) {
			selectedGear = gear;
			return true;
		} else {
			return false;
		}
	}
	
	public Gear getSelectedGear() {
		return selectedGear;
	}
	
	public Gear getGear(int index) {
		return gears.get(index);
	}
	
	public int getGearsCount() {
		return gears.size();
	}
}
