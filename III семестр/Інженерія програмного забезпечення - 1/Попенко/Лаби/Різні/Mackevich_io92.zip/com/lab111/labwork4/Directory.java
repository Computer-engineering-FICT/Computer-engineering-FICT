package com.lab111.labwork4;

/**
 * Composite class
 * group of files
 * @author solimr
 */
public class Directory extends FileComponent{
	/**
	 * files and directories in this directory
	 */
	private FileComponent[] content=new FileComponent[20];
	/**
	 * number of files
	 */
	private int size=0;
	
	/**
	 * Standart constructor
	 * @param path is path to new directory from father
	 * @param father is parent of this directory
	 */
	public Directory(String path,Directory father){
		if (father!=null){
			absPath=father.getPath();
			father.addFile(this);
		}
		absPath+=path;
		Parent=father;
	}
	
	/**
	 * Constructor without parent
	 * @param path is name of root directory
	 */
	public Directory(String path){
		this(path,null);
	}
	
	/**
	 * Adding new file to directory
	 * @param f is new file
	 * @return new file
	 */
	public FileComponent addFile(FileComponent f){
		if (size>=content.length){
			FileComponent[] temp = new FileComponent[2*size];
			System.arraycopy(content, 0, temp, 0, size);
			content=temp;
		}
		content[size]=f;
		size++;
		return f;
	}
	
	/**
	 * Delete all from this directory
	 */
	public void del(){
		for (FileComponent f : content)
			if (f!=null)
				f.del();
		rmdir(absPath);
	}
	
	/**
	 * Get file by path
	 * @param path is destination path
	 * @return file by path
	 */
	public FileComponent getFile(String path){
		for (FileComponent f:content)
			if (f!=null&&f.getPath().equals(path))
				return f;
		return null;
	}
	
	/**
	 * deleting some file from content
	 * @param f is deleting file
	 */
	public void delFile(FileComponent f){
		for (int i=0;i<size;i++)
			if (content[i].getPath().equals(f.getPath())){
				System.arraycopy(content, i+1, content, i, size-i-1);
				size--;
				break;
			}
		f.del();
	}
	
	/**
	 * Create new directory
	 * @param path is path of new directory
	 * @return new directory
	 */
	public Directory create(String path){
		System.out.println("Method Directory.create("+path+")");
		Directory dir = new Directory(path,Parent);
		addFile(dir);
		return dir;
	}
	
	/**
	 * delete directory by path
	 * @param path is path do deleting directory
	 */
	public void rmdir(String path){
		System.out.println("Method Directory.rmdir("+path+")");
	}

	/**
	 * return size of all files in directory
	 */
	@Override
	public int getSize() {
		int S=0;
		for (int i=0;i<size;i++)
			S+=content[i].getSize();
		return S;
	}

}
