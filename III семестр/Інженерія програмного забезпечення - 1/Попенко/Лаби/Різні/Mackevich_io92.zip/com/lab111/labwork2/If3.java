package com.lab111.labwork2;

public interface If3 extends If2 {

	public void meth3();
}
