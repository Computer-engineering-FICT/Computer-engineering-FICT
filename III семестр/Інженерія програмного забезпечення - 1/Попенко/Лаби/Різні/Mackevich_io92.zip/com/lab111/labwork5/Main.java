package com.lab111.labwork5;

/**
 * Client class
 * @author solimr
 */
public class Main {

	/**
	 * Main client method
	 * @param args don't use
	 */
	public static void main(String[] args) {
		Object[] test = {"first","second","third"};
		StraightList sList = new StraightList();
		ReverseList rList = new ReverseList();
		for (int i=0;i<3;i++){
			sList.add(test[i]);
			rList.add(test[i]);
		}
		ObjectIterator it1 = sList.getIterator();
		ObjectIterator it2 = rList.getIterator();
		System.out.println("First iterator:");
		System.out.println(it1.current());
		while (!it1.isDone())
			System.out.println(it1.next());
		System.out.println("Second iterator:");
		System.out.println(it2.current());
		while (!it2.isDone())
			System.out.println(it2.next());
	}

}
