package com.lab111.labwork2;
/**
 * Template first class.
 * @author Solimr
 *
 */
public class Cl1 implements If1 {

	If1 SomeData1;
	/**
	 * 
	 */
	@Override
	public void meth1() {
		System.out.println("Cl1: meth1");
	}

}
