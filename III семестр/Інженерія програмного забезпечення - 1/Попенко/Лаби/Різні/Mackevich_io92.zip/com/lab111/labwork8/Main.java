package com.lab111.labwork8;

/**
 * Client class
 * @author solimr
 */
public class Main {

	/**
	 * Main client method
	 * @param args don't use
	 */
	public static void main(String[] args) {
		Object[] test = {"first","second","third"};
		List l = new StraightList();		
		for (int i=0;i<test.length;i++){
			l.add(test[i]);
		}
		ObjectIterator it1 = l.getIterator();
		System.out.println("First iterator:");
		System.out.println(it1.current());
		while (!it1.isDone())
			System.out.println(it1.next());
		ObjectIterator it2 = new ReverseIterator(it1);
		System.out.println("Second iterator:");
		System.out.println(it2.current());
		while (!it2.isDone())
			System.out.println(it2.next());
	}

}
