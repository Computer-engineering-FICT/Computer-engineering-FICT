package com.lab111.labwork8;

/**
 * List class with direction from end to begin
 * @author solimr
 */
public class ReverseList extends List {
	
	/**
	 * Standart constructor
	 */
	public ReverseList(){
		super();
	}

	/**
	 * Factory method, get reverse iterator
	 * @return iterator for this list
	 */
	@Override
	public ObjectIterator getIterator() {
		return new ReverseIterator(this);
	}

}
