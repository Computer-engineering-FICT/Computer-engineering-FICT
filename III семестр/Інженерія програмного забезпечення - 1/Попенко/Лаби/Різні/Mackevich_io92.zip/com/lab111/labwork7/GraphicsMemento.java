package com.lab111.labwork7;

/**
 * Memento class for Graphics
 * @author solimr
 */
public class GraphicsMemento {
	/**
	 * Coordinate x, top left corner
	 */
	private int x;
	/**
	 * Coordinate y, top left corner
	 */
	private int y;	
	/**
	 * Width of graphics
	 */
	private int width;
	/**
	 * Height of graphics
	 */
	private int height;
	
	/**
	 * RGB Color
	 */
	private byte[] Color = {0,0,0};
	
	/**
	 * Number of included graphics
	 */
	private int size=0;
	
	/**
	 * List of included graphics
	 */
	private Graphics[] content;
	
	/**
	 * Standart constructor, create memento for state of Graphics
	 * @param g is graphics, which state memento must keep
	 */
	public GraphicsMemento(Graphics g){
		x=g.getX();
		y=g.getY();
		width=g.getWidth();
		height=g.getHeight();
		Color=g.getColor();
		content=g.getContent();
		size=g.getSize();
	}
	
	/**
	 * Memento return state to it's master
	 * @param g is master of state
	 */
	public void setState(Graphics g){
		g.setPoint(x, y);
		g.setDimension(width, height);
		g.setColor(Color);
		g.setContent(content,size);
	}
}
