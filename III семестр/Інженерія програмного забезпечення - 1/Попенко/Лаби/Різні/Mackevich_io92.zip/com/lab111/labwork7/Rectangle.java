package com.lab111.labwork7;

/**
 * Leaf class,
 * Rectangle line
 * @author Solimr
 */
public class Rectangle extends Graphics{

	/**
	 * Constructor, create size and place of graphics
	 * @param xUpLeft is coordinate x of top left corner
	 * @param yUpLeft is coordinate y of top left corner
	 * @param xDownRight is coordinate x of low right corner
	 * @param yDownRight is coordinate x of low right corner
	 */
	public Rectangle(int xUpLeft,int yUpLeft,int xDownRight,int yDownRight){
		setPoint(xUpLeft, yUpLeft);
		setDimension(xDownRight-xUpLeft, yDownRight-yUpLeft);
	}
	
	/**
	 * Paint rectangle
	 */
	@Override
	public void paint() {	
		System.out.println("Rectangle: x="+getX()+", y="+getY()+", width="+getWidth()+
				", height="+getHeight()+", Color="+getColor()[0]+" "+getColor()[1]+" "+getColor()[2]);		
	}

}
