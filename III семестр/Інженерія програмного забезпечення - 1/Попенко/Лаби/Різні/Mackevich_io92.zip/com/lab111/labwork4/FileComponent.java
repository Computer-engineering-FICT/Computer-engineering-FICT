package com.lab111.labwork4;

/**
 * Composite class
 * interface for files and directories
 * @author solimr
 *
 */
public abstract class FileComponent {
	/**
	 * parent of this file
	 */
	protected Directory Parent;
	/**
	 * path to this file
	 */
	protected String absPath;
	/**
	 * size of file
	 */
	protected int length;
	
	/**
	 * method must be realized
	 * @return size of file
	 */
	public abstract int getSize();
	/**
	 * method must be realized to delete itself
	 */
	public abstract void del();
	
	/**
	 * @return parent of this file
	 */
	public FileComponent getParent(){
		return Parent;
	}
	
	/**
	 * @return path to this file
	 */
	public String getPath(){
		return absPath;
	}
}
