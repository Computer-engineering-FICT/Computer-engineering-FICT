package com.lab111.labwork6;

/**
 * Basic class
 * @author solimr
 */
public class Cell extends Element{
	
	/**
	 * Standart constructor
	 * @param p is parent of cell
	 * @param s is state of cell
	 */
	public Cell(Field p, String s){
		this(p);
		setState(s);
	}
	
	/**
	 * Constructor without state
	 * @param p is parent of cell
	 */
	public Cell(Field p){
		setParent(p);
		p.addCell(this);
	}
	
	/**
	 * Constructor without parent
	 * @param s is state of cell
	 */
	public Cell(String s){
		setState(s);
	}

	/**
	 * Changing cell, if it is independent, else - cell with all dependence
	 */
	@Override
	public void changeState(String s) {
		if (isIndependent())
			setState(s);
		else
			Parent.changeState(s);
	}

}
