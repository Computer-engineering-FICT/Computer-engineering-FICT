package com.lab111.labwork9;

/**
 * Singleton class for whole database
 * @author solimr
 */
public class Database{
	
	/**
	 * parts of database
	 */
	private DBTable[] tables;
	/**
	 * number of parts
	 */
	private int length=0;
	/**
	 * private access point
	 */
	private static Database Single;
	
	/**
	 * Global access point
	 * @return single database
	 */
	public static Database init(){
		if (Single!=null)
			return Single;
		return Single=new Database();
	}
	
	/**
	 * Protected for other class constructor
	 */
	protected Database(){
		tables=new DBTable[5];
	}

	/**
	 * Add new table to database
	 * @param db is adding table
	 */
	public void addTable(DBTable db){
		if (!include(db)){
			if (length>=tables.length){
				Object[] temp = tables;
				tables = new DBTable[2*temp.length];
				System.arraycopy(temp, 0, tables, 0, temp.length);
			}
			tables[length]=db;
			length++;
		}
	}
	
	/**
	 * Is database include some table
	 * @param db is searching table
	 * @return true, if include
	 */
	public boolean include(DBTable db){
		for (int i=0;i<length;i++)
			if (tables[i].getName().equals(db.getName()))
				return true;
		return false;
	}
	
	/**
	 * Get table from database but it's id
	 * @param id is id of table
	 * @return needed table
	 */
	public DBTable getTable(String id){
		DBTable value=null;
		for (int i=0;i<length;i++)
			if (tables[i].getName().equals(id)){
				value=tables[i];
				break;
			}
		return value;
	}
	
	@Override
	public String toString(){
		String S = "Database \n";
		for (int i=0;i<length;i++)
			S+=tables[i]+"\n";
		return S;
	}
}
