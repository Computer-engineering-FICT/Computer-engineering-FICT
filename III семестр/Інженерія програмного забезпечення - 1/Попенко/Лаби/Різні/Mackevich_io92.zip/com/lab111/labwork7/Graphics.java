/**
 * 
 */
package com.lab111.labwork7;

/**
 * General abstract component class, 
 * generalize all possible type of vector graphis
 * @author Solimr
 */
public abstract class Graphics {
	
	/**
	 * Coordinate x, top left corner
	 */
	private int x;
	/**
	 * Coordinate y, top left corner
	 */
	private int y;	
	/**
	 * Coordinate x, low right corner
	 */
	private int x2;
	/**
	 * Coordinate y, low right corner
	 */
	private int y2;
	
	/**
	 * RGB Color
	 */
	private byte[] Color = {0,0,0};
	
	/**
	 * Number of included graphics
	 */
	private int size=0;
	
	/**
	 * List of included graphics
	 */
	private Graphics[] content;
	
	/**
	 * @return coordinate x, top left corner
	 */
	public int getX(){
		return x;
	}
	
	/**
	 * @return coordinate y, top left corner
	 */
	public int getY(){
		return y;
	}
	
	/** 
	 * @return width of graphic
	 */
	public int getWidth(){
		return x2-x;
	}
	/**
	 * @return height of graphic
	 */
	public int getHeight(){
		return y2-y;
	}
	
	/**
	 * @return RGB color of graphics
	 */
	public byte[] getColor(){
		return Color;
	}
	
	/**
	 * Set coordinate of top left corner of graphics
	 * @param ax is new coordinate x
	 * @param ay is new coordinate y
	 */
	public void setPoint(int ax,int ay){
		if (ax*ay>0){
			x = ax;
			y = ay;
		}
	}
	
	/**
	 * Set size of graphics
	 * @param ax is new width
	 * @param ay is new height
	 */
	public void setDimension(int ax,int ay){
		if (ax*ay>0) {
			x2=x+ax;
			y2=y+ay;
		}
	}
	
	/**
	 * Set color of graphics
	 * @param c is new RGB color
	 */
	public void setColor(byte[] c){
		System.arraycopy(c, 0, Color, 0, 3);
	}
	
	/**
	 * Set other state of graphics
	 * @param m is memento of new state
	 */
	public void setMemento(GraphicsMemento m){
		m.setState(this);
	}
	
	/**
	 * Create memento of current state
	 * @return new memento with state of this graphics
	 */
	public GraphicsMemento createMemento(){
		return new GraphicsMemento(this);
	}
	
	/**
	 * Paint graphics, must be realise
	 */
	public abstract void paint();
	
	/**
	 * Manage structure, add new graphic to the composite graphics
	 * @param a is new graphic
	 * @return true if adding was successfull
	 */
	public boolean addGraphics(Graphics a){
		if (content==null)
			return false;
		content[size]=a;
		size++;
		return true;
	}
	
	/**
	 * Manage structure, remove some graphic from the composite graphics
	 * @param a is removing graphic
	 * @return true if removing was successfull
	 */
	public boolean removeGraphics(int index){
		if ((content==null)||(index<0)||(index>size-1)) 
			return false;	
		System.arraycopy(content, index+1, content, index, size-index-1);
		size--;
		return true;		
	}

	/**
	 * Manage structure, get graphics by it's index
	 * @param i is index of graphics
	 * @return graphics, placed on index-parameter
	 */
	public Graphics getGraphics(int i){
		if (content==null)
			return null;
		return content[i];
	}
	
	/**
	 * Make new list, if graphics can include other graphics
	 */
	protected void initContent(){
		content = new Graphics[50];
	}
	
	/**
	 * @return list of included graphics
	 */
	protected Graphics[] getContent(){
		return content;
	}
	
	/**
	 * @return number of included graphics
	 */
	protected int getSize(){
		return size;
	}
	
	/**
	 * Set new included graphics
	 * @param c is array of graphics
	 * @param num is number of new graphics
	 */
	protected void setContent(Graphics[] c,int num){
		content=c;
		size=num;
	}
}
