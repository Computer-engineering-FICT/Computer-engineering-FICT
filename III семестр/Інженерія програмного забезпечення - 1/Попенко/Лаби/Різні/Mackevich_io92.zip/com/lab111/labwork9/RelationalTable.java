package com.lab111.labwork9;

/**
 * Class for relation table
 * @author solimr
 */
public class RelationalTable {
	/**
	 * cells of table
	 */
	private Pair[] fields;
	/**
	 * number of cells
	 */
	private int size=0;
	
	/**
	 * Standart constructor
	 */
	public RelationalTable(){
		fields=new Pair[10];
	}
	
	/**
	 * Add cell to the table
	 * @param p is adding pair
	 */
	public void addField(Pair p){
		if (size>=fields.length){
			Pair[] temp = fields;
			fields = new Pair[2*temp.length];
			System.arraycopy(temp, 0, fields, 0, temp.length);
		}
		fields[size]=p;
		size++;
	}
	
	/**
	 * Get fields
	 * @return cells of the table
	 */
	public Pair[] getFields(){
		return fields;
	}
	
	/**
	 * Get value by key
	 * @param key is searching key
	 * @return founded value, or null if didn't find
	 */
	public Object getValue(String key){
		Object value=null;
		for (int i=0;i<size;i++){
			if (fields[i].getKey().equals(key))
				return fields[i].getValue();
		}
		return value;
	}
	
	/**
	 * Get number of cells
	 * @return number of cells
	 */
	public int getSize(){
		return size;
	}
	
	@Override
	public String toString(){
		String S = "Relational Table: \n";
		for (int i=0;i<size;i++)
			S+=fields[i]+"\n";
		return S;
	}
}