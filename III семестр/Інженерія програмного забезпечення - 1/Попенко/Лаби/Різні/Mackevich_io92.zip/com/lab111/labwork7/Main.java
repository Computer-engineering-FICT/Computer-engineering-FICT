package com.lab111.labwork7;

/**
 * Client class
 * @author solimr
 */
public class Main {

	/**
	 * Main client method
	 * @param args don't use
	 */
	public static void main(String[] args) {
		Ellipse e = new Ellipse(3, 2, 4, 4);
		byte[] Color = {50,100,120};
		e.setColor(Color);
		GraphicsMemento m = e.createMemento();
		e.paint();
		e.setDimension(5, 5);
		e.paint();
		e.setMemento(m);
		e.paint();
		
	}

}
