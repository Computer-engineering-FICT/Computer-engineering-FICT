package com.lab111.labwork2;

public interface If2 extends If1 {

	public void meth2();
}
