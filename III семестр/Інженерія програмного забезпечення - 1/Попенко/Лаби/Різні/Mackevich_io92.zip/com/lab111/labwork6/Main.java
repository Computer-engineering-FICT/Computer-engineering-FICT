package com.lab111.labwork6;

/**
 * Client class
 * @author solimr
 */
public class Main {

	/**
	 * Main client method
	 * @param args don't use
	 */
	public static void main(String[] args) {
		Field f1 = new Field("f1");
		Field f2 = new Field(f1);
		Cell c1 = new Cell(f1, "c1");
		new Cell(f1);
		new Cell(f2);
		System.out.print(f1);
		c1.changeState("c1");
		System.out.print(f1);
	}

}
