package com.lab111.labwork9;

/**
 * Class for database table
 * @author solimr
 */
public class DBTable{
	
	/**
	 * Keys for record's fields
	 */
	private String[] keys;
	/**
	 * ID of table
	 */
	private String ID;
	/**
	 * records in table
	 */
	private Record[] rows;
	/**
	 * number of records
	 */
	private int length=0;
	
	/**
	 * Standart constructor
	 * @param Name is ID of this table
	 * @param columns is keys for columns
	 */
	public DBTable(String Name,String[] columns){
		keys=columns;
		ID=Name;
		rows=new Record[10];
	}
	
	/**
	 * Add new record to the table
	 * @param r is adding table
	 */
	public void addRecord(Record r){
		if (!include(r)){
			if (length>=rows.length){
				Object[] temp = rows;
				rows = new Record[2*temp.length];
				System.arraycopy(temp, 0, rows, 0, temp.length);
			}
			rows[length]=r;
			length++;
		}
	}
	
	/**
	 * Is table include some record
	 * @param r is searching record
	 * @return true, if include
	 */
	public boolean include(Record r){
		for (int i=0;i<length;i++)
			if (rows[i].getKey().equals(r.getKey()))
				return true;
		return false;
	}
	
	/**
	 * Get name
	 * @return ID of the table
	 */
	public String getName(){
		return ID;
	}
	
	/**
	 * Get some record by it's ID
	 * @param id is searching ID
	 * @return founded record or null, if didn't find
	 */
	public Record getRecord(Object id){
		Record value=null;
		for (int i=0;i<length;i++)
			if (rows[i].getKey().equals(id)){
				value=rows[i];
				break;
			}
		return value;
	}
	
	/**
	 * Get position of key for columns
	 * @param key is searching key
	 * @return int position of searching key
	 */
	public int getKeyPos(String key){
		for (int i=0;i<keys.length;i++)
			if (keys[i].equals(key))
				return i;
		return -1;
	}
	
	/**
	 * Get number of columns
	 * @return number of columns
	 */
	public int getKeyNum(){
		return keys.length;
	}
	
	/**
	 * Get number of rows
	 * @return number of records
	 */
	public int getSize(){
		return length;
	}
	
	@Override
	public String toString(){
		String S = "Database Table \""+ID+"\" ("+length+") with ";
		for (int i=0;(i<keys.length)&&(keys[i]!=null);i++)
			S+=keys[i]+",";
		S+=" fields\n";
		for (int i=0;i<length;i++)
			S+=rows[i]+"\n";
		return S;
	}
}
