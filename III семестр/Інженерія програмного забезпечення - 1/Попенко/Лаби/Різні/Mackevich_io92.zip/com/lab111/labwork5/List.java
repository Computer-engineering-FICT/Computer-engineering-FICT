package com.lab111.labwork5;

/**
 * List class
 * @author solimr
 */
abstract public class List {
	/**
	 * list of elements
	 */
	private Object[] content;
	/**
	 * number of elements
	 */
	private int size=0;
	
	/**
	 * Standart constructor
	 */
	protected List(){
		content=new Object[50];
	}
	
	/**
	 * add new object to list
	 * @param o is adding object
	 */
	public void add(Object o){
		if (size==content.length-1){
			Object[] temp = content;
			content = new Object[2*temp.length];
			System.arraycopy(temp, 0, content, 0, temp.length);
		}
		content[size]=o;
		size++;
	}
	
	/**
	 * get object from list
	 * @param i is position of needed object
	 * @return needed object
	 */
	public Object get(int i){
		return content[i];
	}
	
	/**
	 * get size of list
	 * @return size of list
	 */
	public int getSize(){
		return size;
	}
	
	/**
	 * must be realized
	 * @return iterator for this list
	 */
	abstract public ObjectIterator getIterator();
}
