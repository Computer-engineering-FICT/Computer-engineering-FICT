package com.lab111.labwork4;

/**
 * Client class
 * @author solimr
 */
public class Main {

	/**
	 * Main client method
	 * @param args don't use
	 */
	public static void main(String[] args) {
		FileSystem sys = new FileSystem();
		sys.create();
		sys.destroy();
	}
}
