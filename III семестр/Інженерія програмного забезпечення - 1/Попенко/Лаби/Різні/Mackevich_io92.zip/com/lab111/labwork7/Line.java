package com.lab111.labwork7;

/**
 * Leaf class,
 * Straight line
 * @author Solimr
 */
public class Line extends Graphics {

	/**
	 * Constructor, create size and place of graphics
	 * @param xUpLeft is coordinate x of left end
	 * @param yUpLeft is coordinate y of left end
	 * @param xDownRight is coordinate x of right end
	 * @param yDownRight is coordinate x of right end
	 */
	public Line(int xUpLeft,int yUpLeft,int xDownRight,int yDownRight){
		setPoint(xUpLeft, yUpLeft);
		setDimension(xDownRight-xUpLeft, yDownRight-yUpLeft);
	}
	
	/**
	 * Paint line
	 */
	@Override
	public void paint() {	
		System.out.println("Line: x="+getX()+", y="+getY()+", width="+getWidth()+
				", height="+getHeight()+", Color="+getColor()[0]+" "+getColor()[1]+" "+getColor()[2]);		
	}

}
