package com.lab111.labwork4;

/**
 * Composite class
 * file - basic leaf
 * @author solimr
 */
public class File extends FileComponent{
	
	/**
	 * Standart constructor
	 * @param path is path to new file
	 * @param father is parent of this file
	 */
	public File(String path,Directory father){
		if (father!=null){
			absPath=father.getPath();
			father.addFile(this);
		}
		absPath=father.getPath()+path;
		Parent=father;		
	}

	/**
	 * Open for read file by path
	 * @param path is path to needed file
	 * @param createIfNotExist if true - create file
	 * @return needed file
	 */
	public File open(String path,boolean createIfNotExist){
		System.out.println("Method File.open("
				+path+", "+createIfNotExist+")");
		if (createIfNotExist)
			if (Parent.getFile(path)==null){				
				return (File)Parent.addFile(new File(path,Parent));
			}
			else
				return null;
		else
			return (File)Parent.getFile(path);
	}
	
	/**
	 * close this file
	 */
	public void close(){
		System.out.println("Method File.close()");
	}
	
	/**
	 * delete file by path
	 * @param path is path to deleting file
	 */
	public void delete(String path){
		System.out.println("Method File.delete("+path+")");
	}
	
	/**
	 * delete this file
	 */
	@Override
	public void del(){
		delete(absPath);
	}

	/**
	 * get size of this file
	 */
	@Override
	public int getSize() {
		return length;
	}
}
