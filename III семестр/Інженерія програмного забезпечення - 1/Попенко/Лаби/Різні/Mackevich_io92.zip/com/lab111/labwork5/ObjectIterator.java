package com.lab111.labwork5;

/**
 * Iterator class
 * @author solimr
 */
abstract public class ObjectIterator {
	/**
	 * list of elements
	 */
	protected List content;
	
	/**
	 * number of current element
	 */
	protected int index;
	
	/**
	 * Set iterator in the begining of list
	 */
	abstract public void inBegin();
	
	/**
	 * Set iterator in the end of list
	 */
	abstract public void inEnd();

	/**
	 * Get next element in direction
	 * @return next element
	 */
	abstract public Object next();
	
	/**
	 * Get previous element in direction
	 * @return previous element
	 */
	abstract public Object previous();
	
	/**
	 * Get this element
	 * @return current element
	 */
	public Object current(){
		return content.get(index);
	}
	
	/**
	 * Method look up, is list is over
	 * @return true, if list is over
	 */
	abstract public boolean isDone();
}
