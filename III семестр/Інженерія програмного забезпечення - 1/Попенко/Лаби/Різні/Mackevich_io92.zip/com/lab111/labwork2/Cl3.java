package com.lab111.labwork2;

public class Cl3 extends Cl1 implements If3 {

	@Override
	public void meth2() {
		System.out.println("Cl3: meth2");

	}

	@Override
	public void meth3() {
		System.out.println("Cl3: meth3");

	}

}
