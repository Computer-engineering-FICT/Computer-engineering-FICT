package com.lab111.labwork9;

/**
 * Class for pair key-relation key
 * @author solimr
 */
public class Relation extends Pair{
	/**
	 * Redirecting table
	 */
	private RelationalTable master;
	
	/**
	 * Standart constructor
	 * @param key is key for pair
	 * @param keyRefer is relation key
	 * @param RT is hander of relation
	 */
	public Relation(String key,String keyRefer,RelationalTable RT){
		super(key,keyRefer);
		master=RT;
	}
	
	@Override
	public Object getValue(){
		return master.getValue((String)super.getValue());
	}

}
