package com.lab111.labwork3;

/**
 * Composite class,
 * unbreakable group of graphics
 * @author Solimr
 */
public class CompositeGraphics extends Graphics {

	/**
	 * Constructor, create object and make possible to add graphics
	 */
	public CompositeGraphics(){
		initContent();
	}

	
	/**
	 * Generate new x coordinate, as the most left point
	 * @return new x coordinate
	 */
	@Override
	public int getX(){
		Graphics[] list = getContent();
		if (list==null)
			return -1;
		else{
			if (list[0]==null)
				return -1;
			int ax = list[0].getX();
			for (int i=1; list[i]!=null;i++)
				if (list[i].getX()<ax)
					ax = list[i].getX();
			x = ax;
			return x;
		}
	}
	
	/**
	 * Generate new y coordinate, as the most top point
	 * @return new y coordinate
	 */
	@Override
	public int getY(){
		Graphics[] list = getContent();
		if (list==null)
			return -1;
		else{
			if (list[0]==null)
				return -1;
			int ay = list[0].getY();
			for (int i=1; list[i]!=null;i++)
				if (list[i].getY()<ay)
					y = list[i].getY();
			y = ay;
			return y;
		}
	}
	
	/**
	 * Generate new width, as difference between x and most right point
	 * @return new width
	 */
	@Override
	public int getWidth(){
		Graphics[] list = getContent();
		if (list==null)
			return 0;
		else{
			if (list[0]==null)
				return 0;
			int ax = list[0].getX()+list[0].getWidth();
			for (int i=1; list[i]!=null;i++)
				if ((list[i].getX()+list[i].getWidth())>ax)
					ax = list[i].getX()+list[i].getWidth();
			width = ax - x;
			return width;
		}
	}
	
	/**
	 * Generate new height, as difference between y and most down point
	 * @return new height
	 */
	@Override
	public int getHeight(){
		Graphics[] list = getContent();
		if (list==null)
			return 0;
		else{
			if (list[0]==null)
				return 0;
			int ay = list[0].getY()+list[0].getHeight();
			for (int i=1; list[i]!=null;i++)
				if ((list[i].getY()+list[i].getHeight())>ay)
					ay = list[i].getY()+list[i].getHeight();
			height = ay - y;
			return height;
		}
	}
	
	/**
	 * Paint all included graphics
	 */
	@Override
	public void paint() {
		System.out.println("Composite: x="+getX()+", y="+getY()+", width="+getWidth()+", height="+getHeight());
		int i = 0;
		Graphics forPaint;
		while ((forPaint = getGraphics(i))!=null){
			forPaint.paint();
			i++;
		}
	}

}
