package com.lab111.labwork9;

/**
 * Class for pair key-value
 * @author solimr
 */
public class Pair {
	/**
	 * Value in pair
	 */
	private Object value;
	/**
	 * Key in value
	 */
	private String key;
	
	/**
	 * Standart constructor
	 * @param k is key
	 * @param v is value
	 */
	public Pair(String k,Object v){
		key=k;
		value=v;
	}
	
	/**
	 * Get value from pair
	 * @return value
	 */
	public Object getValue(){
		return value;
	}
	
	/**
	 * Get key from pair
	 * @return key
	 */
	public String getKey(){
		return key;
	}
	
	@Override
	public String toString(){
		return key+": "+value;
	}
}
