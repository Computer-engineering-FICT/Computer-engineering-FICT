package com.lab111.labwork8;

/**
 * List class with direction from begin to end
 * @author solimr
 */
public class StraightList extends List {
	
	/**
	 * Standart constructor
	 */
	public StraightList(){
		super();
	}

	/**
	 * Factory method, get straight iterator
	 * @return iterator for this list
	 */
	@Override
	public ObjectIterator getIterator() {
		return new StraightIterator(this);
	}

}
