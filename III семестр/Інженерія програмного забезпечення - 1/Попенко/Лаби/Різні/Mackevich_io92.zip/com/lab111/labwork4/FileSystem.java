package com.lab111.labwork4;

/**
 * Facade class
 * @author solimr
 */
public class FileSystem {
	
	/**
	 * path to upper directory
	 */
	private String rootpath = "/home/user/labwork4/dir1/";
	private Directory root = new Directory(rootpath);

	/**
	 * create new system of files and directories
	 */
	public void create(){
		root.create("dir2/");
		File file1 = new File("file1.dat", root);
		file1.open("file2.dat", true);
		file1.close();
		file1.open("dir2/file3.dat",false);	
	}
	
	/**
	 * delete all system
	 */
	public void destroy(){
		root.del();
	}
}
