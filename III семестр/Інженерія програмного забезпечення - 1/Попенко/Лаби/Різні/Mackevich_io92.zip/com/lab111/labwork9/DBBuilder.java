package com.lab111.labwork9;

/**
 * Builder class
 * @author solimr
 */
public class DBBuilder {
	/**
	 * Builded database
	 */
	private Database result;
	/**
	 * Part of database, which building at this time
	 */
	private DBTable currentTable;
	/**
	 * number of parts
	 */
	private int size=0;
	
	/**
	 * Standart constructor
	 */
	public DBBuilder(){
		result=Database.init();
	}
	
	/**
	 * Get builded database
	 * @return builded database
	 */
	public Database getResult(){
		return result;
	}
	
	/**
	 * Add new part to building database
	 * @param t is adding table
	 */
	public void addTable(RelationalTable t){
		Pair[] base = t.getFields();
		String[] keys=new String[t.getSize()];
		Object[] values=new Object[keys.length];
		
		for (int i=0;(i<keys.length)&&(base[i]!=null);i++){
			keys[i]=base[i].getKey();
			values[i]=base[i].getValue();
		}
		
		size++;
		DBTable table = new DBTable(Integer.toString(size), keys);
		currentTable=table;
		addRecord(values);
		
		result.addTable(table);
	}

	/**
	 * Add new record to building database
	 * @param fields is values for table
	 */
	public void addRecord(Object[] fields){
		if (fields.length!=currentTable.getKeyNum())
			return;
		currentTable.addRecord(new Record(
				Integer.toString(currentTable.getSize()), currentTable, fields));
	}
}
