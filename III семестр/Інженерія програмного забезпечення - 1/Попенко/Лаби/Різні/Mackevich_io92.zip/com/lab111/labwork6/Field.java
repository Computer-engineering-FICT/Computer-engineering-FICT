package com.lab111.labwork6;

/**
 * Component class
 * @author solimr
 */
public class Field extends Element {
	
	/**
	 * elements in field
	 */
	private Element[] content = new Element[20];
	/**
	 * number of elements in field
	 */
	private int size=0;
	
	/**
	 * Standart constructor
	 * @param p is parent of cell
	 * @param s is state of cell
	 */
	public Field(Field p,String s){
		this(p);
		setState(s);
	}
	
	/**
	 * Constructor without state
	 * @param p is parent of cell
	 */
	public Field(Field p){
		setParent(p);
		p.addCell(this);
	}
	
	/**
	 * Constructor without parent
	 * @param s is state of cell
	 */
	public Field(String s){
		setState(s);
	}
	
	/**
	 * Add new element to field
	 * @param e is new element
	 * @return new element
	 */
	public Element addCell(Element e){
		if (size>=content.length){
			Element[] temp = new Element[2*size];
			System.arraycopy(content, 0, temp, 0, size);
			content=temp;
		}
		content[size]=e;
		size++;
		return e;
	}
	
	/**
	 * Changing cell, if it is independent, else - cell with all dependence
	 */
	@Override
	public void changeState(String s) {
		if (isIndependent())
			setState(s);
		else
			Parent.changeState(s);
	}
	
	/**
	 * Set new state for field and all inner elements
	 */
	@Override
	public void setState(String s){
		super.setState(s);
		for (int i=0;i<size;i++)
			content[i].setState(s);
	}
	
	/**
	 * Get field and all content as string
	 */
	public String toString(){
		String s = "\n Field : "+getState()+"\n";
		for (int i=0;i<size;i++)
			s+=content[i]+"\n";
		return s;
	}
}
