package com.lab111.labwork3;

/**
 * Leaf class,
 * Straight line
 * @author Solimr
 */
public class Line extends Graphics {

	/**
	 * Constructor, create size and place of graphics
	 * @param xUpLeft is coordinate x of left end
	 * @param yUpLeft is coordinate y of left end
	 * @param xDownRight is coordinate x of right end
	 * @param yDownRight is coordinate x of right end
	 */
	public Line(int xUpLeft,int yUpLeft,int xDownRight,int yDownRight){
		x=xUpLeft; 
		y=yUpLeft;
		width=xDownRight-xUpLeft;
		height=yDownRight-yUpLeft;
	}
	
	/**
	 * Paint line
	 */
	@Override
	public void paint() {	
		System.out.println("Line: x="+x+", y="+y+", width="+width+", height="+height);		
	}

}
