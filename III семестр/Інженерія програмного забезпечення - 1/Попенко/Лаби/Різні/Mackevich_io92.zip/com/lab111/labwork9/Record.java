package com.lab111.labwork9;

/**
 * Class for database record
 * @author solimr
 */
public class Record {
	
	/**
	 * Values in record
	 */
	private Object[] values;
	/**
	 * ID of the record
	 */
	private String ID;
	/**
	 * Holding table for the record
	 */
	private DBTable master;
	
	/**
	 * Standart constructor
	 * @param Name is ID of the record
	 * @param table is holding table
	 * @param init is values of record
	 */
	public Record(String Name,DBTable table,Object[] init){
		ID=Name;
		master=table;
		values=init;
	}

	/**
	 * Get value from record by key
	 * @param key is searching value
	 * @return founded value, or null if didn't find
	 */
	public Object getValue(String key){
		return values[master.getKeyPos(key)];
	}
	
	/**
	 * Get key of the record
	 * @return ID
	 */
	public Object getKey(){
		return ID;
	}
	
	@Override
	public String toString(){
		String S = "Record "+ID+": ";
		for (int i=0;(i<values.length)&&(values[i]!=null);i++)
			S+=values[i]+",";
		return S;
	}
}
