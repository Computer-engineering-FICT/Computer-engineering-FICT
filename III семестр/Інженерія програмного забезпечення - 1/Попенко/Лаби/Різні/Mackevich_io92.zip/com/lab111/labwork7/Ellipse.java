package com.lab111.labwork7;

/**
 * Leaf class,
 * Ellipse line
 * @author Solimr
 */
public class Ellipse extends Graphics {

	/**
	 * Constructor, create size and place of graphics
	 * @param xUpLeft is coordinate x of top left corner
	 * @param yUpLeft is coordinate y of top left corner
	 * @param xRadius is max radius along x
	 * @param yRadius is max radius along y
	 */
	public Ellipse(int xUpLeft,int yUpLeft,int xRadius,int yRadius){
		setPoint(xUpLeft, yUpLeft);
		setDimension(2*xRadius, 2*yRadius);
	}
	
	/**
	 * Paint ellipse
	 */
	@Override
	public void paint() {	
		System.out.println("Ellipse: x="+getX()+", y="+getY()+", width="+getWidth()+
				", height="+getHeight()+", Color="+getColor()[0]+" "+getColor()[1]+" "+getColor()[2]);		
	}

}
