/**
 * 
 */
package com.lab111.labwork3;

/**
 * General abstract component class, 
 * generalize all possible type of vector graphis
 * @author Solimr
 */
public abstract class Graphics {
	
	/**
	 * Coordinate x, top left corner
	 */
	protected int x;
	/**
	 * Coordinate y, top left corner
	 */
	protected int y;	
	/**
	 * Width of graphic
	 */
	protected int width;
	/**
	 * Height of graphic
	 */
	protected int height;
	
	/**
	 * Number of included graphics
	 */
	private int size=0;
	
	/**
	 * List of included graphics
	 */
	private Graphics[] content;
	
	/**
	 * @return coordinate x, top left corner
	 */
	public int getX(){
		return x;
	}
	
	/**
	 * @return coordinate y, top left corner
	 */
	public int getY(){
		return y;
	}
	
	/** 
	 * @return width of graphic
	 */
	public int getWidth(){
		return width;
	}
	/**
	 * @return height of graphic
	 */
	public int getHeight(){
		return height;
	}
	
	/**
	 * Set coordinate of top left corner of graphics
	 * @param ax is new coordinate x
	 * @param ay is new coordinate y
	 */
	public void setPoint(int ax,int ay){
		x = ax;
		y = ay;
	}
	
	/**
	 * Set size of graphics
	 * @param ax is new width
	 * @param ay is new height
	 */
	public void setDimension(int ax,int ay){
		width=ax;
		height=ay;
	}
	
	/**
	 * Paint graphics, must be realise
	 */
	public abstract void paint();
	
	/**
	 * Manage structure, add new graphic to the composite graphics
	 * @param a is new graphic
	 * @return true if adding was successfull
	 */
	public boolean addGraphics(Graphics a){
		if (content==null)
			return false;
		content[size]=a;
		size++;
		return true;
	}
	
	/**
	 * Manage structure, remove some graphic from the composite graphics
	 * @param a is removing graphic
	 * @return true if removing was successfull
	 */
	public boolean removeGraphics(int index){
		if (content==null) 
			return false;
		
		System.arraycopy(content, index+1, content, index, size-index-1);
		size--;
		return false;		
	}

	/**
	 * Manage structure, get graphics by it's index
	 * @param i is index of graphics
	 * @return graphics, placed on index-parameter
	 */
	public Graphics getGraphics(int i){
		if (content==null)
			return null;
		return content[i];
	}
	
	/**
	 * Make new list, if graphics can include other graphics
	 */
	protected void initContent(){
		content = new Graphics[50];
	}
	
	/**
	 * @return list of included graphics
	 */
	public Graphics[] getContent(){
		return content;
	}
}
