package com.lab111.labwork6;

/**
 * Common interface for composite and chain of responsibility
 * @author solimr
 */
public abstract class Element {
	/**
	 * State of element
	 */
	private String State;
	/**
	 * Parent of element
	 */
	protected Element Parent;
	
	/**
	 * Changing state of this element
	 * Must be realized
	 * @param s is new state
	 */
	public abstract void changeState(String s);
	
	/**
	 * Set new state without other actions
	 * @param s is new state
	 */
	protected void setState(String s){
		State = s;
	}
	
	/**
	 * Get state
	 * @return state of element
	 */
	public String getState(){
		return State;
	}
	
	/**
	 * Can element change it's state by itself
	 * @return true, if can
	 */
	public boolean isIndependent(){
		return Parent==null;
	}
	
	/**
	 * Set parent of element
	 * @param e is new parent
	 */
	protected void setParent(Element e){
		Parent = e;
	}
	
	/**
	 * Get element as string
	 */
	@Override
	public String toString(){
		return "State: "+State;
	}
}
