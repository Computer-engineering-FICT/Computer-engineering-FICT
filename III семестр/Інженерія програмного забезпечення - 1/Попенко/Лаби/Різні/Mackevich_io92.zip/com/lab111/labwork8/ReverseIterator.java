package com.lab111.labwork8;

/**
 * Iterator class with direction from end to begin
 * @author solimr
 */
public class ReverseIterator extends ObjectIterator {
	
	/**
	 * Standart constructor
	 * @param list is list of iterating elements
	 */
	public ReverseIterator(List list){
		super(list);
		index=content.getSize()-1;
	}
	
	/**
	 * Specific, create new iterator from other for new algorithm
	 * @param it is other iterator
	 */
	public ReverseIterator(ObjectIterator it){
		super(it);
	}

	/**
	 * Set iterator in the begining of list
	 */
	@Override
	public void inBegin() {
		index=content.getSize()-1;
	}

	/**
	 * Set iterator in the end of list
	 */
	@Override
	public void inEnd() {
		index=0;
	}

	/**
	 * Get next element in direction
	 * @return next element
	 */
	@Override
	public Object next() {
		if (isDone())
			return null;
		index--;
		if (content.get(index)!=null)
			return content.get(index);
		else
			return next();
	}

	/**
	 * Get previous element in direction
	 * @return previous element
	 */
	@Override
	public Object previous() {
		if (isDone())
			return null;
		index++;
		if (content.get(index)!=null)
			return content.get(index);
		else
			return previous();
	}

	/**
	 * Method look up, is list is over
	 * @return true, if list is over
	 */
	@Override
	public boolean isDone() {
		return (index==0);
	}

}
