package com.lab111.labwork9;

import java.util.Date;

/**
 * Client class
 * @author solimr
 */
public class Main {

	/**
	 * Main method
	 * @param args isn't in use
	 */
	public static void main(String[] args) {
		RelationalTable table = new RelationalTable();
		table.addField(new Pair("Name", "Gordon"));
		table.addField(new Pair("Surname", "Freeman"));
		table.addField(new Pair("Money", 100500));
		
		RelationalTable table2 = new RelationalTable();
		Date date = new Date();
		table2.addField(new Relation("Money", "Money", table));
		table2.addField(new Pair("RegDate", date));
		table2.addField(new Pair("IsMan", true));
		
		Object[] record = {666,date,false};
		
		DBBuilder build = new DBBuilder();
		build.addTable(table);
		build.addTable(table2);
		build.addRecord(record);
		
		System.out.print(build.getResult());
	}

}
