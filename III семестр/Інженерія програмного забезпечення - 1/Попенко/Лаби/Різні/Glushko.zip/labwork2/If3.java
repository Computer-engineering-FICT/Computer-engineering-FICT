package com.lab111.labwork2;

/**
 * Interface If3,
 * consists of abstract method "meth3"
 * @author Nightingale
 *
 */
public interface If3 {

	public void meth3();
	
}

