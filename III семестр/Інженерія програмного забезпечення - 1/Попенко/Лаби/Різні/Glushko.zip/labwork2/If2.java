package com.lab111.labwork2;

/**
 * Interface If2 which extends If3,
 * consists of abstract method "meth2" and implemented method "meth3"
 * @author Nightingale
 *
 */
public interface If2 extends If3{

	public void meth2();
	
}

