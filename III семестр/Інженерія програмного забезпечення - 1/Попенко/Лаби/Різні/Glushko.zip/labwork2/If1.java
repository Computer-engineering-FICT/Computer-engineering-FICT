package com.lab111.labwork2;

/**
 * Interface If1 which extends If2,
 * consists of abstract method "meth1" and inherited method "meth2"
 * @author Nightingale
 *
 */
public interface If1 extends If2{

	public void meth1();
	
}

