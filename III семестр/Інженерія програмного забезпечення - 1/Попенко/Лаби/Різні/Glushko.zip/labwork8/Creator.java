package com.lab111.labwork8;
/**
 * interface for creator that realize iterator
 * @author Nightingale
 *
 */
public interface Creator {
	public Product CreateProduct();
	public void GetProduct(Product Product);
}