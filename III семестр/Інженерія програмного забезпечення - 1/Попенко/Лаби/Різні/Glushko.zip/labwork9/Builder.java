package com.lab111.labwork9;
/**
 * abstract class for builder
 * @author Nightingale
 *
 */
public abstract class Builder {
	public void create(){};
	public void setInfo(){};
	public Elements[] getTable(){return null;};
}