import com.lab111.labwork3.*;

public class Test {
    public static void main(String[] args) {
        Expr ex = new Expr();

        Expr c1 = new Expr();
            c1.setFirstExpr(new Constant("2"));
            c1.setSign(new Sign(Sign.MULTIPLY));
            c1.setSecondExpr(new Constant("3"));

        Expr c2 = new Expr();
            c2.setFirstExpr(new Variable("str"));
            c2.setSign(new Sign(Sign.DIVIDE));
            c2.setSecondExpr(new Constant("4"));

        ex.setFirstExpr(c1);
        ex.setSign(new Sign(Sign.PLUS));
        ex.setSecondExpr(c2);
        
        System.out.println(ex.getValue());
    }
}
