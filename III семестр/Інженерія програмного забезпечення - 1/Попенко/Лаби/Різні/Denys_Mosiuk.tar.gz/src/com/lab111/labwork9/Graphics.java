package com.lab111.labwork9;

/**
 * Abstract composite element
 *
 * @author dector
 * @version 28.11.10 23:33
 */
public interface Graphics {
    /**
     * Add child
     *
     * @param g child
     */
    public void add(Graphics g);

    /**
     * Return child
     *
     * @param n child number
     * @return child element
     */
    public Graphics get(int n);

    /**
     * Remove child
     *
     * @param n child number
     */
    public void rm(int n);
}
