package com.lab111.labwork8;

/**
 * @author dector
 * @version 28.11.10 17:00
 */
public interface Iterator {
    public boolean hasNext();
    public Element next();
}
