package com.lab111.labwork4;

/**
 * @author dector
 * @version 26 вер 2010 21:52:14
 */
public class Test {
    public static void main(String[] args) {
        Image img = new Image();

        for (int i = 1; i <= 4; i++) {
            img.setBorderVisibility(i, true);
        }       
        img.show(false);

        img.draw();
        img.show(true);

        img.draw();
    }
}
