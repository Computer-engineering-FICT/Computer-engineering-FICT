package com.lab111.labwork2;

/**
 * Educational class #2
 *
 * @author Denys Mosiuk
 * @version 2.0
 * @since 2.0
 */
public class Cl2 extends Cl1 implements Lf2{

    /**
     * Overrided "Alien" method
     *
     * @see Cl1#meth1()
     */
    public void meth1() {
        System.out.println("Cl2.meth1()");
    }

    /**
     * "Native" method
     *
     * @see Lf2#meth2()
     */
	public void meth2() {
	    System.out.println("Cl2.meth2()");
	}

    /**
     * "Alien" method
     *
     * @see Lf3#meth3()  
     */
    public void meth3() {
        System.out.println("Cl2.meth3()");
    }
}
