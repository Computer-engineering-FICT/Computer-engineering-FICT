package com.lab111.labwork6;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dector
 * @version 14.11.10 12:14
 */
public class Panel extends Widget {
    private List widgets;

    /** Default constructor */
    public Panel() {
        widgets = new ArrayList();
    }

    /**
     * Add child widget
     *
     * @param widget child widget
     */
    public void add(Widget widget) {
        widgets.add(widget);
    }

    /**
     * Remove child widget
     *
     * @param widget child widget
     */
    public void rm(Widget widget) {
        widgets.remove(widget);
    }

    /**
     * Returns array of nextlevel children
     *
     * @return array of children
     */
    public Widget[] getChildren() {
        Widget[] arr = new Widget[widgets.size()];
        widgets.toArray(arr);
        return arr;
    }

    /**
     * Returns <b>true</b> if has children, else <b>false</b>
     *
     * @return has children?
     */
    public boolean hasChildren() {
        if (widgets.isEmpty())
            return false;
        else
            return true;
    }

    /**
     * Accept acceptable Visitor
     *
     * @param v acceptable Visitor
     */
    public void accept(Visitor v) {
        try {
            v.visitPanel(this);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}
