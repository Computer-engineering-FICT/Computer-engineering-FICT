package com.lab111.labwork6;

import org.w3c.dom.events.EventException;

import java.rmi.NoSuchObjectException;

/**
 * @author dector
 * @version 14.11.10 12:14
 */
public abstract class Visitor {
    /**
     * Visit Button class
     *
     * @param widget widget to visit
     * @throws NoSuchMethodException if Visitor is not acceptable for widget
     */
    public void visitButton(Widget widget) throws NoSuchMethodException {
        throw new NoSuchMethodException();
    };

    /**
     * Visit Panel class
     *
     * @param widget widget to visit
     * @throws NoSuchMethodException if Visitor is not acceptable for widget
     */
    public void visitPanel(Widget widget) throws NoSuchMethodException {
        throw new NoSuchMethodException();
    };
}
