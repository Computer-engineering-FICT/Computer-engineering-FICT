package com.lab111.labwork5;

/**
 * Iterator for sequence-type collection
 *
 * @author dector
 * @version 30.10.10 21:10
 */
public class IntSequenceIterator implements IntIterator {
    private IntEl current;
    private IntSequence list;

    /**
     * Init iterator with initial <s>list</s> sequence
     * @param list iterable list
     */
    public IntSequenceIterator(IntSequence list) {
        this.list = list;
        toFirst();
    }

    /** Set first element as current */
    public void toFirst() {
        current = new IntEl();
        current.setNext(list.getFirst());
    }

    /**
     * Get next element in collection if exists any
     * @return next element
     * @throws EndOfCollectionException if there is no elements in collection more
     */
    public IntEl next() throws EndOfCollectionException {
        if (!hasNext())
            throw new EndOfCollectionException();

        current = current.getNext();
        return current;
    }

    /**
     * Get state of current iteration
     * @return true if collection has unviewed elements
     */
    public boolean hasNext() {
        if (current != list.getFirst().getPrev())
            return true;
        else
            return false;
    }
}
