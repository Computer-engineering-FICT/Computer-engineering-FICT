package com.lab111.labwork5;

/**
 * Collection encapsulator for integer
 *
 * @author dector
 * @version 30.10.10 19:19
 */
public class IntEl {
    private int value;
    private IntEl next;
    private IntEl prev;

    /** Default constructor */
    public IntEl() {}

    /** Initialize with value */
    public IntEl(int value) {
        this.value = value;
    }

    /**
     * Get value
     * @return current value
     */
    public int getValue() {
        return value;
    }

    /**
     * Set value
     * @param value value to set
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     * Get next element in collection
     * @return next element
     */
    protected IntEl getNext() {
        return next;
    }

    /**
     * Set next element in collection
     * @param next next element
     */
    protected void setNext(IntEl next) {
        this.next = next;
    }

    /**
     * Get previous element in collection
     * @return previous element
     */
    protected IntEl getPrev() {
        return prev;
    }

    /**
     * Set previous element in collection
     * @param prev previous element
     */
    protected void setPrev(IntEl prev) {
        this.prev = prev;
    }

    /** Null all links inside this element (for GB) */
    protected void nullLinks() {
        next =
        prev = null;
    }
}
