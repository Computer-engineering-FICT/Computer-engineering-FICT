package com.lab111.labwork8;

/**
 * Element in composite structure
 *
 * @author dector
 * @version 28.11.10 15:10
 */
public interface Element {
    public void addChild(Element child);
    public Element getChild(int n);
    public void rmChild(int n);
    public Iterator getIterator(IteratorCreator creator);
}
