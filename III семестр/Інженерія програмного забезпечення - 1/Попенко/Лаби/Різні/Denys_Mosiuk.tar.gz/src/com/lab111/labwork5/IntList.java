package com.lab111.labwork5;

/**
 * List-type integer collection
 *
 * @author dector
 * @version 30.10.10 19:22
 */
public class IntList implements IntCollection {
    private IntEl first;
    private int size;

    /** Default constructor */
    public IntList() {}

    /**
     * Get first element in list
     * @return firt element
     */
    public IntEl getFirst() {
        return first;
    }

    /**
     * Get last element in list
     * @return last element
     */
    public IntEl getLast() {
        return first.getPrev();
    }

    /**
     * Add element to list
     * @param element new element
     */
    public void add(IntEl element) {
        if (size == 0) {
            element.setNext(element);
            element.setPrev(element);
            first = element;
        }

        else {
            element.setNext(first);
            element.setPrev(first.getPrev());
            first.getPrev().setNext(element);
            first.setPrev(element);
        }

        size++;
    }

    /**
     * Remove element from list
     * @param element element to remove
     * @throws CollectionIsEmptyException if collection has no elements
     */
    public void remove(IntEl element) throws CollectionIsEmptyException {
        if (size == 0) {
            throw new CollectionIsEmptyException();
        }

        else if (size == 1) {
            first.nullLinks();
            first = null;
        }

        else {
            element.getNext().setPrev(element.getPrev());
            element.getPrev().setNext(element.getNext());
            element.nullLinks();
        }

        size--;
    }

    /**
     * Get number of elements in collection
     * @return number of elements
     */
    public int size() {
        return size;
    }

    /**
     * Get iterator for this collection
     * @return new iterator
     */
    public IntIterator getIterator() {
        return new IntListIterator(this);
    }
}
