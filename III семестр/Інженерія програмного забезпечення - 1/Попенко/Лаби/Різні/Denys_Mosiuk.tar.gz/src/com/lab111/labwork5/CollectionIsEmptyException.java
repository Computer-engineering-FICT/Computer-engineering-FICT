package com.lab111.labwork5;

/**
 * @author dector
 * @version 30.10.10 20:23
 */
public class CollectionIsEmptyException extends Exception {
    public CollectionIsEmptyException() {
        super();
    }

    public CollectionIsEmptyException(String s) {
        super(s);
    }
}
