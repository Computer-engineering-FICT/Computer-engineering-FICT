package com.lab111.labwork6;

/**
 * @author dector
 * @version 14.11.10 12:13
 */
public class Button extends Widget{
    /**
     * Accept "buttonable" Visitor
     *
     * @param v acceptable Visitor
     */
    public void accept(Visitor v) {
        try {
            v.visitButton(this);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}
