package com.lab111.labwork5;

/**
 * Sequence-type collection for integer
 *
 * @author dector
 * @version 30.10.10 20:57
 */
public class IntSequence implements IntCollection {
    private IntEl first;
    private int size;

    /** Done nothing */
    public IntSequence() {}

    /**
     * Get first element from collection
     * @return first element
     */
    public IntEl getFirst() {
        return first;
    }

    /**
     * Get last element from collection
     * @return last element
     */
    public IntEl getLast() {
        return first.getPrev();
    }

    /**
     * Add new element to collection. It will be automatically seted on his place
     * @param element element to add
     */
    public void add(IntEl element) {
        if (size == 0) {
            element.setNext(element);
            element.setPrev(element);
            first = element;
        }

        else {
            IntEl el = seekPlace(element);

            if (el == null) {
                if (element.getValue() < first.getValue()) {
                    element.setNext(first);
                    element.setPrev(first.getPrev());
                    first.getPrev().setNext(element);
                    first.setPrev(element);
                    first = element;
                }
                else {
                    element.setPrev(first.getPrev());
                    element.setNext(first);
                    first.getPrev().setNext(element);
                    first.setPrev(element);
                }
            }
            else {
                element.setPrev(el.getPrev());
                element.setNext(el);
                el.getPrev().setNext(element);
                el.setPrev(element);
                if (el == first)
                    first = element;
            }
        }

        size++;
    }

    /**
     * Remove element from collection
     * @param element selected element
     * @throws CollectionIsEmptyException if collection if empty
     */
    public void remove(IntEl element) throws CollectionIsEmptyException {
        if (size == 0) {
            throw new CollectionIsEmptyException();
        }

        else if (size == 1) {
            first.nullLinks();
            first = null;
        }

        else {
            element.getNext().setPrev(element.getPrev());
            element.getPrev().setNext(element.getNext());
            element.nullLinks();
        }

        size--;
    }

    /**
     * Get number of elements in collection
     * @return number of elements in collection
     */
    public int size() {
        return size;
    }

    /**
     * Get iterator for this collection
     * @return new iterator
     */
    public IntIterator getIterator() {
        return new IntSequenceIterator(this);
    }

    /**
     * Seek element in collection, that will be after current tested
     * @param element tested element
     * @return number of element if exists any, null if this element will be last
     */
    protected IntEl seekPlace(IntEl element) {
        IntIterator iterator = getIterator();

        IntEl el;
        while (iterator.hasNext()) {
            try {
                el = iterator.next();
                if (el.getValue() >= element.getValue())
                    return el;
            } catch (EndOfCollectionException e) {}
        }

        return null;

    }
}
