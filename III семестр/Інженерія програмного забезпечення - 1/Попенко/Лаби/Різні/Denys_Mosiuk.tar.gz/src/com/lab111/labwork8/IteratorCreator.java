package com.lab111.labwork8;

/**
 * Creators for iterators family
 *
 * @author dector
 * @version 28.11.10 17:04
 */
public abstract class IteratorCreator {
    /**
     * Return new Iterator for composite element
     *
     * @param element composite element
     * @return null
     */
    public Iterator createIterator(Element element) {
        System.out.println("IteratorCreator.createIterator() call");
        return null;
    };
}
