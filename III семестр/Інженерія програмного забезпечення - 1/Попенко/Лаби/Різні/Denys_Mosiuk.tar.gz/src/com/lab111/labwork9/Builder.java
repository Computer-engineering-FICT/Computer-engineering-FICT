package com.lab111.labwork9;

/**
 * Abstract builder
 *
 * @author dector
 * @version 29.11.10 0:00
 */
public interface Builder {
    /**
     * Build box in structure
     *
     * @param id ID number
     * @param parent parent's ID
     */
    public void buildBox(int id, int parent);

    /**
     * Build text in structure
     *
     * @param parent parent's ID
     */
    public void buildText(int parent);
}
