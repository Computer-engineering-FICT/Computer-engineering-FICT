package com.lab111.labwork9;

import java.util.ArrayList;
import java.util.List;

/**
 * Composite element in structure
 *
 * @author dector
 * @version 28.11.10 23:40
 */
public class Box implements Graphics {
    private List<Graphics> children;

    /** Default constructor */
    public Box() {
        children = new ArrayList<Graphics>();
        System.out.println("Creating new box ");
    }

    /**
     * Add child
     *
     * @param g child
     */
    public void add(Graphics g) {
        System.out.println("Adding new child to box:  " + g.getClass());
        children.add(g);
    }

    /**
     * Get element from structure
     *
     * @param n child number
     * @return graphics element
     */
    public Graphics get(int n) {
        System.out.println("Requesting #" + n + " element from box");
        return children.get(n);
    }

    /**
     * Remove element from structure
     *
     * @param n child number
     */
    public void rm(int n) {
        System.out.println("Requesting removing #"+ n + "element from box");
        children.remove(n);
    }
}
