package com.lab111.labwork2;

/**
 * Educational interface #3
 *
 * @author Denys Mosiuk
 * @version 2.0
 * @since 2.0
 */
public interface Lf3 extends Lf1 {

    /** Executable method */
    public void meth3();
    
}
