package com.lab111.labwork6;

/**
 * @author dector
 * @version 14.11.10 13:12
 */
public class Lab6 {
    public static void main(String[] args) {
        // Initialize main elements
        System.out.println("Initialize element structure");
        Widget root = new Panel();
        Panel panel1 = new Panel();
        Panel panel2 = new Panel();

        // Line 1
        panel1.add(new Button());
        panel1.add(new Button());
        panel1.add(new Button());

        panel2.add(new Button());
        panel2.add(panel1);
        root.add(panel2);

        // Line2
        panel1 = new Panel();
        panel2 = new Panel();
        panel1.add(new Button());
        panel2.add(panel1);

        panel1 = new Panel();
        panel1.add(new Button());
        panel2.add(panel1);
        root.add(panel2);

        // Line 3
        panel1 = new Panel();
        panel1.add(new Panel());
        panel1.add(new Button());
        panel1.add(new Panel());
        root.add(panel1);

        // Testing
        System.out.println("Counting buttons and panels in root panel with CountAllVisitor");
        root.accept(new CountAllVisitor());
        System.out.println();
        System.out.println("Counting buttons in root panel with CountButtonsVisitor");
        root.accept(new CountButtonsVisitor());
        System.out.println("Counting panels in root panel with CountPanelsVisitor");
        root.accept(new CountPanelsVisitor());
    }
}
