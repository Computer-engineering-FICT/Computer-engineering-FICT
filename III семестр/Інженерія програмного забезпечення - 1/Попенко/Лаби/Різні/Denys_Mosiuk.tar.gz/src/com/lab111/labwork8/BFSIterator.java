package com.lab111.labwork8;

/**
 * BFS Iterator
 *
 * @author dector
 * @version 28.11.10 17:03
 */
public class BFSIterator implements Iterator {
    /**
     * Init iterator on current element
     *
     * @param element current element
     */
    public BFSIterator(Element element) {
        System.out.println("Creating BFSIterator");
    };

    /**
     * Has structure next element?
     *
     * @return true if yes, else false
     */
    public boolean hasNext() {
        System.out.println("BFSIterator.hasNext()");
        return false;
    };

    /**
     * Return next element
     *
     * @return next element
     */
    public Element next() {
        System.out.println("BFSIterator.next()");
        return null;
    };
}
