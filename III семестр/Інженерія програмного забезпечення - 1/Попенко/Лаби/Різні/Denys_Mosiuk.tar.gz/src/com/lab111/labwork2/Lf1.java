package com.lab111.labwork2;

/**
 * Educational interface #1
 *
 * @author Denys Mosiuk
 * @version 2.0
 * @since 2.0
 */
public interface Lf1 {

    /** Included class */
    public static final Cl3 cl3 = new Cl3();

    /** Executable method */
    public void meth1();
    
}
