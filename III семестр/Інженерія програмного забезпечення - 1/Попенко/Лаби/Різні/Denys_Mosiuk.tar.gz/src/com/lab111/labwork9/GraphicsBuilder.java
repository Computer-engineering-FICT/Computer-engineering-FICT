package com.lab111.labwork9;

import java.util.HashMap;
import java.util.Map;

/**
 * Concrete builder
 *
 * @author dector
 * @version 29.11.10 0:04
 */
public class GraphicsBuilder implements Builder {
    /** Product */
    private Graphics g;

    /** ID store map */
    private Map<Integer, Graphics> map;

    /** Default constructor */
    public GraphicsBuilder() {
        System.out.println("Creating GraphicsBuilder");
        map = new HashMap<Integer, Graphics>();
    }

    /**
     * Build box in structure
     *
     * @param id ID number
     * @param parent parent's ID, 0 - is root
     */
    public void buildBox(int id, int parent) {
        System.out.println("Requesting box building #" + id + " in " + parent);
        Graphics b = new Box();

        if (parent != 0) {
            map.get(parent).add(b);
        }
        map.put(id, b);
    }

    /**
     * Build text in structure
     *
     * @param parent parent's ID
     */
    public void buildText(int parent) {
        System.out.println("Requesting text building in " + parent);
        map.get(parent).add(new Text());
    }

    /**
     * Return work result
     *
     * @return Graphics structure
     */
    public Graphics getGraphics() {
        return g;
    }
}
