package com.lab111.labwork4;

/**
 * @author dector
 * @version 26 вер 2010 20:07:02
 */
public class Image {
    /** Just inner image */
    private Graphics graphics;

    /**
     * Borders numbers
     *
     * <em>
     *      0
     *   +-----+
     *   |     |
     * 3 |     | 1
     *   |     |
     *   +-----+
     *      2
     * </em>
     */
    private Line[] borders;

    /** Borders visibility */
    private boolean[] bordersVis;

    /** Create new Image */
    public Image() {
        graphics = new Graphics();

        borders = new Line[4];
        for (int i = 0; i < 4; i++) {
            borders[i] = new Line();
        }

        bordersVis = new boolean[4];
        for (int i = 0; i < 4; i++) {
            bordersVis[i] = false;
        }
    }

    /**
     * Sets visibity of subsystem
     *
     * @param vis <b>true</b> to show, <b>false</b> to hide
     */
    public void show(boolean vis) {
        System.out.println("Image.show(" + vis + ")");
        double visible = (vis) ? 1 : 0;
        graphics.setTransperency(visible);
        for (int i = 0; i < 4; i++) {
            if (bordersVis[i]) {
                borders[i].setOpacity(1-visible);
            }
        }
    }

    /** Draw subsystem on the screen*/
    public void draw() {
        System.out.println("Image.draw()");
        graphics.draw();
        for(int i = 0; i < 4; i++) {
            if (bordersVis[i]) {
                borders[i].draw();
            }
        }
    }

    /**
     * Sets border visibility
     *
     * @param border borders number (1 - upper, next - clockwise)
     * @param visible visibility
     */
    public void setBorderVisibility(int border, boolean visible) {
        System.out.println("Image.setBorderVisibility(" + border + "," + visible + ")");
        bordersVis[border-1] = visible;
    }
}
