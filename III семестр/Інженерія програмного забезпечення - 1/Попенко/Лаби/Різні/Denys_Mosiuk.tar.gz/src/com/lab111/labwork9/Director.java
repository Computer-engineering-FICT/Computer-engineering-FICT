package com.lab111.labwork9;

/**
 * Just Director :)
 *
 * @author dector
 * @version 28.11.10 23:42
 */
public class Director {

    private Builder b;

    /**
     * Construct composite structure
     *
     * @param filename filename
     */
    public void construct(String filename) {
        // Your file parser may be here :)

        System.out.println("Requesting structure building from file: " + filename);

        if (filename.equals("fakefile.in")) {
            b.buildBox(1, 0);
            b.buildBox(2, 1);
            b.buildBox(3, 1);
            b.buildText(2);
            b.buildText(3);
        }
    }

    /**
     * Set concrette builder
     *
     * @param b builder
     */
    public void setBuilder(Builder b) {
        System.out.println("Setting builder " + b.getClass());
        this.b = b;
    }
}
