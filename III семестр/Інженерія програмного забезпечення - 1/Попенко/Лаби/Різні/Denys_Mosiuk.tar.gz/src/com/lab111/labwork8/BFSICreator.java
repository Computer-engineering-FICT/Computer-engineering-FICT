package com.lab111.labwork8;

/**
 * Creator for BFS Iterator
 *
 * @author dector
 * @version 28.11.10 17:08
 */
public class BFSICreator extends IteratorCreator {
     /**
     * Return BFSIterator
     *
     * @param element composite element
     * @return BFSIterator
     */
    public Iterator createIterator(Element element) {
        System.out.println("BFSICreator.createIterator() call");
        return new BFSIterator(element);
    }
}
