package com.lab111.labwork6;

/**
 * Counts number of buttons and panels in panel
 *
 * @author dector
 * @version 14.11.10 14:37
 */
public class CountAllVisitor extends Visitor {
    private int buttons = 0;
    private int panels = -1;

    /**
     * Counts number of buttons and panels in panel and print result
     *
     * @param widget widget to visit
     */
    public void visitPanel(Widget widget) {
        countAll(widget);
        System.out.println("Number of buttons: " + buttons);
        System.out.println("Number of panels: " + panels);
    }

    private void countAll(Widget widget) {
        if (widget instanceof Button) {
            buttons++;
        }

        else {
            if (widget.hasChildren()) {
                Widget[] arr = widget.getChildren();

                for (int i = 0; i < arr.length; i++) {
                    countAll(arr[i]);
                }
            }

            panels++;
        }
    }

}
