package com.lab111.labwork5;

/**
 * @author dector
 * @version 30.10.10 20:31
 */
public class Lab5Test {
    public static void main(String... args) {
        IntCollection coll = new IntList();
            coll.add(new IntEl(4));
            coll.add(new IntEl(14));
            coll.add(new IntEl(2));
            coll.add(new IntEl(12));
            coll.add(new IntEl(42));
        IntIterator iterator = coll.getIterator();

        while (iterator.hasNext()) {
            try {
                System.out.println(iterator.next().getValue());
            } catch (EndOfCollectionException e) {
                e.printStackTrace();
            }
        }

        System.out.println("");

        coll = new IntSequence();
            coll.add(new IntEl(4));
            coll.add(new IntEl(14));
            coll.add(new IntEl(2));
            coll.add(new IntEl(12));
            coll.add(new IntEl(42));
        iterator = coll.getIterator();

            while (iterator.hasNext()) {
            try {
                System.out.println(iterator.next().getValue());
            } catch (EndOfCollectionException e) {
                e.printStackTrace();
            }
        }
    }
}
