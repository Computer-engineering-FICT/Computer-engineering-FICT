package com.lab111.labwork7;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller class to demonstrate Memento pattern
 *
 * @author dector
 * @version 20.11.10 14:32
 */
public class Controller {
    /** Player */
    private Player player;

    /** Stored games (states) pull */
    private Map<String, Player.Memento> mems;

    /**
     * Initialize controller with new player
     *
     * @param player player
     */
    public Controller(Player player) {
        this.player = player;
        mems = new HashMap();
    }

    /** Returns player
     *
     * @return player
     */
    public Player getPlayer() {
        return player;
    }

    /** Sets player as current
     *
     * @param player player
     */
    public void setPlayer(Player player) {
        this.player = player;
    }

    /** Save game's state
     *
     * @param name game's name
     */
    public void saveGame(String name) {
        mems.put(name, player.getMemento());
    }

    /** Load game's state
     *
     * @param name game's name
     */
    public void loadGame(String name) {
        Player.Memento mem = mems.get(name);

        if (mem != null) {
            player.setMemento(mem);
        }
    }

    /**
     * Delete game
     *
     * @param name game's name
     */
    public void deleteGame(String name) {
        mems.remove(name);
    }

    /** Draw world on screen and print the message atop
     *
     * @param message message to print
     */
    public void draw(String message) {
        System.out.println(message);
        drawWorld();
        drawStatusLine();
    }

    /** Draw world (static) */
    private void drawWorld() {
        System.out.println(
            "##############\n" +
            "#.........%..#\n" +
            "#...@d.......|\n" +
            "#[...........#\n" +
            "##############");
    }

    /** Draw status line */
    private void drawStatusLine() {
        System.out.println("[Health: " + player.getHealth() +"/100, coords: " + player.getX() + ":" + player.getY() +"]");
        System.out.println();
    }
}
