package com.lab111.labwork5;

/**
 * Integer collection interface
 *
 * @author dector
 * @version 30.10.10 19:16
 */
public interface IntCollection {
    /** Get first element from collection */
    public IntEl getFirst();
    /** Get last element from collection */
    public IntEl getLast();
    /** Add element to collection */
    public void add(IntEl element);
    /** Remove element from collection */
    public void remove(IntEl element) throws CollectionIsEmptyException;
    /** Returns number of elements in collection*/
    public int size();
    /** Returns iterator for collection */
    public IntIterator getIterator();
}
