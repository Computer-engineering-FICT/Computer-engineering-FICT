package com.lab111.labwork2;

/**
 * Educational class #1
 *
 * @author Denys Mosiuk
 * @version 2.0
 * @since 2.0
 */
public class Cl1 implements Lf1 {

    /** Agregated {@link Cl1} */
    public Cl1 cl1;

    /** Agregated {@link Cl2} */
    public Cl2 cl2;

    /**
     * "Native" method
     *
     * @see Lf1#meth1()  
     */
    public void meth1() {
	    System.out.println("Cl1.meth1()");
    }
    
}
