package com.lab111.labwork3;

/**
 * Interface for expression control
 * Main <i>Composite</i> interface realisation
 *
 * @author dector
 * @version 25 вер 2010 13:55:48
 */
public interface Expression {
    /**
     * Sets value for current element
     *
     * @param value value to set
     */
    public void setValue(String value);

    /**
     * Returns data, that was stored in elemnts  
     *
     * @return element's value
     */
    public String getValue();
}
