package com.lab111.labwork7;

import java.util.List;

/**
 * Player class
 *
 * @author dector
 * @version 20.11.10 13:58
 */
public class Player {
    /** Internal state */
    private State state;

    /** Default counstructor */
    public Player() {
        state = new State();
    }

    /** Memento class */
    public class Memento {
        /** Inner state for Player */
        private State state;

        /**
         * Initialize memento with internal state
         *
         * @param state
         */
        private Memento(State state) {
            this.state = new State();
            setState(state);
        };

        /**
         * Returns stored state
         *
         * @return stored state
         */
        private State getState() {
            return state;
        }

        /**
         * Sets internal state as current
         *
         * @param state internal state
         */
        private void setState(State state) {
            try {
                this.state = (State) state.clone();
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Returns new memento with current internal state
     *
     * @return new memento
     */
    public Memento getMemento() {
        return new Memento(state);
    }

    /**
     * Applies new memeneto to set the current state
     *
     * @param mem memento with internal state
     */
    public void setMemento(Memento mem) {
        state = mem.getState();
    }

    /**
     * Returns X coord
     *
     * @return x coord
     */
    public int getX() {
        return state.x;
    }

    /**
     * Sets X coord
     *
     * @param x x coord
     */
    public void setX(int x) {
        state.x = x;
    }

    /**
     * Returns Y coord
     *
     * @return y coord
     */
    public int getY() {
        return state.y;
    }

    /**
     * Sets Y coord
     *
     * @param y y coord
     */
    public void setY(int y) {
        state.y = y;
    }

    /**
     * Returns List with artefacts
     *
     * @return list with artefacts
     */
    public List getArtefacts() {
        return state.artefacts;
    }

    /**
     * Sets artefact list
     *
     * @param artefacts artefact list
     */
    public void setArtefacts(List artefacts) {
        state.artefacts = artefacts;
    }

    /**
     * Returns health value
     *
     * @return health value
     */
    public int getHealth() {
        return state.health;
    }

    /**
     * Sets health value
     *
     * @param health new health value
     */
    public void setHealth(int health) {
        state.health = health;
    }
}

/** Internal state class for Player */
class State implements Cloneable{
    /** X coord */
    int x;

    /** Y coord */
    int y;

    /** List of artefacts */
    List artefacts;

    /** Health value */
    int health;

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
