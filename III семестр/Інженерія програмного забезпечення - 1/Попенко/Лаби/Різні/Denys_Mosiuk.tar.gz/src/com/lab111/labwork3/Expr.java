package com.lab111.labwork3;

/**
 * Miltiplex expression with sign and two expressions
 * Has the component role in <i>Composite</i> 
 *
 * @author dector
 * @version 25 вер 2010 14:03:41
 */
public class Expr implements Expression {
    /** First expression */
    private Expression first;

    /** Second expression */
    private Expression second;

    /** Sign between expressions */
    private Sign sign;

    /** Just default constructor */
    public Expr(){
    }

    /**
     * Set expressions while initialize
     *
     * @param expr1 first expression
     * @param expr2 second expression
     */
    public Expr(Expression expr1, Expression expr2) {
        first = expr1;
        second = expr2;
    }

    /**
     * Sets sign between expressions
     * Use {@link Sign.PLUS}, {@link Sign.MINUS}, {@link Sign.MULTIPLY}, {@link Sign.DIVIDE}
     *
     * @param sign sign to set
     */
    public void setSign(Sign sign) {
        this.sign = sign;
    }

    /**
     * Returns stored sign
     *
     * @return sign
     */
    public Sign getSign() {
        return sign;
    }

    /**
     * Sets first expression
     *
     * @param expr expression to set
     */
    public void setFirstExpr(Expression expr) {
        first = expr;
    }

    /**
     * Returns first expression
     *
     * @return first expression
     */
    public Expression getFirstExpr() {
        return first;
    }

    /**
     * Sets second expression
     *
     * @param expr expression to set
     */
    public void setSecondExpr(Expression expr) {
        second = expr;
    }

    /**
     * Returns second expression
     *
     * @return second expression
     */
    public Expression getSecondExpr() {
        return second;
    }

    /**
     * In far future some parse may be here.
     * But not now
     *
     * @param value string to parse
     */
    public void setValue(String value) {
        // your parsing scheme may be here
    }

    /**
     * Returns current expression view
     * But first includes expressions count
     *
     * @return expression view  
     */
    public String getValue() {
        System.out.println("Expr.getValue()");
        StringBuilder s = new StringBuilder();
            s.append("(");
            s.append(first.getValue());
            s.append(sign.get());
            s.append(second.getValue());
            s.append(")");
        return s.toString();
    }
}
