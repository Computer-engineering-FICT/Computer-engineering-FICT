package com.lab111.labwork7;

import java.util.ArrayList;

/**
 * @author dector
 * @version 20.11.10 14:18
 */
public class Lab7 {
    public static void main(String[] args) {
        System.out.println("Creating player");
        Player player = new Player();
            player.setX(100);
            player.setY(50);
            player.setHealth(100);
            player.setArtefacts(new ArrayList());

        System.out.println("Creating controller");
        Controller ctr = new Controller(player);
        System.out.println();

        ctr.saveGame("full");
        ctr.draw("You feel yourself bad.");
        ctr.saveGame("bad");
        ctr.draw("The dog is growling.");
        player.setHealth(player.getHealth() - 7);
        ctr.draw("The dog bites you.");
        ctr.loadGame("full");
        ctr.draw("The light blessing you from atop. You feel yourself healthy!");
    }
}
