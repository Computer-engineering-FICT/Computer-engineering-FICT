package com.lab111.labwork6;

/**
 * Counts number of panels in panel
 *
 * @author dector
 * @version 14.11.10 12:17
 */
public class CountPanelsVisitor extends Visitor {
    private int number = -1;

    /**
     * Counts number of panels in panel and print result
     *
     * @param widget widget to visit
     */
    public void visitPanel(Widget widget) {
        countPanels(widget);
        System.out.println(number);
    }

    public void countPanels(Widget widget) {
        if (widget instanceof Panel) {

            if (widget.hasChildren()) {
                int sum = 1;
                Widget[] arr = widget.getChildren();

                for (int i = 0; i < arr.length; i++) {
                    countPanels(arr[i]);
                }
            }

            number++;
        }
    }
}
