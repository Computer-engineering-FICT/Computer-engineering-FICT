package com.lab111.labwork3;

/**
 * Just constant class to store constant ;)
 * <b>NOT</b> a part of <i>Composite</i>
 *
 * @author dector
 * @version 25 вер 2010 14:22:16
 */
public class Sign {
    /** PLUS constant */
    public static final String PLUS = "+";

    /** MINUS constant */
    public static final String MINUS = "-";

    /** MULTIPLY constant */
    public static final String MULTIPLY = "*";

    /** DIVIDE constant */
    public static final String DIVIDE = "/";

    /** His majesty sign! */
    private String sign;

    /** Default constructor */
    public Sign() {}

    /**
     * Set sign value while initialized
     *
     * @param sign sign to set
     */
    public Sign(String sign) {
        System.out.println("new Sign(\"" + sign + "\")");
        this.sign = sign;
    }

    /**
     * Sets sign
     *
     * @param sign sign
     */
    public void set(String sign) {
        System.out.println("Sign.set(\"" + sign + "\")");
        this.sign = sign;
    }

    /**
     * Returns sign
     *
     * @return sign
     */
    public String get() {
        System.out.println("Sign.get()");
        return sign;
    }
}
