package com.lab111.labwork8;

/**
 * DFS Iterator for composite
 *
 * @author dector
 * @version 28.11.10 17:00
 */
public class DFSIterator implements Iterator {
    /**
     * Init iterator on current element
     *
     * @param element current element
     */
    public DFSIterator(Element element) {
        System.out.println("Creating DFSIterator");
    }

    /**
     * Has structure next element?
     *
     * @return true if yes, else false
     */
    public boolean hasNext() {
        System.out.println("DFSIterator.hasNext()");
        return false;
    };


    /**
     * Return next element
     *
     * @return next element
     */
    public Element next() {
        System.out.println("DFSIterator.next()");
        return null;
    };
}
