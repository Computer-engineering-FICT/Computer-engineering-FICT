package com.lab111.labwork8;

/**
 * Creator for DFS Iterator
 *
 * @author dector
 * @version 28.11.10 17:05
 */
public class DFSICreator extends IteratorCreator {
    /**
     * Return DFSIterator
     *
     * @param element composite element
     * @return DFSIterator
     */
    public Iterator createIterator(Element element) {
        System.out.println("DFSICreator.createIterator() call");
        return new DFSIterator(element);
    }
}


