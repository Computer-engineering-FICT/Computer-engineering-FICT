package com.lab111.labwork9;

/**
 * @author dector
 * @version 29.11.10 0:12
 */
public class Lab9 {
    public static void main(String[] args) {
        Director director = new Director();
        GraphicsBuilder b = new GraphicsBuilder();

        director.setBuilder(b);
        director.construct("fakefile.in");
        Graphics g = b.getGraphics();
    }
}
