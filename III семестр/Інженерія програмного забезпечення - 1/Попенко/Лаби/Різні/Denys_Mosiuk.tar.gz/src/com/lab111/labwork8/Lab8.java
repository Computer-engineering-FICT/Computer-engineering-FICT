package com.lab111.labwork8;

/**
 * @author dector
 * @version 28.11.10 17:20
 */
public class Lab8 {
    public static void main(String[] args) {
        Element root = new Composite();
        root.addChild(new Leaf());

        Element child = new Composite();
        child.addChild(new Composite());
        child.addChild(new Leaf());

        root.addChild(child);

        root.getIterator(new DFSICreator());
        System.out.println("Iteration....");

        root.getIterator(new BFSICreator());
        System.out.println("Iteration....");

        System.out.println("The end!");
    }
}
