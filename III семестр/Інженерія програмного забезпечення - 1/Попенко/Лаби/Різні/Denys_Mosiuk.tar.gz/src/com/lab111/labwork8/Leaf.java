package com.lab111.labwork8;

/**
 * Leaf element in composite structure
 *
 * @author dector
 * @version 28.11.10 15:22
 */
public class Leaf implements Element{
    /** LEAF HAS NO CHILDREN! */
    public void addChild(Element child) {}

    /** LEAF HAS NO CHILDREN! */
    public Element getChild(int n) {
        return null;
    }

    /** LEAF HAS NO CHILDREN! */
    public void rmChild(int n) {}

    /** LEAF HAS NO CHILDREN! */
    public Iterator getIterator(IteratorCreator creator) {
        return null;
    }
}
