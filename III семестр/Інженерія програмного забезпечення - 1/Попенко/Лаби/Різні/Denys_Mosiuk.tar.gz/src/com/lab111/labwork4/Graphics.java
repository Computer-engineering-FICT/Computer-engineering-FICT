package com.lab111.labwork4;

/**
 * @author dector
 * @version 26 вер 2010 21:24:01
 */
public class Graphics {
    /** Transperency level. 1.0 = invisible, 0.0 = full visibility */
    private double tr;
    /** X coord */
    private int x;
    /** Y coord */
    private int y;
    /** Image width */
    private int width;
    /** Image height */
    private int height;

    /**
     * Sets Transperency level:
     * 1.0 = invisible;
     * 0.0 = full visibility.
     *
     * @param tr transperency level
     */
    public void setTransperency(double tr) {
        System.out.println("Graphics.setTransperency(" + tr + ")");
        this.tr = tr;
    }

    /**
     * Returns Transperency level:
     * 1.0 = invisible;
     * 0.0 = full visibility.
     *
     * @return transperency level
     */
    public double getTransperency() {
        System.out.println("Graphics.getTransperency()");
        return tr;
    }

    /**
     * Sets image position
     *
     * @param x x coord
     * @param y y coord
     */
    public void setPosition(int x, int y) {
        System.out.println("Graphics.setPosition(" + x + "," + y + ")");
        this.x = x;
        this.y = y;
    }

    /**
     * Returns X coord
     *
     * @return X coord
     */
    public int getX() {
        System.out.println("Graphics.getX()");
        return x;
    }

    /**
     * Returns Y coord
     *
     * @return Y coord
     */
    public int getY() {
        System.out.println("Graphics.getY()");
        return y;
    }

    /**
     * Sets image size
     *
     * @param width width
     * @param height height
     */
    public void setSize(int width, int height){
        System.out.println("Graphics.setSize(" + width + "," + height + ")");
        this.width = width;
        this.height = height;
    }

    /**
     * Returns image width
     *
     * @return image width
     */
    public int getWidth() {
        System.out.println("Graphics.getWidth()");
        return width;
    }

    /**
     * Returns image height
     *
     * @return image height
     */
    public int getHeight() {
        System.out.println("Graphics.getHeight()");
        return height;
    }

    /** Draw image on screen */
    public void draw() {
        System.out.println("Graphics.draw() ==> tr=" + tr);
    }
}
