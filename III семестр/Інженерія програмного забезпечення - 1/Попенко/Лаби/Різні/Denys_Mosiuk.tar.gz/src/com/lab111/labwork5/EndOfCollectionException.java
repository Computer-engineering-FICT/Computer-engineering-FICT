package com.lab111.labwork5;

/**
 * @author dector
 * @version 30.10.10 20:24
 */
public class EndOfCollectionException extends Exception{
    public EndOfCollectionException() {
        super();
    }

    public EndOfCollectionException(String s) {
        super(s);
    }
}
