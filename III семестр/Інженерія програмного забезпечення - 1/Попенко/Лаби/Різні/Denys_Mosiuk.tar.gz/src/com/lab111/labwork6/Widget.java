package com.lab111.labwork6;

/**
 * Core system widget
 *
 * @author dector
 * @version 14.11.10 12:12
 */
public abstract class Widget {
    /**
     * Add child widget
     *
     * @param widget
     */
    public void add(Widget widget) {};

    /**
     * Remove child widget
     *
     * @param widget
     */
    public void rm(Widget widget) {};

    /**
     * Returns array of children without included children in children
     *
     * @return array of children widgets
     */
    public Widget[] getChildren() {return new Widget[0];};

    /**
     * Returns <b>true</b> if has children widgets, else <b>false</b>
     *
     * @return has children widgets?
     */
    public boolean hasChildren() {return false;};

    /**
     * Accept new Visitor
     *
     * @param v acceptable Visitor
     */
    public abstract void accept(Visitor v);
}
