package com.lab111.labwork8;

import java.util.ArrayList;
import java.util.List;

/**
 * Composite element
 *
 * @author dector
 * @version 28.11.10 15:09
 */
public class Composite implements Element {
    private List<Element> children;

    /** Default constructor */
    public Composite() {
        children = new ArrayList<Element>();
    }

    /**
     * Add child to composite
     *
     * @param element child
     */
    public void addChild(Element element) {
        System.out.println("Adding new element to composite: " + element);
        children.add(element);
    };

    /**
     * Return child in composite
     *
     * @param n child number
     * @return child
     */
    public Element getChild(int n) {
        System.out.println("Returning child from composite with num: " + n);
        return children.get(n);
    }

    /**
     * Remove child from composite
     *
     * @param n number of child
     */
    public void rmChild(int n) {
        System.out.println("Removing child from composite with num: " + n);
        children.remove(n);
    }

    /**
     * Return iterator for composite structure
     *
     * @param creator concrete factory method class
     * @return specific iterator
     */
    public Iterator getIterator(IteratorCreator creator) {
        System.out.println("Composite.getIterator() call with " + creator.getClass());
        return creator.createIterator(this);
    }
}
