package com.lab111.labwork9;

/**
 * Leaf element
 *
 * @author dector
 * @version 28.11.10 23:37
 */
public class Text implements Graphics {
    /** HAS NO CHILDREN */
    public void add(Graphics g) {}

    /** HAS NO CHILDREN */
    public Graphics get(int n) {
        return null;
    }

    /** HAS NO CHILDREN */
    public void rm(int n) {}
}
