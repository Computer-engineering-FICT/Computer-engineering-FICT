package com.lab111.labwork3;

/**
 * Just variable class to store variable's name ;)
 * Role in <i>Composite</i>: leaf
 *
 * @author dector
 * @version 25 вер 2010 14:20:12
 */
public class Variable implements Expression{
    /** Variable name */
    private String value;

    /** Default constructor */
    public Variable() {}

    /**
     * Set variable's name while initialized
     *
     * @param value variables name
     */
    public Variable(String value) {
        System.out.println("new Variable(\"" + value + "\")");
        this.value = value;
    }

    /**
     * Sets variable name
     *
     * @param value variable name
     */
    public void setValue(String value) {
        System.out.println("Variable.setValue(\"" + value + "\")");
        this.value = value;
    }

    /**
     * Returns variable name
     *
     * @return variable name
     */
    public String getValue() {
        System.out.println("Variable.getValue()");
        return "(" + value + ")";
    }
}
