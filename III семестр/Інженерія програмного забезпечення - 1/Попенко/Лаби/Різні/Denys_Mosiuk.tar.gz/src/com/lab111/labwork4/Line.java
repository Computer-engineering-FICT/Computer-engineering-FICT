package com.lab111.labwork4;

/**
 * Straight line
 *
 * @author dector
 * @version 26 вер 2010 21:25:30
 */
public class Line {

    /** Opacity: 1.0 = full visibility, 0.0 = not visible */
    private double op;

    /** Coordinate X1 (start)*/
    private int x1;
    /** Coordinate Y1 (start)*/
    private int y1;
    /** Coordinate X2 (end)*/
    private int x2;
    /** Coordinate Y2 (end)*/
    private int y2;

    /**
     * Sets opacity:
     * 1.0 = full visibility;
     * 0.0 = not visible.
     *
     * @param op opacity level
     */
    public void setOpacity(double op) {
        System.out.println("Line.setOpacity(" + op + ")");
        this.op = op;
    }

    /**
     * Returns opacity:
     * 1.0 = full visibility;
     * 0.0 = not visible.
     *
     * @return opacity level
     */
    public double getOpacity() {
        System.out.println("Line.getOpacity()");
        return op;
    }

    /**
     * Sets coordinates of start and end of line
     *
     * @param x1 x for start
     * @param y1 y for start
     * @param x2 x for end
     * @param y2 y for end
     */
    public void setCoordinates(int x1, int y1, int x2, int y2) {
        System.out.println("Line.setCoordinates(" + x1 + y1 + x2 + y2 + ")");
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    /**
     * Draw line on screen
     */
    public void draw() {
        System.out.println("Line.draw() ==> op="+op);
    }
}
