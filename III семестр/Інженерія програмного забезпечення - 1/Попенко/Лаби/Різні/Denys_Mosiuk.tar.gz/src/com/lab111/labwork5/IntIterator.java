package com.lab111.labwork5;

/**
 * Iterator for integer collection
 *
 * @author dector
 * @version 30.10.10 19:19
 */
public interface IntIterator {
    /** Set first element of collection as current */
    public void toFirst();
    /** Get next element from collection */
    public IntEl next() throws EndOfCollectionException;
    /** Returns true if collection has next element, else false */
    public boolean hasNext();
}
