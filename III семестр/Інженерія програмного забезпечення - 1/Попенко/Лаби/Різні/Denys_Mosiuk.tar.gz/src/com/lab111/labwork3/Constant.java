package com.lab111.labwork3;

/**
 * Just constant class to store constant ;)
 * Role in <i>Composite</i>: leaf
 *
 * @author dector
 * @version 25 вер 2010 14:15:08
 */
public class Constant implements Expression {
    /** Stored constant */
    private int value;

    /** Default constructor */
    public Constant(){}

    /**
     * Set constant value while initialized
     *
     * @param value constant
     */
    public Constant(String value) {
        System.out.println("new Constant(\"" + value + "\")");
        this.value = Integer.parseInt(value);
    }

    /**
     * Set constant value while initialized
     *
     * @param value constant
     */
    public Constant(int value) {
        System.out.println("new Constant(" + value + ")");
        this.value = value;
    }

    /**
     * Sets constant value
     *
     * @param value constant value to set
     */
    public void setValue(String value) {
        System.out.println("Constant.setValue(\"" + value + "\")");
        this.value = Integer.parseInt(value);
    }

    /**
     * Sets constant value
     *
     * @param value constant value to set
     */
    public void setValue(int value) {
        System.out.println("Constant.setValue(" + value + ")");
        this.value = value;
    }

    /**
     * Returns constant value with braces
     *
     * @return constant expression
     */
    public String getValue() {
        System.out.println("Constant.getValue()");
        return "(" + String.valueOf(value) + ")";
    }
}
