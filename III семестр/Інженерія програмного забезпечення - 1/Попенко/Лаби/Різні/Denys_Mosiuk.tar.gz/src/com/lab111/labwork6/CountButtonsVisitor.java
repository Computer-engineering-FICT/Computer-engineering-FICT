package com.lab111.labwork6;

/**
 * Counts number of buttons in panel
 *
 * @author dector
 * @version 14.11.10 12:16
 */
public class CountButtonsVisitor extends Visitor {
    private int number = 0;

    /**
     * Counts number of buttons in panel and print result
     *
     * @param widget widget to visit
     */
    public void visitPanel(Widget widget) {
        countButtons(widget);
        System.out.println(number);
    }

    private void countButtons(Widget widget) {
        if (widget instanceof Button) {
            number++;
        }

        else {
            if (widget.hasChildren()) {
                Widget[] arr = widget.getChildren();

                for (int i = 0; i < arr.length; i++) {
                    countButtons(arr[i]);
                }
            }
        }
    }
}
