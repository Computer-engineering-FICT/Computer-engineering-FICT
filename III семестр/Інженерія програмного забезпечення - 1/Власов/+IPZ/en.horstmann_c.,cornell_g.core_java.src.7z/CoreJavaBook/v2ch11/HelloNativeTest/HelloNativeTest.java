/**
   @version 1.10 1997-07-01
   @author Cay Horstmann
*/

class HelloNativeTest
{  
   public static void main(String[] args)
   {  
      HelloNative.greeting();
   }
}
