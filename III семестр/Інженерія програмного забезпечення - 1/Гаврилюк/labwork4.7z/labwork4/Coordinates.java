package com.lab111.labwork4;

/**
 * @author Oleksii Havanchuk
 *
 * Class of coordinates of a pixel
 */
public class Coordinates {
	
	public int x;
	public int y;
	
	public Coordinates(int x0, int  y0){
		this.x = x0;
		this.y = y0;
	}

}

