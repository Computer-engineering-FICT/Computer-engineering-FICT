package com.lab111.labwork4;

/**
 * @author Oleksii Havanchuk
 *
 */

public interface Point {
	
	void draw(Coordinates coord);

}
