package com.lab111.labwork6;

public class Test {
public static void main (String [] args){
	Strategy Dec= new Decard();
	Function F = new Function(Dec);
	
	F.Visualize();
	
	Strategy pol = new Polar();
	Function z = new Function(pol);
	
	z.Visualize();
	
	
}
}
