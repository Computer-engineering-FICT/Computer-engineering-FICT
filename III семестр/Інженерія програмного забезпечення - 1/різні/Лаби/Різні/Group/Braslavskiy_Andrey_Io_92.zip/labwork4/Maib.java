package com.lab111.labwork4;

public class Maib {
 public static void main (String [] args){
	 Rectangle b = new Rectangle();
	 b.RectangleDraw(10,10,10,10,10,10);
 }
}
