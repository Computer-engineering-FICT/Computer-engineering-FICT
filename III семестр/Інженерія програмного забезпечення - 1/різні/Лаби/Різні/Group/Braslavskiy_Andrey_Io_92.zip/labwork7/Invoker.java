package com.lab111.labwork7;
/**
 * Invoker claSS
 * Called Command for changing information about persons
 * @author dron
 *
 */
public class Invoker {
	public static void main(String [] args){
		Table Andrey = new Table("Andrey","Braslavskiy" ,18);
		Table Roman = new Table("Roman","Panchenko","student",19);
		System.out.println("The object's before calling execute() ");
		Andrey.ShowInformation();
		ChangeJobandAge tmp = new ChangeJobandAge("worker", 20, Andrey);
		tmp.execute();
		Andrey.ShowInformation();
		System.out.println("The object's before calling execute() ");
		Roman.ShowInformation();
		ChangeJobandAge tmp2 = new ChangeJobandAge("worker", 20, Roman);
		tmp2.execute();
		Roman.ShowInformation();


	}
}
