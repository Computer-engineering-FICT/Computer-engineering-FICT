package com.lab111.labwork7;
/**
 * This class perfor transaction function

 * @author dron
 *
 */
public class ChangeJobandAge implements Command {
	public Table ChangingTable;
	/**
	 * variable for a newJob
	 */
	public String newJob;
	/**
	 * variable for a newAge
	 */
	public int newAge;
	/**
	 * variable to save history for transaction

	 */
	public int PreviousAge;
	/**
	 * variable to save history for transaction
	 */
	public String PreviousJob;
	public String b="null";
	
	/**
	 * Constructor for initialization variables
	 * @param job - newJob
	 * @param Age -newAge
	 * @param table - Object for changing
	 */
	public ChangeJobandAge(String job,int Age,Table table){
		this.ChangingTable=table;
		this.newJob=job;
		this.newAge=Age;
		this.PreviousAge=table.GetAge();
		this.PreviousJob=table.GetJob();
	}
	/**
	 * Method for returning previous values
	 */
	public void unexecute(){
		System.out.println("Nothing is changing");
		ChangingTable.SetAge(PreviousAge);
	}
	/**
	 * Command method to changing values and doing trasaction
	 */
public void execute(){
	ChangingTable.SetAge(newAge);

	if(PreviousJob==null)
{
		System.out.println("was changing");
	ChangingTable.SetJob(newJob);
	}
	else {
		unexecute();
	}
	
}
}
