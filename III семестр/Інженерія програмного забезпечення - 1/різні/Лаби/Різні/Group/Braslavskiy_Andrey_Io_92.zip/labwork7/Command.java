package com.lab111.labwork7;
/**
 * interface with unexecute and execute methods
 * @author dron
 *
 */
public interface Command {
public void execute();
public void unexecute();
}
