package com.lab111.labwork7;
/**
 * Class Table - information about a person
 * @author dron
 *
 */
public class Table {
	/**
	 * Person name
	 */
	String name;
	/**
	 * Person surname
	 */
	String surname;
	/**
	 * Person major
	 */
	String job;
	/**
	 * Person age
	 */
	int age;
	/**
	 * Constructor
	 */
public Table(){};

/**
 * Constructor
 * @param n -name
 * @param s - surname
 * @param a - age
 */
public Table(String n, String s,int a){
	this.name=n;
	this.surname=s;
	this.age=a;
}
/**
 * 
 * Constructor
 * @param n -name
 * @param s - surname
 * @param a - age
 * @param j -major

 */
public Table(String n, String s,String j,int a){
	this.name=n;
	this.surname=s;
	this.job=j;
	this.age=a;
}
/**
 * Set Person Name
 * @param n
 */
public void SetName(String n){
	this.name=n;
}
/**
 * Set Person SurName
 * @param s
 */
public void SetSurname(String s){
	this.surname=s;
}
/**
 * Set Person major
 * @param j
 */
public void SetJob(String j){
	this.job=j;
}
/**
 * Set Person Age
 * @param a
 */
public void SetAge(int a){
	this.age=a;
}
/**
 *  Get Pesron Name
 * @return
 */
public String GetName(){
	return this.name;
}
/**
 * Get Person SurNAme
 * @return
 */
public String GetSurname(){
	return this.surname;
}
/**
 * Get Person major
 * @return
 */
public String GetJob(){
	return this.job;
}
/**
 * Get PErson AGe
 * @return
 */
public int GetAge(){
	return this.age;
}
/**
 * Show all information about a person
 */
public void ShowInformation(){
	System.out.println("|name  -  "+GetName()+"  |surname  -  "+GetSurname()+"  |Major  -  "+GetJob()+"  |Age  -  "+GetAge()+"|");
}
}
