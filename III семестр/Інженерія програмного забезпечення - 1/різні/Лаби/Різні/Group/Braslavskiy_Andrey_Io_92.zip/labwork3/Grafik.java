package com.lab111.labwork3;

public class Grafik {

}
