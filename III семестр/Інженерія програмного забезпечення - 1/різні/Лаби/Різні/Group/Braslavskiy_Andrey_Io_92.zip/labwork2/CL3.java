package com.lab111.labwork2;
/**
 * 
 * @author Andrej
 *This class have methods to print class-name
 */
public class CL3 implements if3 {
	/**
	 * Print name of the third class
	 */
	 public  void meth3() {
		 System.out.println("The name of this class is CL3");
		 System.out.println("The name of this method is meth3");
	}
		/**
		 * Print name of the second class
		 */
	 public void meth2() {
		 System.out.println("The name of this class is CL2");
		 System.out.println("The name of this method is meth2");
	}
	 public if1 fieldif1;
}
