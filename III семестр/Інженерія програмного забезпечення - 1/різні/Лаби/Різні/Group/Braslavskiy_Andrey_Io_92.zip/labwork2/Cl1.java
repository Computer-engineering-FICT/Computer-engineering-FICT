package com.lab111.labwork2;
/**
 * 
 * @author Andrej
 *This class have methods to print class-name
 */

public class Cl1 extends Cl2  implements if1  {
	/**
	 * Print name of the first class
	 */
	 public void meth1() {
		 System.out.println("The name of this class is CL1");
		 System.out.println("The name of this method is meth1");

	}
	 /**
	  *  Print name of the third class
	  */
	 public  void meth3() {
		 System.out.println("The name of this class is CL3");
		 System.out.println("The name of this method is meth3");
	}
	 /**
	  * Aggregation field
	  */
	 public Cl1 fieldclass1;
	 
}
