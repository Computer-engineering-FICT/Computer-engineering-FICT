package com.lab111.labwork2;
/**
 * 
 * @author Andrey
 * interface if1
 * include meth1() and extends if3
 */

public interface if1 extends if3{
public void meth1();
/**
 * First class field
 */
/*public Cl1 fieldclass1;*/
}
