package com.lab111.labwork2;
/**
 * 
 * @author Admin
 * interface if1
 * include meth2()
 */

public interface if2  {
public void meth2();
}
