package com.lab111.labwork2;
/**
 * 
 * @author Andrej
 *This class have methods to print class-name
 */
public class Cl2  implements if2 {
	/**
	 * Print name of the second class
	 */
	 public void meth2() {
		 System.out.println("The name of this class is CL2");
		 System.out.println("The name of this method is meth2");
	}
	 public Cl1 fieldclass1;
}