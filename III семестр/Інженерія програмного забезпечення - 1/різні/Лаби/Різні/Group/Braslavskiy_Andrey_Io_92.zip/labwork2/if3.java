package com.lab111.labwork2;
/**
 * 
 * @author Admin
 * interface if1
 * include meth2() and extends second interface
 */
public interface if3 extends if2{
public void meth3();


}
