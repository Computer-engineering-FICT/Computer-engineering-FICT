package com.lab111.labwork8;
/**
 * perfom mul operation
 * @author dron
 *
 */
public class Mul implements Expression {
	/**
	 * left value
	 */
  private Expression lhs;
	/**
	 * right value
	 */
  private Expression rhs;
  /**
   * Constructor for mul
   * @param lhs
   * @param rhs
   */
  public Mul(Expression lhs, Expression rhs) {
    this.lhs = lhs;
    this.rhs = rhs;
  }
  /**
   * perfoming method
   */
  public int calc() {
    return this.lhs.calc() * this.rhs.calc();
  }
}
