package com.lab111.labwork8;
public class Num implements Expression {
  private int num;
/**
 * Constructor
 */
  public Num(int num) {
    this.num = num;
  }
  /**
   * perfoming method
   */
  public int calc() {
    return this.num;
  }
}