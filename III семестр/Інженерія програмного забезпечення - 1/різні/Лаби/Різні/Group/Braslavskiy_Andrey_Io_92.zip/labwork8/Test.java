package com.lab111.labwork8;


public class Test {
	 public static void main(String[] args) {
		 Siglenton g,e;
		 g=Siglenton.instense();
		 g.addValue("x", new Num(6));
		 g.addValue("y", new Num(2));
		 g.addValue("z", new Num(3));
		    System.out.println("Get result with G ValueMap  "+
		        new Mul(new Minus(g.getValue("x"), g.getValue("y")),
		          new Add(g.getValue("x"), g.getValue("z"))).calc());
		    e=Siglenton.instense();
		    System.out.println("Get result with e ValueMap, that was crieted aftet G ValueMap and it's his clone  "+
			        new Mul(
			          new Minus(e.getValue("x"), e.getValue("y")),
			          new Add(e.getValue("x"), e.getValue("z"))).calc());
		    

		  }
	

}
