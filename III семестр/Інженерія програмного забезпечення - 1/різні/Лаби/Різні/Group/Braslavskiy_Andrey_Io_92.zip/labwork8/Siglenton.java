package com.lab111.labwork8;

import java.util.HashMap;
/**
 * Class for created only one variable card
 */

public class Siglenton {
	static private Siglenton instance;
    private HashMap<String,Num> map = new HashMap<String,Num>(); 
	/**
	 * Class constructor
	 */
	 Siglenton() {
	}
	/**
	 * Map Constructot for creating only one map
	 * @return
	 */
	public static Siglenton  instense(){
		if (instance == null) {
			instance = new Siglenton();
			}
		return instance;
		}
		/**
		 * Method for add new value to the map
		 * @param name
		 * @param value
		 */
	public void addValue(String name,Num value){
		map.put(name,value);
	}
	/**
	 * Method for Getting value by the name
	 * @param name
	 * @return
	 */
	public Num getValue(String name){
		return map.get(name);
	}

	}