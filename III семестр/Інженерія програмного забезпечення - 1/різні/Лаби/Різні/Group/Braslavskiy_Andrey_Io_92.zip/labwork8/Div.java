package com.lab111.labwork8;
/**
 * perfom plus operation
 * @author dron
 *
 */
public class Div implements Expression {
	/**
	 * left value
	 */
  private Expression lhs;
	/**
	 * right value
	 */
  private Expression rhs;
  /**
   * Constructor for div
   * @param lhs
   * @param rhs
   */
  public Div(Expression lhs, Expression rhs) {
    this.lhs = lhs;
    this.rhs = rhs;
  }
  /**
   * perfoming method
   */
  public int calc() {
    return this.lhs.calc() / this.rhs.calc();
  }
}