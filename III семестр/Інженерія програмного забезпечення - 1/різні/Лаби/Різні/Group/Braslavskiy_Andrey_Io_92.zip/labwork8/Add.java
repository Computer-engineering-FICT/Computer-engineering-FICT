package com.lab111.labwork8;
/**
 * perfom plus operation
 * @author dron
 *
 */
public class Add implements Expression {
	/**
	 * left value
	 */
  private Expression lhs;
  /**
   * right value
   */
  private Expression rhs;
/**
 * Constructor for add
 * @param lhs
 * @param rhs
 */
  public Add(Expression lhs, Expression rhs) {
    this.lhs = lhs;
    this.rhs = rhs;
  }
/**
 * perfoming method
 */
  public int calc() {
    return this.lhs.calc() + this.rhs.calc();
  }
}