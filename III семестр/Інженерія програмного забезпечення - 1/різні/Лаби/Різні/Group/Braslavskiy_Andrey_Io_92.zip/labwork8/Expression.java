package com.lab111.labwork8;
/**
 * inerface for Math operations
 * @author dron
 *
 */
public interface Expression {
  public int calc();
}
