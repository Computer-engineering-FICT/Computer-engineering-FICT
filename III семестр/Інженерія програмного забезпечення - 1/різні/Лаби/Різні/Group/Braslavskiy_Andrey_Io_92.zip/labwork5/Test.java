package com.lab111.labwork5;

public class Test {

	public static void main (String [] args){
		
		Mediator M = new Mediator();
		Room[] rooms = new Room[10];
		for (int i=0;i<rooms.length;i++){
			rooms[i]=M.CreateRoom();
			
		}
		rooms[5].Entered();
		vuvod(rooms);
		System.out.println();
		rooms[8].Entered();
		vuvod(rooms);
		System.out.println();
		rooms[1].Entered();
		vuvod(rooms);
		
	}
	public static void vuvod(Room[] x){
		for (int i =0; i<x.length;i++){
			String b=x[i].GetState();
			System.out.print(+(i+1)+"  "+b+"  ");
		}
	}
}
