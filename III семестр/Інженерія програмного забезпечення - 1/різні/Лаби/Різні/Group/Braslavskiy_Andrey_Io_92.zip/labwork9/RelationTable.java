package com.lab111.labwork9;
/**
 * Class - Realtion table
 * @author dron
 *
 */
public class RelationTable {
/**
 * Filed for table
 */
private String relationtable[]=new String [4];

/**
 * Method for a table setting
 * @param l
 */
public void SetTable (String [] l){
	this.relationtable=l;
}
/**
 * Method for getting information
 */
public void GetTable(){
	for(int i=0;i<relationtable.length;i++){
	System.out.println(relationtable[i]);
	}
}
}
