package com.lab111.labwork9;
/**
 * Class for a Table Making
 * @author dron
 *
 */
public class Make {
	/**
	 * Reference for a concrete builder
	 */
	private REaltionBuilder relationbuilder;
	/**
	 * File for downloading information
	 */
	private String file []=new String [4];
    
	/**
	 * Concrete builder setter
	 * @param rb
	 */
	public void setRelationBuilder(REaltionBuilder rb) {
		relationbuilder = rb;
	}
	/**
	 * method for getting relation table
	 * @return
	 */
	public RelationTable getTable() {
		return relationbuilder.getTable();
	}
	/**
	 * method for getting information from file to a table
	 * this methods create a relation table object
	 * 
	 */
	public void constructTable() {
		file[0]="���           �������              ����� ";
		file[1]="Gerry Farish  (415)365-8775 127    Primrose Ave.,SF ";
		file[2]="Celia Brock   (707)874-3553 246    #3rd St.,Sonoma ";
		file[3]="Yves Grillet  (762)976-3665 778    Modernas,Barcelona";
		System.out.println("Download information from the file to the table");
		relationbuilder.createNewRelationTable();
		relationbuilder.buildinf(file);
		
	}


}
