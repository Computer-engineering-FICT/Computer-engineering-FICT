package com.lab111.labwork9;

public class BuilderExample {
	public static void main(String[] args) {
		Make make = new Make();
		REaltionBuilder buildTable = new Concretebiulder();
 
		make.setRelationBuilder(buildTable);
		make.constructTable();
		RelationTable  Table = make.getTable();
		Table.GetTable();

	}

}
