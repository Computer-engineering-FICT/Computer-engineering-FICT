package com.lab111.labwork9;
/**
 * Concrete builder for a relation table
 * @author dron
 *
 */
public  class Concretebiulder extends REaltionBuilder {
	public void buildinf(String[] l) {
		table.SetTable(l);
	}


}
