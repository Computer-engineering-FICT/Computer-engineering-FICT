package com.lab111.labwork9;
/**
 * Abstract class for a Concrete builders
 * @author dron
 *
 */
public abstract class REaltionBuilder {
	/**
	 * reference for an object RelationTable
	 */
	protected RelationTable table;
//	protected Record record;
public RelationTable getTable(){
	return table;
}
/**
 * Method for a creation RelationTable object
 */
public void createNewRelationTable() {
	table = new RelationTable();
}
/**
 * Abstract method for a building
 * It realized in a concrete builders
 * @param l
 */
public abstract void buildinf(String [] l);

}
