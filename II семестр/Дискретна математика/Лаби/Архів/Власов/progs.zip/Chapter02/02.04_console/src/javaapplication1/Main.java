/*
 * Main.java
 *
 * Created on 26.09.2007, 14:27:17
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication1;

/**
 *
 * @author V.Monakhov
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Привет!");
        try {
            System.in.read();
        } catch (Exception e) {
        }
    }
}