/*
 * Figure.java
 * 
 * Created on 03.07.2007, 14:13:23
 * 
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package java_gui_example;

/**
 *
 * @author �.�.�������
 */
public class Figure {

    public Figure() {
    }
    
    private int x=0;
    private int y=0;
    
}
