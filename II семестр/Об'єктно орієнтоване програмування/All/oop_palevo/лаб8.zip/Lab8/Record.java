import java.io.Serializable;
final class Record<T> implements Serializable{
	T data;
	Record<T> next;
	Record<T> prev;
	public Record(T data,Record<T> next, Record<T> prev){
		this.data=data;
		this.next=next;
		this.prev=prev;
	}
}
