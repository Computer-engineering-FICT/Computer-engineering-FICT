import java.io.Serializable;
public class Sea implements Serializable{
	private String Planet;
	private String Name;
	private double Promile;
	private boolean Exist;
	private String Countries;
	private String DropRivers;
	private double S;
	public final String GetPlanet(){
		return Planet;
	}
	public final void SetPlanet(String Planet){
		this.Planet=Planet;
	}
	public final String GetName(){
		return Name;
	}
	public final void SetName(String Name){
		this.Name=Name;
	}
	public final double GetPromile(){
		return Promile;
	}
	public final void SetPromile(double Promile){
		this.Promile=Promile;
	}
	public final boolean GetExist(){
		return Exist;
	}
	public final void SetExist(boolean Exist){
		this.Exist=Exist;
	}
	public final String GetCountries(){
		return Countries;	
	}
	public final void SetCountries(String Countries){
		this.Countries=Countries;
	}
	public final String GetDropRivers(){
		return DropRivers;	
	}
	public final void SetDropRivers(String DropRivers){
		this.DropRivers=DropRivers;
	}
	public final double GetS(){
		return S;
	}
	public final void SetS(double S){
		this.S=S;
	}
	public Sea(String Planet,String Name,double Promile,boolean Exist,String Countries, String DropRivers, double S) {
		SetPlanet(Planet);
		SetName(Name);
		SetPromile(Promile);
		SetExist(Exist);
		SetCountries(Countries);
		SetDropRivers(DropRivers);
		SetS(S);
	}
	public Sea(String Name,double Promile,boolean Exist,double S){
		this("Earth",Name,Promile,Exist,"None","None",S);
	}
	public Sea(){
		this("Unknown",0.0,false,Math.random());
	}
	public boolean equals(Object obj){
	    if(obj == this)
	    return true;
	    if(obj == null)
	    return false;
	    if((getClass() == obj.getClass())){
	    	Sea temp = (Sea)obj;
		     if(temp.Planet == this.Planet && temp.Name == this.Name && temp.Promile == this.Promile && temp.Exist == this.Exist && temp.Countries == this.Countries && temp.DropRivers == this.DropRivers && temp.S == this.S){
		    	 return true;
		     }		       
		     else return false;
	    }	   
	    else return false;
	  }
}
