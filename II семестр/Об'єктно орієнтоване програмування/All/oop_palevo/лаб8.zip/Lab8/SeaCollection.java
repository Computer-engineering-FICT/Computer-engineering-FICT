import java.util.ArrayList;
import java.io.Serializable;
class SeaCollection<T> implements Serializable{
	private int length=0;
	private Record<T> first;
	//private Record<T> last=first;
	public final int length(){
		return length;
	}
	SeaCollection(){
	}
	SeaCollection(T input){
		init(input);
	}
	SeaCollection(ArrayList<T> input){
		for(T elem : (T[]) input.toArray()){
		    add(elem);
		}
	}
	public boolean add(T input){
		if(first==null){
			init(input);
		}
		Record<T> cur=first,prev=first;
		while (cur != null){
			if (cur.data.equals(input)){
				return false; 
			}
			prev=cur;
			cur=cur.next;
		}
		cur=new Record<T>(input,null,prev);
		prev.next=cur;
		length++;
		return true;
	}
	public boolean remove(T input){
		Record<T> cur=first;
		while (cur != null){
			if (cur.data.equals(input)){
				if (cur.next==null && cur.prev==null){
					first=null;
					length=0;
					return true;
				}
				if (cur.next==null){
					cur.prev.next=null;
				}else{
					cur.next.prev=cur.prev;
				}
				if (cur.prev==null){
					first=cur.next;
				}else{
					cur.prev.next=cur.next;
				}
				length--;
				return true; 
			}
			cur=cur.next;
		}
		return false;
	}
	public boolean replace(T search, T input){
		Record<T> cur=first;
		while (cur != null){
			if (cur.data.equals(search)){
				cur.data=input;
				return true;
			}
			cur=cur.next;
		}
		return false;
	}
	public void write(){
		Record<T> cur=first;
		int i=1;
		while (cur != null){
			System.out.println("Record"+(i++)+":"+cur.data);         
			cur=cur.next;
		}
	}
	public T GetX(int n){
		Record<T> cur=first;
		for(int i=1;i<n;i++){
			cur=cur.next;
		}
		return cur.data;
	}
	private void init(T input){
		first=new Record<T>(input,null,null);
		length=1;
	}
}