import java.util.StringTokenizer;
import java.io.*;
public class Lab8 {
	public static void main(String[] args) {
		SeaCollection<Sea> sea=new SeaCollection<Sea>();
		for(int i=1;i<=10;i++){
			sea.add(new Sea());
		}
		SeaCollection<Sea> in=new SeaCollection<Sea>();
		SaveSequence(sea,"C:/temp.dat");
		LoadSequence("C:/temp.dat",in);
		SaveCollection(sea,"C:/temp.dat");
		LoadCollection("C:/temp.dat",in);
		Save(sea,"C:/temp.dat");
		Load("C:/temp.dat",in);
		in.write();
	}
	public static void Save(SeaCollection<Sea> coll,String fileName){
		try{
			PrintWriter stream=new PrintWriter(new FileWriter(fileName));
			Sea sea;
			for(int i=1;i<=coll.length();i++){
				sea=coll.GetX(i);
				stream.println(sea.GetPlanet()+"|"+sea.GetName()+"|"+sea.GetPromile()+"|"+sea.GetExist()+"|"+sea.GetCountries()+"|"+sea.GetDropRivers()+"|"+sea.GetS());
			}
			stream.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void Load(String fileName, SeaCollection<Sea> coll){
		try{
			BufferedReader stream=new BufferedReader(new FileReader(fileName));
			StringTokenizer st;
			while(stream.ready()){
				st=new StringTokenizer(stream.readLine(),"|");
				coll.add(new Sea(st.nextToken(),st.nextToken(),Double.parseDouble(st.nextToken()),Boolean.parseBoolean(st.nextToken()),st.nextToken(),st.nextToken(),Double.parseDouble(st.nextToken())));
			}
			stream.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void SaveSequence(SeaCollection<Sea> coll, String fileName){
		try{
			ObjectOutputStream stream=new ObjectOutputStream(new FileOutputStream(fileName));
			for(int i=1;i<=coll.length();i++){
				stream.writeObject(coll.GetX(i));
			}
			stream.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void LoadSequence(String fileName, SeaCollection<Sea> coll){
		try{
			FileInputStream file=new FileInputStream(fileName);
			ObjectInputStream stream=new ObjectInputStream(file);
			while(file.available()>0){
				coll.add((Sea) stream.readObject());
			}
			stream.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void SaveCollection(SeaCollection<Sea> coll,String fileName){
		try{
		    ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(fileName));
		    stream.writeObject(coll);
		    stream.close();
		}
		catch(Exception e){
		    e.printStackTrace();
		}
	}
	public static void LoadCollection(String fileName, SeaCollection<Sea> coll){
		try{			
		    ObjectInputStream stream = new ObjectInputStream(new FileInputStream(fileName));
		    coll=(SeaCollection<Sea>) stream.readObject();
		    stream.close();
		}
		catch(Exception e){
		    e.printStackTrace();
		}
	}
}
