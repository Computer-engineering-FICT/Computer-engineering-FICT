/**
 * @author Glushko Olga
 *
 */
public interface Scientist {

	public String getAcademicDegree();
	public void setAcademicDegree(String degree);
	public String getAcademicRank();
	public void setAcademicRank(String rank);
	public int getPublicationsNumber();
	public void setPublicationsNumber(int num);

}
