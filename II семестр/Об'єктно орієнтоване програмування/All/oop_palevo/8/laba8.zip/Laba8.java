import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

/**
 * @author Glushko Olga
 *
 */
public class Laba8 {

	/**
	 * Prints some properties of Academic object
	 * @param a an Academic object to print
	 * @param out a a stream for output
	 */
	public static void printAcademic(Academic a, PrintStream out) {
		out.print(a.getSurname());
		out.print("\t");
		out.print(a.getName());
		out.print("\t");
		out.print(a.getFacultee());
		out.print("\t");
		out.print(a.getCathedra());
		out.print("\t");
		out.println(a.getPosition());
	}

	/**
	 * Loads a serialized collection of objects from file
	 * @param filename file name to load from
	 * @return collection loaded from file
	 */
	public static AcademicArrayQueue loadAsSingleObject(String filename) {
		AcademicArrayQueue q2 = null;
		File file = new File(filename);
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			q2 = (AcademicArrayQueue)ois.readObject();
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return q2;
	}

	/**
	 * Stores (serializes) a collection to a file
	 * @param queue collection to store
	 * @param filename name of file to store to
	 * @return collection containing loaded objects
	 */
	public static void storeAsSingleObject(AcademicArrayQueue queue, String filename) {
		File file = new File(filename);
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(file);
			ObjectOutputStream oos;
			oos = new ObjectOutputStream(fos);
			oos.writeObject(queue);
			oos.close();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Loads a sequence of objects from file as a collection
	 * @param filename file name to load from
	 * @return collection containing loaded objects
	 */
	public static AcademicArrayQueue loadAsObjectsSequence(String filename) {
		AcademicArrayQueue q2 = new AcademicArrayQueue();
		File file = new File(filename);
		FileInputStream fis;
		Academic a;
		try {
			fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			while(fis.available() > 0) {
				a = (Academic)ois.readObject();
				q2.add(a);
			}
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		} catch (ClassNotFoundException e) {
		}
		return q2;
	}

	/**
	 * Stores (serializes) content of a collection to a file
	 * @param queue collection to store
	 * @param filename name of file to store to
	 */
	public static void storeAsObjectsSequence(AcademicArrayQueue queue, String filename) {
		File file = new File(filename);
		FileOutputStream fos;
		int i, length;
		Academic a;
		try {
			fos = new FileOutputStream(file);
			ObjectOutputStream oos;
			oos = new ObjectOutputStream(fos);
			length = queue.size();
			for (i=0; i<length; i++) {
				a = queue.poll();
				oos.writeObject(a);
				queue.add(a);
			}
			oos.close();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Loads a sequence of objects from CSV (comma separated values) file
	 * and returns them in a collection.
	 * @param filename
	 * @return collection containing loaded objects
	 */
	public static AcademicArrayQueue loadAsCSV(String filename) {
		AcademicArrayQueue q2 = new AcademicArrayQueue();
		Academic a;
		File file = new File(filename);
		FileReader fileReader;
		try {
			fileReader = new FileReader(file);
		} catch (FileNotFoundException e1) {
			return q2;
		}
		BufferedReader reader = new BufferedReader(fileReader);
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		String line;
		try {
			for(line=reader.readLine(); line != null; line=reader.readLine()) {
				/* Setup a scanner which will break a line on parts by delimiter
				 * following calls to scanner.next() will return the next part
				 * pattern "\\s*;\\s*" means: any number of whitespaces ("\\s*")
				 * followed by ';' followed by any number of whitespaces. More
				 * precisely, "\\s" means whitespace when '*' means "0 or more".
				*/ 
				Scanner scanner = new Scanner(line).useDelimiter("\\s*;\\s*"); 
				String surname, name, position, facultee, cathedra, date;
				surname = scanner.next();
				name = scanner.next();
				facultee = scanner.next();
				cathedra = scanner.next();
				position = scanner.next();
				// Well, now we know what the object's class is and can create
				// an object
				if ("���������".equals(position))
					a = new Assistant(surname, name);
				else if ("������".equals(position))
					a = new Docent(surname, name);
				else if ("���������".equals(position))
					a = new Professor(surname, name);
				else return null;
				// Just fill remaining fields
				a.setPosition(position);
				a.setFacultee(facultee);
				a.setCathedra(cathedra);
				a.setExperience(scanner.nextInt());
				a.setWorkbooksNumber(scanner.nextInt());
				date = scanner.next();
				try {
					a.setBirthdate(dateFormat.parse(date));
				} catch (ParseException e) {
					System.err.println("Error parsing date.");
					a.setBirthdate(null);
				}
				if (a instanceof Scientist) {
					Scientist sc = (Scientist)a;
					if (scanner.hasNext()) {
						sc.setAcademicDegree(scanner.next());
						if (scanner.hasNext()) {
							sc.setAcademicRank(scanner.next());
							if (scanner.hasNext())
								sc.setPublicationsNumber(scanner.nextInt());
						}
					}
				}
				// And add object to queue
				q2.add(a);
			}
		} catch (IOException e) {
			/* Nothing to do here since we always should return a collection
			 * containing successfully read elements */
		}
		return q2;
	}

	/**
	 * Stores content of a collection to a file in a CSV format
	 * @param queue collection to store
	 * @param filename name of file to store to
	 */
	public static void storeAsCSV(AcademicArrayQueue queue, String filename) {
		File file = new File(filename);
		FileOutputStream fos;
		int i, length;
		Academic a;
		Scientist sc;
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		try {
			fos = new FileOutputStream(file);
			PrintStream print = new PrintStream(fos);
			length = queue.size();
			for (i=0; i<length; i++) {
				a = queue.poll();
				print.print(a.getSurname());
				print.print(';');
				print.print(a.getName());
				print.print(';');
				print.print(a.getFacultee());
				print.print(';');
				print.print(a.getCathedra());
				print.print(';');
				print.print(a.getPosition());
				print.print(';');
				print.print(a.getExperience());
				print.print(';');
				print.print(a.getWorkbooksNumber());
				print.print(';');
				print.print(dateFormat.format(a.getBirthdate()));
				if (a instanceof Scientist) {
					sc = (Scientist)a;
					print.print(';');
					print.print(sc.getAcademicDegree());
					print.print(';');
					print.print(sc.getAcademicRank());
					print.print(';');
					print.print(sc.getPublicationsNumber());
				}
				print.println();
				queue.add(a);
			}
		} catch (IOException e) {
			return;
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		InteractiveAcademicReader reader = new InteractiveAcademicReader(System.in, System.out);
		Academic a;
		AcademicArrayQueue queue;
		int c, i, length;
		String s;
		queue = new AcademicArrayQueue();
		do {
			try { // to keep a style, also catch an IOException here
				a = reader.readAcademic();
				queue.add(a);
				System.out.print("Got an object. Read another one? ");
				s = reader.getReader().readLine();
				c = s.charAt(0);
				System.out.println();
			} catch (IOException e) {
				System.out.println("An I/O exception occured, exiting.");
				return;
			}
		} while (c == 'y');

		BufferedReader br = reader.getReader();
		AcademicArrayQueue loadedQueue;
		do {
			System.out.format("Ok, we've got %d objects. Now I can:\n", queue.size());
			System.out.println("1: store and load a collection as single object");
			System.out.println("2: store and load a collection as a sequence of objects");
			System.out.println("3: store and load a collection as text (CSV)");
			System.out.println("0 or q: quit");
			System.out.print("What should I do? ");
			try {
				s = br.readLine();
				c = s.charAt(0);
			} catch (IOException e) {
				System.out.println("Ooops, an IOException breaks our pleasure. Exiting.");
				c = 'q';
			}
			switch (c) {
				case '1':
					storeAsSingleObject(queue, "single");
					System.out.println("Stored in file named \"single\". Trying to load it back...");
					loadedQueue = loadAsSingleObject("single");
					length = loadedQueue.size();
					System.out.format("Loaded %d objects:\n", length);
					for (i=0; i<length; i++) {
						a = loadedQueue.poll();
						printAcademic(a, System.out);
					}
					break;
				case '2':
					storeAsObjectsSequence(queue, "seq");
					System.out.println("Stored in file named \"seq\". Trying to load it back...");
					loadedQueue = loadAsObjectsSequence("seq");
					length = loadedQueue.size();
					System.out.format("Loaded %d objects:\n", length);
					for (i=0; i<length; i++) {
						a = loadedQueue.poll();
						printAcademic(a, System.out);
					}
					break;
				case '3':
					storeAsCSV(queue, "academics.csv");
					System.out.println("Stored in file named \"academics.csv\". Trying to load it back...");
					loadedQueue = loadAsCSV("academics.csv");
					length = loadedQueue.size();
					System.out.format("Loaded %d objects:\n", length);
					for (i=0; i<length; i++) {
						a = loadedQueue.poll();
						printAcademic(a, System.out);
					}
					break;
				case '0':
				case 'q':
					break;
				default:
					System.out.println("Wrong choice. Have you learned a digits? Try again: ");
					break;
			}
		} while (c != '0' && c != 'q');
	}

}
