/*����� ���� ARRAYLIST ������� TOaRRAY ���������� � ����� ����Ҳ� � ���������� ����� ������ ADD*/
import java.util.ArrayList;

public class List{
	private Element Curr,Prev,Head;
	private int size=0;
	
	List (){
		Head=new Element();
	}
	
	List(Element e){
		this.Head=e;
	}
	
	List(TMount Mount){
		this();
		addToEnd(Mount);
	}
	
	List(TMount[]mas){
		this();
		addToEnd(mas);
	}
	
	boolean HasNext(Element e){
		return e.GetNext()!=null;
	}
	
	int GetSize (){
		return size;
	}
	
	Element GetCurr(){
		return Curr;
	}

	int next(){
		if (HasNext(Curr)==false){
			return -1;
		}else{
		Prev=Curr;
		Curr=Curr.GetNext();
		return 1;
		}
	}
	
	
	private int seek(int index,Element Prev,Element Next){
		if (index<0){
			System.out.println("Invalid Index");
			return -1;
		}else{
		for (int i=0;i<=index;i++)
			next();
			return 1;
		}
	}
	
	Element seek(int index){
		if (index<0){
			System.out.println("Invalid Index");
			return null;
		}else{
		for (int i=0;i<=index;i++)
			next();
			return GetCurr();
		}
	}
		
	private void add(TMount Mount,Element Prev,Element Next){
	Element e= new Element();
	e.SetMount(Mount);	
	Prev.SetNext(e);
	e.SetNext(Next);
	size++;
	}
	
	int addAfter(TMount Mount,int index){
		if (index<0 || chek (Mount)==-1){
			return -1;
		}else{
			Curr=Prev=Head;
			seek(index,Prev,Curr);
			add(Mount,Prev,Curr);
			return 1;
		}
	}
	
	int addAfter(TMount[] mas,int index){
		if (index<0){
			return -1;
		}else{
			for (TMount e:mas){
				if (addAfter(e,index)==1){
				addAfter(e,index);
				index++;
				}
			}
			return 1;
		}
	}
	
	void addAfter(ArrayList <TMount> L,int index){
		addAfter(L.toArray(new TMount[L.size()]),index);
	}
	
	void addToEnd(TMount Mount){
		addAfter(Mount,GetSize());
	}
	
	void addToEnd(TMount[] Mount){
		addAfter(Mount,GetSize());
	}
	
	
	private void replace(TMount Mount,Element Prev,Element Next){
		Element e= new Element();
		e.SetNext(Next.GetNext());
		Prev.SetNext(e);
	}
	
	int replacePos(TMount Mount,int index){
		if (index<0 || chek (Mount)==-1){
			return -1;
		}else{
			Curr=Prev=Head;
			seek(index,Prev,Curr);
			replace(Mount,Prev,Curr);
			return 1;
		}
	}
	
	int replacePos(TMount[] mas,int index){
		if (index<0){
			return -1;
		}else{
			for (TMount e:mas){
				if (replacePos(e,index)==1){
				replacePos(e,index);
				index++;
				}
			}
			return 1;
		}
	}
	
	void replacePos(ArrayList <TMount> L,int index){
		replacePos(L.toArray(new TMount[L.size()]),index);
	}
	
	private void remove(Element Prev,Element Next){
		Prev=Next.GetNext();
		size--;
	}
	
	void removePos(int index){
		if (index<0){
			
		}else{
		Curr=Prev=Head;
		seek(index,Prev,Curr);
		remove(Prev,Curr);
		}
	}
	
	void print(Element e){
		System.out.println(e.GetMount());
	}
	
	void output(){
		Curr=Prev=Head;
		for(int i=0;i<GetSize();i++){
			next();
			print(GetCurr());
		}
	}
	
	int chek (TMount Mount){
		for (int i=0;i<GetSize();i++){
			Curr=Prev=Head;
			seek(i,Prev,Curr);
			if(Mount.equals((TMount)GetCurr().GetMount())==true){
				return -1;
			}
		}
		return 1;
	}
}
