
public class TMount {
	private TName Name =new TName(); 
	private TCountry Country =new TCountry(); 
	private String Continent;
	private int Area;
	private int Higth;
	private int Length;
	private int N_of_caves;
    
	public final void SetName(String NameM){
		Name.SetName(NameM);
	}
	public final void SetContinent(String Continent){
		this.Continent=Continent;
	}
	public final void SetCountry(String CountryM){
		Country.SetCountry(CountryM);
	}
	public final void SetArea(int Area){
		this.Area=Area;
	}
	public final void SetHigth(int Higth){
		this.Higth=Higth;
	}
	public final void SetLength(int Length){
		this.Length=Length;
	}
	public final void SetN_of_caves(int N_of_caves){
		this.N_of_caves=N_of_caves;
	}
	public final String GetCountry(){
		return Country.GetCountry();
	}
	public final String GetName(){
		return Name.GetName();
	}
	public final String GetContinent(){
		return Continent;
	}
	public final int GetArea(){
		return Area;
	}
	public final int GetHigth(){
		return Higth;
	}
	public final int GetLength(){
		return Length;
	}
	public final int GetN_of_caves(){
		return N_of_caves;
	}
	public void Output(){
		System.out.println("Name: "+GetName());
		System.out.println("Country: "+GetCountry());
		System.out.println("Continent: "+GetContinent());
		System.out.println("Area: "+GetArea());
		System.out.println("Higth: "+GetHigth());
		System.out.println("Length: "+GetLength());
		System.out.println("N_of_caves: "+GetN_of_caves());
	}
	
	public TMount (String name,String Continent,String country,int Area,int Higth,int Length,int N_of_caves){
		Name.SetName(name);
		SetContinent(Continent);
		Country.SetCountry(country);
		SetArea(Area);
		SetHigth(Higth);
		SetLength(Length);
		SetN_of_caves(N_of_caves);
	}
	public TMount(){
		this(null,null,null,0,0,0,0);
	}
	public TMount(String NameM,String Continent,String CountryM){
		this(NameM,Continent,CountryM,0,0,0,0);
	}
	public TMount(int Area,int Higth,int Length,int N_of_caves){
		this(null,null,null,Area,Higth,Length,N_of_caves);
	}
}