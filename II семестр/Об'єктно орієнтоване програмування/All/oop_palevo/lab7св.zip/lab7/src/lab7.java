
public class lab7 {
 public static void main(String[] args){
	 TMount m = new TMount();
	 TMount l = new TMount("o","p","s");
	 List L=new List(m);
	 L.addAfter(l, -5);
	 L.addAfter(m, -2);
	 L.output();
	 System.out.println(L.GetSize());
 }
}
