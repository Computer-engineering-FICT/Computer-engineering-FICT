package lab5;


/**
* 
* @version 1 5 April 2014
* @author Gutov Vladislav
* 
* Объект класса <code>Text</code> содержит в себе массив предложений
*/
public class Text {
	private Sentence[] sentences;
	private char[] symbols;
	
	
	/**
	 * Конструктор класса <code>Text</code>
	 * Принимает строку типа <b>String</b>  разбивает ее на массив предложений
	*/
	public Text(String text){
				
		String[] tokens = text.split("!|\\.|\\?"); //регулярное выражение для сплита текста
		
		
		//в слудующих строках запоминаем знаки конца предложения (точки и т.д.)
		symbols = new char[tokens.length];
		int temp = 0;
		for(int i = 0; i < text.length(); i++)
			if(text.charAt(i) == '.' || text.charAt(i) == '!' || text.charAt(i) == '?'){
				symbols[temp] = text.charAt(i);
				temp++;
			}
		
		//заполняем массив предложений
		sentences = new Sentence[tokens.length];
		
		for(int i = 0; i < tokens.length; i++){
			sentences[i] = new Sentence(tokens[i]);
		}
		
	}
	
	public String toString(){
		String result = new String();
		for(int i = 0; i < symbols.length; i++){
			result+=sentences[i].toString();
			result+=symbols[i] + " ";
			
		}
		
		return result;
	}
	
	public Sentence[] getSentences(){
		return sentences;
	}
	
}
