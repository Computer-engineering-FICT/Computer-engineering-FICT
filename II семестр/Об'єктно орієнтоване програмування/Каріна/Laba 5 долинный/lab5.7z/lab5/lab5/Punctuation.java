package lab5;


/**
* 
* @version 1 5 April 2014
* @author Gutov Vladislav
* 
* Объект класса <code>Punctuation</code> содержит в себе поле <b>sign</b>
*/
//был унаследован от Element чтобы предложение хранило в себе как слова, так и знаки препинания
public class Punctuation extends Element{
	private char sign;

	
	/**
	 * Просто конструктор, ничего особенного
	*/
	public Punctuation(char sign){
		this.sign = sign;
	}
	
	@Override
	public boolean isPunctuation() {
		return true;
	}

	public char getSign() {
		return sign;
	}

	public void setSign(char sign) {
		this.sign = sign;
	}
	
	public void setSign(Punctuation sign){
		setSign(sign.getSign());
	}
	
	public String toString(){
		return Character.toString(sign);
	}
	
}
