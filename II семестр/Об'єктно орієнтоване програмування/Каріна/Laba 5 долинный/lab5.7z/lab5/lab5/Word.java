package lab5;


/**
* 
* @version 1 5 April 2014
* @author Gutov Vladislav
* 
* Объект класса <code>Word</code> содержит в себе массив букв
*/
//был унаследован от Element чтобы предложение хранило в себе как слова, так и знаки препинания
public class Word extends Element{
	private static final int FREE_SPACE = 5;
	
	private Letter[] letters;
	private int lastIndex;     //хранит количество элементов, чтобы невозможно было обратиться к несуществующему элементу
	
	
	//перегруженные конструкторы, ничего особенного
	public Word(char[] chars){
		setWord(chars);			
	}

	public Word(){
		this.letters = new Letter[FREE_SPACE];
		lastIndex = 0;
	}
	
	public Word(String word){
		setWord(word.toCharArray());
	}
	
	public Word(Word word){
		setWord(word.getLetter());
	}
	
	public Word(Letter[] letters){
		setWord(letters);
	}
	
	
	/**
	 * Возвращает <b>копию</b> слова
	*/
	public Word getWord(){
		return new Word(letters);
	}
	
	
	/**
	 * Удаляет символ из слова в указанной позиции. Если будет указано ошибочное место, ничего не выполнится
	 * @param place - позиция символа, который нужно удалить
	*/
	public void removeCharAt(int place){
		if(place >= 0 && place < lastIndex){  //проверка на корректность операции
			for(int i = place; i < lastIndex-1; i++)
				letters[i] = letters[i+1]; // сдвигаем все символы
			letters[lastIndex-1] = null; //последний символ затираем
			lastIndex--; //поскольку один символ был удален, сдвигаем границу
		}
	}
	
	/**
	 * Вставляет указаный символ в указанное место в слове. Если будет указано ошибочное место, ничего не выполнится
	 * @param place - позиция, куда нужно вставить
	 * @param ch - имвол, который вставляем
	*/
	public void insertCharAt(int place, char ch){   
		
		if(place >= 0 && place <= lastIndex){   //проверка на корректность операции
			
			if(lastIndex >= letters.length)   //если в массиве нет места,
				addSpace();					  //увеличить его размер
			
			for(int i = lastIndex; i > place; i--)
				letters[i] = letters[i-1];
			
			letters[place] = new Letter(ch);  //копируем символ
			
			lastIndex++;  
		}
	}
	
	/**
	 * @return <b>int</b> - длина слова
	*/
	public int lenght(){
		return lastIndex;
	}
	
	private void addSpace(){
		Letter[] buffer = letters;
		letters = new Letter[letters.length + FREE_SPACE];
		for(int i = 0; i < buffer.length; i++)
			letters[i] = buffer[i];
	}
	
	/**
	 * Возвращает символ из указанной позиции в слове, если результат некоректный, возвращает символ пробела
	 * @param place - позиция символа
	 * 
	 * @return <b>char</b> - символ в текущей позиции
	*/
	public char charAt(int place){
		if(place >= 0 && place < lastIndex)
			return letters[place].getSymbol();
		else
			return ' ';
	}
	
	
	/**
	 * Возвращает <b>копию</b> массива букв
	 * @return <b>Letter[]</b> - буквы
	*/
	public Letter[] getLetter(){
		Letter[] result = new Letter[lastIndex];
		
		for(int i = 0; i < lastIndex; i++)
			result[i] = new Letter(letters[i]);
		
		return result;
	}
	
	//Setters. Устанавливают только копии объектов
	public void setWord(Letter[] word){
		
		this.letters = new Letter[word.length + FREE_SPACE];
		
		for(int i = 0; i < word.length; i++)
			this.letters[i] = new Letter(word[i]);
		
		lastIndex = word.length;
	}
	public void setWord(char[] word){
		this.letters = new Letter[word.length + FREE_SPACE];
		
		for(int i = 0; i < word.length; i++)
			this.letters[i] = new Letter(word[i]);
		lastIndex = word.length;
	}

	
	@Override
	boolean isPunctuation() {
		return false;
	}
	
	public String toString(){
		String result = new String();
		for(int i = 0; i < lastIndex; i++)
			result += letters[i].toString(); 
		
		return result;
	}
	
}
