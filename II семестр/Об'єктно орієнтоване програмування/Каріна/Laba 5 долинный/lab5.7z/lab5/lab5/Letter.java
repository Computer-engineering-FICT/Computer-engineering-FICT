package lab5;


/**
* 
* @version 1 5 April 2014
* @author Gutov Vladislav
* 
* Объект класса <code>Letter</code> содержит в себе поле <b>symbol</b>
* Класс имитирует букву в слове
*/
public class Letter{
	private char symbol;

	
	/**
	 * Конструктор класса <code>Letter</code> <br>
	 * Просто конструктор, ничего особенного
	*/
	public Letter(char symbol){
		this.symbol = symbol;
	}
	
	/**
	 * Конструктор класса <code>Letter</code> <br>
	 * Используется для создания копии буквы
	*/
	public Letter(Letter symbol){
		this(symbol.getSymbol());
	}
	

	//Getter and Setters
	public char getSymbol() {
		return symbol;
	}
	public void setSymbol(char symbol) {
		this.symbol = symbol;
	}
	public void setSymbol(Letter symbol) {
		setSymbol(symbol.getSymbol());
	}
	
	@Override
	public String toString(){
		return Character.toString(symbol);
	}
	
}
