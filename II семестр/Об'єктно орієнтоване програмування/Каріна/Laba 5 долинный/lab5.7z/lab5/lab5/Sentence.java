package lab5;


/**
* 
* @version 1 5 April 2014
* @author Gutov Vladislav
* 
* Объект класса <code>Sentence</code> содержит в себе массив элементов(слова и знаки препинания)
*/
public class Sentence {
	private static final int FREE_SPACE = 5;
	private Element[] elements;
	private int count;
	
	/**
	 * Конструктор класса <code>Sentence</code>
	 * Принимает строку типа <b>String</b> без знаков нового предложения(точек, вопросительных знаков...)  
	*/
	public Sentence(String sentence){
		
		String[] tokens = sentence.split(" "); //разбиваем строку на слова и знаки препинания
		elements = new Element[tokens.length]; //начальное количество памяти
		count = 0;
		
		//проходим по всем словам
		for(int i = 0; i < tokens.length; i++){
			
			int j = 0;
			while(j < tokens[i].length()){
				
				if(count >= elements.length) //если место в массиве elements закончилось, увеличиваем
					addSpace();
				
				
				//если нашли знак препинания, добавляем его в массив
				if(tokens[i].charAt(j) == ',' || tokens[i].charAt(j) == '-'){
					elements[count] = new Punctuation(tokens[i].charAt(j));
					count++;
					j++; //переходим на следующий символ строки
				}
				
				
				
				Word buffer = new Word();
				
				//встретились буквы
				while(j < tokens[i].length() &&
					  ((tokens[i].charAt(j) >= 'a' && tokens[i].charAt(j) <= 'z') || 
					   (tokens[i].charAt(j) >= 'A' && tokens[i].charAt(j) <= 'Z') ||
					   (tokens[i].charAt(j) >= 'а' && tokens[i].charAt(j) <= 'я') ||
					   (tokens[i].charAt(j) >= 'А' && tokens[i].charAt(j) <= 'Я'))){
					buffer.insertCharAt(buffer.lenght(), tokens[i].charAt(j)); //вставляем букву в конец буффера
					j++;
					
				}
				
				//проверка, если буффер содержит хотя бы один элемент, добавляем его в массив
				if(buffer.lenght() > 0){
					elements[count] = buffer;
					count++;
				}
				
			}
				
			
		}
		
	}
	
	
	public int getLenght(){
		return count;
	}
	
	
	/**
	 * Метод возвращает <b>ссылку</b> на массив слов в предложении.
	 * @return Word[]
	*/
	public Word[] getWords(){
		int words = 0; 
		for(int i = 0; i < count; i++)
			if(!elements[i].isPunctuation())  //подсчитываем количество слов в массиве элементов
				words++;
		
		//выделяем память и запоминаем ссылки на слова
		Word[] result = new Word[words];
		int j = 0;
		for(int i = 0; i < count; i++)
			if(!elements[i].isPunctuation()){
				result[j] = (Word) elements[i];
				j++;
			}
		
		return result;
		
	}
	
	public String toString(){
		String result = new String();
		for(int i = 0; i < count; i++){
			result+=elements[i].toString();
			if(i+1 < count && !(elements[i+1].isPunctuation() && ((Punctuation) elements[i+1]).getSign() == ',')) //в этой строке проверяем чтобы не ставить пробел после запятой
				result+=" ";
		}
		return result;
	}
	
	private void addSpace(){
		Element[] buffer = elements;
		elements = new Element[elements.length + FREE_SPACE];
		for(int i = 0; i < buffer.length; i++)
			elements[i] = buffer[i];
	}
}
