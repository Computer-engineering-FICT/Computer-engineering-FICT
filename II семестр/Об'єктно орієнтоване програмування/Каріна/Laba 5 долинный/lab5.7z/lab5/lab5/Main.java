package lab5;

public class Main {

	public static void main(String[] args) {
		Text a = new Text("В дадддддддддднной лабораторной работе я ,научился работать со строками в языке Java... Научился использовать основные функции, для работы со строками! В данной лабораторной работе были обработаны все исключительные ситуации.");
		
		Sentence[] input = a.getSentences();
		
		for(Sentence current: input){
			Word[] tokens = current.getWords();
			
			
			for(Word cur: tokens){
				
				char buffer = Character.toLowerCase(cur.charAt(0));
				
				for(int i = 1; i < cur.lenght();)
					if(buffer == Character.toLowerCase(cur.charAt(i)))
						cur.removeCharAt(i);
					else
						i++;
				
				
				
				
			}
			
			
		}
		
		System.out.println(a.toString());
	}

}
