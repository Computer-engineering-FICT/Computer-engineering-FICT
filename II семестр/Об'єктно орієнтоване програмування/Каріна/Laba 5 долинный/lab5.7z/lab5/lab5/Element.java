package lab5;

public abstract class Element {
	abstract boolean isPunctuation();
}
