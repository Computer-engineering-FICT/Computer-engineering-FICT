public abstract class SentenceMember {
    public String str() {
        return "";
    }
    public int length() {
        return 0;
    }
}