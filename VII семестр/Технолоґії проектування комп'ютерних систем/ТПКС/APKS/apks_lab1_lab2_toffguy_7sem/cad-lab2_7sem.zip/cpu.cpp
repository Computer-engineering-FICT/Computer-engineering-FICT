//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#include <stdio.h>

#ifndef CPU
#include "cpu.h"
#define CPU
#endif

extern unsigned
	sys_time;

cpu::cpu()
{
	current_task = NULL;
};

bool cpu::idle()
{
	if (current_task == NULL) return true;
	else return false;
};

void cpu::set_task(task *new_task)
{
	current_task = new_task;
};

unsigned long cpu::need_time()
{
	if (current_task != NULL) return current_task->need_time;
	else return 0;
};

void cpu::work()
{
	if (current_task != NULL) current_task->used_time++;
	else return;

	if (current_task->used_time >= current_task->need_time)
	{
		flags |= CPU_READY;
		current_task->solved = true;
		current_task->dest = current_task->orig;
		current_task->orig = device_num;
		printf("%5d: cpu %d is sending answer to cpu %d\n", sys_time, current_task->orig, current_task->dest);
		r->send(current_task, current_task->dest);
		current_task = NULL;
	};
};

void cpu::bind(router *b_router, unsigned d)
{
	r = b_router;
	device_num = d;
};
