//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#ifndef CONST
#include "const.h"
#define CONST
#endif

#ifndef DEVICE
#include "device.h"
#define DEVICE
#endif

class blackbox
{
	unsigned
		ring[MAX_DEVS],
		ring_len,
		marker_owner,
		fake_marker_owner;
	task
		*task;
	bool
		busy;
	marker
		mark;

	void replace_marker();
public:
	blackbox();
	void add_device(device *, unsigned);
	void remove_device(unsigned);
	bool data_ready(marker *m);
	void work(device d[MAX_DEVS]);
};
