//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

class timer
{
	unsigned long
		time,
		interval;
	bool
		ir;
public:
	timer();
	void set_interval(unsigned long);
	void work();
	bool interrupt();
};
