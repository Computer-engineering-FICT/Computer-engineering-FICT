//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#include <stdio.h>

#ifndef BLACKBOX
#include "blackbox.h"
#define BLACKBOX
#endif

extern unsigned
	sys_time;

blackbox::blackbox()
{
	ring_len = 0;
	task = NULL;
};

/* add device to token bus */
void blackbox::add_device(device *d, unsigned dev_n)
{
	ring[ring_len] = dev_n;
	ring_len++;
	d->router.init(dev_n, &busy, &mark);
	printf("%5d: device %d is added to ring\n", sys_time, dev_n);
};

/* remove device from FDDI-ring */ 
void blackbox::remove_device(unsigned dev_n)
{
	unsigned
		i, j, k;

	for (i = 0; i < ring_len; i++)
		if (ring[i] == dev_n)
		{
			for (j = i; j < ring_len - i; j++)
				ring[j] = ring[j+1];
			ring_len--;
			printf("%5d: device %d is removed from ring\n", sys_time, dev_n);
			printf("%5d: ring: -> ", sys_time); 
			for (k = 0; k < ring_len; k++) printf("%d ", ring[k]);
			printf("->\n");
			break;
		};
};

/* if data placed in marker */
bool blackbox::data_ready(marker *m)
{
	m = &mark;

	if (task == NULL) return false;
	else return true;
};

/* give marker to the next device */
void blackbox::replace_marker()
{
	marker_owner++;
	if (marker_owner >= ring_len) marker_owner = 0;
};

/* blackbox (token bus device) main procedure */
void blackbox::work(device d[MAX_DEVS])
{
	unsigned
		i, dest;

	/* send data */
	if (task != NULL) 
	{
		if (task->solved) printf("%5d: answer from cpu %d to cpu %d is in channel now\n", sys_time, task->orig, task->dest);
		else printf("%5d: task from cpu %d to cpu %d is in channel now\n", sys_time, task->orig, task->dest);
		dest = task->dest;
		mark.dest = dest;
		mark.data_sent = 0;
		fake_marker_owner = marker_owner;
		for (i = marker_owner+1; i < marker_owner+ring_len+1; i++)
		{			
			fake_marker_owner++;
			if (fake_marker_owner >= ring_len) fake_marker_owner = 0;
			if (ring[fake_marker_owner] == task->dest)			
			{
				d[ring[fake_marker_owner]].router.recv(task);
				task = NULL;
				break;
			};
		};
		if (!mark.data_sent)
		{
			printf("%5d: no answer from device %d\n", sys_time, dest);			
			delete task;
			task = NULL;
			remove_device(dest);
		};
	};

	/* receive data */
	if (d[marker_owner].router.rts()) task = d[marker_owner].router.get_data();
	else replace_marker();
};
