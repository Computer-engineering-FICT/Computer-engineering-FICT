//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#ifndef BLACKBOX
#include "blackbox.h"
#define BLACKBOX
#endif

#include <windows.h>

device
	dev[MAX_DEVS];
blackbox
	box;
int 
	dev_cnt = 5,
	i;
unsigned 
	sys_time;

void main()
{		
	for (i = 0; i < dev_cnt; i++)
	{
		dev[i].init(i);	
		box.add_device(&dev[i], i);
	};

	while(1)
	{		
		sys_time++;
		for (i = 0; i < dev_cnt; i++)
			dev[i].work();
		box.work(dev);		
		Sleep(1000);
	};
};
