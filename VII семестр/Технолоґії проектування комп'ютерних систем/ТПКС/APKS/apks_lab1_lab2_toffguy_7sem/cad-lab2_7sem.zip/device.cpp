//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifndef DEVICE
#include "device.h"
#define DEVICE
#endif

extern unsigned
	sys_time;

device::device()
{
	srand((unsigned)time(NULL));
	operable = true;
};

/* init device */
void device::init(unsigned dev_num)
{
	number = dev_num;
	router.bind(&fifo);
	cpu.bind(&router, number);
};

/* interrupt handler */
void device::int_handler(int)
{			
	timer.set_interval(1);
	if (cpu.idle() && !fifo.empty())
	{
		cpu.set_task(fifo.get_task());
		cpu.flags |= !CPU_READY;
		timer.set_interval(cpu.need_time());
	};
};

/* device main procedure */
void device::work()
{
	timer.work();	
	if (timer.interrupt()) int_handler(0);
	cpu.work();

	gen_random();
};

void device::gen_random()
{
	int
		rnd;
	task
		*new_task;

	rnd = rand();
	if (rnd > RAND_MAX - RAND_MAX / 100 * 30 && operable)
	{
		new_task = new task;
		new_task->dest = number + rand() % 3;
		new_task->orig = number;
		new_task->need_time = rand() % 10 + 1;
		new_task->used_time = 0;
		new_task->solved = false;

		printf("%5d: task generated from device %d for device %d\n", sys_time, new_task->orig, new_task->dest);
		router.send(new_task, new_task->dest);
	};

	rnd = rand();
	if (rnd > RAND_MAX - RAND_MAX / 100 && operable)
	{
		shutdown();
		printf("%5d: device %d is shutting down\n", sys_time, number);
	};
};

void device::shutdown()
{
	operable = false;
	router.operable = false;
};
