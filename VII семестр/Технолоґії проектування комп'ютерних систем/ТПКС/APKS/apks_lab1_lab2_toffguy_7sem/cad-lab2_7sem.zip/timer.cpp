//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#ifndef TIMER
#include "timer.h"
#define TIMER
#endif

timer::timer()
{	
	time = 0;
	interval = 1;
	ir = false;
};

void timer::work()
{
	time++;
	if (time % interval == 0) ir = true;
};

void timer::set_interval(unsigned long new_interval)
{
	interval = new_interval;
};

bool timer::interrupt()
{
	if (ir == false) return false;
	else return true;
};
