//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#ifndef FIFO
#include "fifo.h"
#define FIFO
#endif

#ifndef ROUTER
#include "router.h"
#define ROUTER
#endif

class cpu
{
	task
		*current_task;
	router
		*r;
	unsigned
		device_num;
public:
	int
		flags;

	cpu();
	void bind(router *b_router, unsigned d);
	bool idle();
	void set_task(struct task *new_task);
	unsigned long need_time();
	void work();	
};
