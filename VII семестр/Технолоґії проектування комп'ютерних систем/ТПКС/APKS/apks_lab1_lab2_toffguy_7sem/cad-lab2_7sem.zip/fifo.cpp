//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#include <stdio.h>

#ifndef FIFO
#include "fifo.h"
#define FIFO
#endif

fifo::fifo()
{
	first = NULL;
	last = NULL;
};

void fifo::add(task *new_task)
{
	fifo_rec
		*new_rec;

	new_rec = new fifo_rec;
	new_rec->next = first;
	new_rec->prev = NULL;
	new_rec->data = new_task;
	if (first != NULL) first->prev = new_rec;
	first = new_rec;

	if (last == NULL) last = first;
};

task* fifo::get_task()
{
	task
		*last_task;

	if (last == NULL) return NULL;
	last_task = last->data;
	if (last->prev != NULL) last->prev->next = NULL;
	last = last->prev;
	if (last == NULL) first = NULL;

	return last_task;
};

bool fifo::empty()
{
	if (last == NULL) return true;
	else return false;
};
