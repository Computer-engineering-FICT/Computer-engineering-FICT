//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#define MAX_DEVS	10

#define CPU_READY	0x01
#define CPU_IDLE	0x02

struct marker
{
	unsigned		
		dest;
	bool
		data_sent;
};
