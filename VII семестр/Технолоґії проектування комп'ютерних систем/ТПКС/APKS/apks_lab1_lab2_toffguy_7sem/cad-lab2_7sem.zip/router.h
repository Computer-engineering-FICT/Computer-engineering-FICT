//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#ifndef FIFO
#include "fifo.h"
#define FIFO
#endif

#ifndef CONST
#include "const.h"
#define CONST
#endif

class router
{
	fifo
		query,
		*proc_fifo;
	bool
		*flag_slot;
	marker
		*marker_slot;
	unsigned
		device_num;
public:
	bool
		operable;

	void init(unsigned, bool*, marker*);
	void bind(fifo *);
	void send(task *, unsigned);
	void recv(task *);
	bool rts();
	task* get_data();
};