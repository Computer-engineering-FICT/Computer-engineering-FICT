//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#ifndef TIMER
#include "timer.h"
#define TIMER
#endif

#ifndef CPU
#include "cpu.h"
#define CPU
#endif

#ifndef FIFO
#include "fifo.h"
#define FIFO
#endif

#ifndef ROUTER
#include "cpu.h"
#define ROUTER
#endif

class device
{
	timer
		timer;
	fifo
		fifo;
	cpu
		cpu;
	unsigned
		number,
		events;
public:
	router
		router;
	bool 
		operable;

	device();
	void init(unsigned dev_num);
	void int_handler(int);
	void work();
	void gen_random();
	void shutdown();
};
