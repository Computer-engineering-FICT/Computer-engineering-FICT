//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

struct task
{
	unsigned
		orig,
		dest;
	unsigned long
		need_time,
		used_time;
	bool
		solved;
};

struct fifo_rec
{
	task
		*data;
	fifo_rec
		*prev,
		*next;
};

class fifo
{
	fifo_rec
		*first,
		*last;
public:
	fifo();
	void add(task *);
	task* get_task();
	bool empty();
};