//(c) Aleksey Tulinoff, 2002
//downloaded from www.i.com.ua/~toffguy

#include <stdio.h>

#ifndef ROUTER
#include "router.h"
#define ROUTER
#endif

extern unsigned
	sys_time;

/* init router (from hand of token bus device) */
void router::init(unsigned num, bool *flag, marker *ms)
{
	operable = true;
	device_num = num;
	flag_slot = flag;
	marker_slot = ms;
};

/* bind router to processor's fifo */
void router::bind(fifo *f)
{
	proc_fifo = f;
};

/* recv data from ring */
void router::recv(task *r_task)
{		
	if (!operable) return;
	if (flag_slot) 	
	{
		if (marker_slot->dest == device_num)
		{			
			if (r_task->solved)
			{
				printf("%5d: cpu %d is accepted answer from cpu %d\n", sys_time, device_num, r_task->orig);
				marker_slot->data_sent = true;
				delete r_task;
				return;
			};

			proc_fifo->add(r_task);			
			marker_slot->data_sent = true;
			printf("%5d: cpu %d is accepted task from cpu %d, for %d tic(s)\n", sys_time, device_num, r_task->orig, r_task->need_time);			
		};
	};	
};

/* send data */
void router::send(task *s_task, unsigned to_id)
{
	if (!operable) return;
	s_task->dest = to_id;
	query.add(s_task);
	printf("%5d: router %d is sending data to device %d\n", sys_time, device_num, s_task->dest);
};

/* `ready to send` signal */
bool router::rts()
{
	if (!operable) return false;
	if (query.empty()) return false;
	else return true;
};

/* get data from query to send */
task* router::get_data()
{
	task
		*data;

	data = query.get_task();
	return data;
};
