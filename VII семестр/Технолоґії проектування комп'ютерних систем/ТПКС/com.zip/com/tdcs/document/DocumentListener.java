package com.tdcs.document;

public interface DocumentListener {
	public void update(Object sender, String msg);
}
