package com.tdcs.model;


public interface Element {
	public int getIndex();

	public String toString();
	
	public int getTextBegin();
	
	public int getTextEnd();
}
