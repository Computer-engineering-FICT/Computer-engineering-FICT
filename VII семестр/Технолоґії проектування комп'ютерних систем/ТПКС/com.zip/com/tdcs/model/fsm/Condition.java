package com.tdcs.model.fsm;

import java.io.Serializable;

public class Condition implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2161217580378959426L;
	private int index;
	private boolean condition;

	public Condition(int index) {
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public boolean getCondition() {
		return condition;
	}

	public void setCondition(boolean condition) {
		this.condition = condition;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if ((obj == null) || (obj.getClass() != this.getClass()))
			return false;
		Condition c = (Condition) obj;

		return (index == c.index) && (condition == c.condition);
	}

	public int hashCode() {
		if (condition)
			return (index << 1) | 1;
		else
			return (index << 1);
	}
}
