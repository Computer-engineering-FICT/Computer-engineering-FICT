package edu.kpi.memory.process;

public class Start {

    public static void main(String[] args) {
        Processor proc = new Processor(new Parameters());
        
        proc.start(100);
    }

}
