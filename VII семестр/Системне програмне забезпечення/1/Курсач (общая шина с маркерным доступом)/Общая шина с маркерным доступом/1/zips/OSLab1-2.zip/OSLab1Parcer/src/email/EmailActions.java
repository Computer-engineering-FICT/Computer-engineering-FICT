package email;

import java.io.BufferedReader;
import java.util.ArrayList;

import parcer.Actions;

public class EmailActions extends Actions {
    ResultStructure struct;
    
    public EmailActions(BufferedReader sourceFile) {
        super(sourceFile);
        
        addAction(1, Action1);
        addAction(2, Action2);
        addAction(3, Action3);
        
        addError(1, new ErrorClass("Incorrect symbol in e-mail name"));
        addError(2, new ErrorClass("Unexpected end email name / empty name"));
        addError(3, new ErrorClass("Unexpected end of file"));
        addError(4, new ErrorClass("Unexpected end email domain / " +
        		"empty domain"));
        addError(5, new ErrorClass("Incorrect symbol in domain"));
        addError(6, new ErrorClass("Incorrect position of '.'/'-'"));
        addError(7, new ErrorClass("Illegal symbol"));
        
        struct = new ResultStructure();
    }

    //=============== Action block ===============
    
    private ActionClass Action1 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addEmail();
            struct.addCharToName(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    private ActionClass Action2 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addCharToName(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    private ActionClass Action3 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addCharToDomain(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    //=============== End of action block ===============
    
    private class ResultStructure {
        private ArrayList<Email> emailList;
        private Email currentEmail;
        
        private class Email {
            private String name;
            private String domain;
            
            public Email() {
                name = "";
                domain = "";
            }
            
            public void addCharToName(char c) {
                name += Character.toString(c);
            }
            
            public void addCharToDomain(char c) {
                domain += Character.toString(c);
            }
            
            public String toString() {
                return name + "@" + domain;
            }
        }
        
        public ResultStructure() {
            emailList = new ArrayList<Email>();
        }
        
        public void addEmail() {
            currentEmail = new Email();
            emailList.add(currentEmail);
        }
        
        public void addCharToName(char c) {
            currentEmail.addCharToName(c);
        }
        
        public void addCharToDomain(char c) {
            currentEmail.addCharToDomain(c);
        }
        
        public String toString() {
            String str = "";
            
            for (Email email : emailList) { str += email + "\n"; }
            
            return str;
        }
    }
    
    @Override
    public void printResult() {
        System.out.println(struct);
    }

    @Override
    public String getResults() {
        return struct.toString();
    }
}
