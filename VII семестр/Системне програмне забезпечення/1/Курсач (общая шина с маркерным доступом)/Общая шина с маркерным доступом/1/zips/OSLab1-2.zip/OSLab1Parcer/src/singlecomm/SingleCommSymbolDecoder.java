package singlecomm;

import parcer.SymbolDecoder;

public class SingleCommSymbolDecoder extends SymbolDecoder {
    public static final int ENTER_CODE = 2;
        
    /**
     * Filling in decoding table.
     */
    public SingleCommSymbolDecoder() {
        super(3, 1);        
        
        //decodeMap.put('\n', ENTER_CODE);
        //decodeMap.put('\n', SPACE_ENTER_CODE);
        decodeMap.put((char) 13, ENTER_CODE);
        decodeMap.put((char) 10, ENTER_CODE);
    }    
}
