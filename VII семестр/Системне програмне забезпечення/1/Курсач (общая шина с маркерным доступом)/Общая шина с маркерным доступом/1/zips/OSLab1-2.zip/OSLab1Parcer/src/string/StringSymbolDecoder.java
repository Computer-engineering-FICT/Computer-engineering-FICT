package string;

import parcer.SymbolDecoder;

public class StringSymbolDecoder extends SymbolDecoder {
    public static final int QUOTES_CODE = 1;
    public static final int BACKSLASH_CODE = 2;
    public static final int NT_CODE = 4;
    
    /**
     * Filling in decoding table.
     */
    public StringSymbolDecoder() {
        super(5, 3);        
               
        decodeMap.put('n', NT_CODE);
        decodeMap.put('N', NT_CODE);
        decodeMap.put('t', NT_CODE);
        decodeMap.put('T', NT_CODE);
        
        decodeMap.put('\\', BACKSLASH_CODE);                      
        decodeMap.put('"', QUOTES_CODE);
    }    
}
