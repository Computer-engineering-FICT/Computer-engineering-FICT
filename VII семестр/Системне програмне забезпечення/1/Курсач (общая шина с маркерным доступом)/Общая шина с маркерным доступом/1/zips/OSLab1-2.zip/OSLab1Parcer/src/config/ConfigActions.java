package config;

import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;

import multicomm.MultiCommActions;
import multicomm.MultiCommSymbolDecoder;

import parcer.Actions;
import parcer.AutomateController;
import singlecomm.SingleCommActions;
import singlecomm.SingleCommSymbolDecoder;
import string.StringActions;
import string.StringSymbolDecoder;

public class ConfigActions extends Actions {
    ResultStructure struct;
    
    public ConfigActions(BufferedReader sourceFile) {
        super(sourceFile);
        
        addAction(1, Action1);
        addAction(2, Action2);
        addAction(3, Action3);
        addAction(4, Action4);
        addAction(5, Action5);
        addAction(6, Action6);
        addAction(7, Action7);
        addAction(8, Action8);
        addAction(9, Action9);
        addAction(10, Action10);
        
        addError(1, new ErrorClass("Incorrect begining of name"));
        addError(2, new ErrorClass("Empty name"));
        addError(3, new ErrorClass("Incorrect symbol in name"));
        addError(4, new ErrorClass("Unexpected end of file"));
        addError(5, new ErrorClass("Incorrect symbol in value"));
        addError(6, new ErrorClass("Incorrect symbol position"));
        addError(7, new ErrorClass("Empty parameter value"));
        
        struct = new ResultStructure();
    }

    //=============== Action block ===============
    
    /** New cell + Action 2 */
    private ActionClass Action1 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addCell();
            struct.addCharToName(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** name += buffer */
    private ActionClass Action2 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addCharToName(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** value += buffer */
    private ActionClass Action3 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addCharToValue(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** braceCount-- */
    private ActionClass Action4 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.decBraceCount();
            struct.addBrace();
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** isParameter = true. Cell marked as parameter. */
    private ActionClass Action5 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.setParameter();
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** braceCount++ */
    private ActionClass Action6 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.incBraceCount();
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** Sub-automate "String" */
    private ActionClass Action7 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            Actions stringActions = new StringActions(reader);
            
            AutomateController stringControl = 
                new AutomateController(reader, 
                        new File("resources/config/line.txt"), 
                        new StringSymbolDecoder(), 
                        stringActions);
            int exitCode = stringControl.start();            
            struct.addStringToValue("\"" + stringActions.getResults() + "\"");
            
            if (exitCode == 0) { 
                return SUCCESS_EXIT_CODE; 
            } else {
                return exitCode;
            }  
        }
    };
    
    /** Sub-automate Multi string comment (with error) */
    private ActionClass Action8 = new ActionClass() {        
        @Override
        public int doAction(char c) {            
            Actions multiActions = new MultiCommActions(reader);
            
            AutomateController multiControl = 
                new AutomateController(reader, 
                        new File("resources/config/multicomm.txt"), 
                        new MultiCommSymbolDecoder(), 
                        multiActions);
            int exitCode = multiControl.start();
            struct.addComment(multiActions.getResults());
            
            if (exitCode == 0) { 
                return SUCCESS_EXIT_CODE; 
            } else {
                return exitCode;
            }            
        }
    };
    
    /** Sub-automate Multi string comment (without error) */
    private ActionClass Action9 = new ActionClass() {        
        @Override
        public int doAction(char c) {            
            Actions multiActions = new MultiCommActions(reader);
            
            AutomateController multiControl = 
                new AutomateController(reader, 
                        new File("resources/config/multicomm.txt"), 
                        new MultiCommSymbolDecoder(), 
                        multiActions);
            int exitCode = multiControl.start();
            if (exitCode == 1) {
                struct.addCharToValue('/');
                if ((char) multiActions.getErrorChar() != ';') {
                	struct.addCharToValue((char) multiActions.getErrorChar());
                }
                setErrorCharExist(true);
                setErrorChar(multiActions.getErrorChar());
                return SUCCESS_EXIT_CODE;
            } 
            
            if (exitCode == 0) {
                struct.addComment(multiActions.getResults());
                return SUCCESS_EXIT_CODE;
            } else {
                return exitCode;
            }
            
        }
    };
    
    /** Sub-automate Single string comment */
    private ActionClass Action10 = new ActionClass() {        
        @Override
        public int doAction(char c) {            
            Actions singleActions = new SingleCommActions(reader);
            
            AutomateController singleControl = 
                new AutomateController(reader, 
                        new File("resources/config/singlecomm.txt"), 
                        new SingleCommSymbolDecoder(), 
                        singleActions);
            int exitCode = singleControl.start();
            struct.addComment(singleActions.getResults());
            
            if (exitCode == 0) { 
                return SUCCESS_EXIT_CODE; 
            } else {
                return exitCode;
            }            
        }
    };
    
    //=============== End of action block ===============
    
    private class ResultStructure {
        private ArrayList<Cell> cellsList;
        private ArrayList<String> comments;
        private Cell currentCell;
        
        private int braceCount = 0;
        
        public void incBraceCount() { braceCount++; }
        public void decBraceCount() { braceCount--; }
        
        private class Cell {
            private String name;
            private String value;
            /** Type of cell (as default - all cells are sections). */
            private boolean param;
            public Character isBrace;
            
            public Cell() {
                name = "";
                value = "";
                param = false;
            }
            
            public Cell(char c) {
                isBrace = c;
            }
            
            public void addCharToName(char c) {
                name += Character.toString(c);
            }
            
            public void addCharToValue(char c) {
                value += Character.toString(c);
            }
            
            public void addStringToValue(String str) {
                value += str;
            }
            
            public String toString() {
                if (isBrace != null) {
                    return isBrace.toString();
                } else {
                    if (param) {
                        return name + " = " + value + ";";
                    } else {
                        return name + " " + value + " {";
                    }
                }                              
            }
            
            public void setParameter(boolean b) {
                param = b;
            }
            
            public boolean isParameter() {
                return param;
            }
            
            public boolean isBrace() {
                return isBrace != null;
            }            
        }
        
        public ResultStructure() {
            cellsList = new ArrayList<Cell>();
            comments = new ArrayList<String>();
        }
        
        public void addCell() {
            currentCell = new Cell();
            cellsList.add(currentCell);
        }
        
        public void addBrace() {
            currentCell = new Cell('}');
            cellsList.add(currentCell);
        }
        
        public void addCharToName(char c) {
            currentCell.addCharToName(c);
        }
        
        public void addCharToValue(char c) {
            currentCell.addCharToValue(c);
        }
        
        public void setParameter() {
            currentCell.setParameter(true);
        }
        
        public void addComment(String comm) {
            comments.add(comm);
        }
        
        public void addStringToValue(String str) {
            currentCell.addStringToValue(str);
        }
        
        public String toString() {
            String str = "";
            
            String indentStep = "   ";
            int indentCount = 0;
            
            for (Cell cell : cellsList) { 
                if (!cell.isParameter() && cell.isBrace()) {
                    indentCount--;
                }
                
                for (int i = 0; i <  indentCount; i++) { str += indentStep; }
                str += cell + "\n";
                
                if (!cell.isParameter() && !cell.isBrace()) {
                    indentCount++;
                }
            }
            if (braceCount != 0) { str += "\n Brace count control failed."; }
            
            str += "\n Comment sections:";            
            for (String comm : comments) {
                str += "\n" + comm;
            }
            
            return str;
        }
    }
    
    @Override
    public void printResult() {
        System.out.println(struct);
    }

    @Override
    public String getResults() {
        return struct.toString();
    }   
}
