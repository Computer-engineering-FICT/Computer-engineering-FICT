package singlecomm;

import java.io.BufferedReader;

import parcer.Actions;

public class SingleCommActions extends Actions {
    ResultStructure struct;
    
    public SingleCommActions(BufferedReader sourceFile) {
        super(sourceFile);
        
        addAction(1, Action1);               
        
        struct = new ResultStructure();
    }

    //=============== Action block ===============
    
    /** Buffer to output string. */
    private ActionClass Action1 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addChar(c);
            return SUCCESS_EXIT_CODE;
        }
    };
         
    //=============== End of action block ===============
    
    private class ResultStructure {
        private String outputStr;
              
        public ResultStructure() {
            outputStr = "";
        }        
        
        public void addChar(char c) {
            outputStr += c;
        }
                
        public String toString() {            
            return outputStr;
        }
    }
    
    @Override
    public void printResult() {
        System.out.println(struct);
    }

    @Override
    public String getResults() {
        return struct.toString();
    }
}
