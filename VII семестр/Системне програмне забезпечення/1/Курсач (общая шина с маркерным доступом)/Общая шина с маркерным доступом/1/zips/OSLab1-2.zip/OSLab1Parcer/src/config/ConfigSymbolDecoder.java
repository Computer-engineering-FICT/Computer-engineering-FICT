package config;

import parcer.SymbolDecoder;

/**
 * @author Pustovit Michael, pustovitm@gmail.com
 * Symbol decoder for config file parser. Decode letters, numbers and 
 * some special characters.
 */
public class ConfigSymbolDecoder extends SymbolDecoder {
    public static final int LETTER_CODE = 1;
    public static final int NUMBER_UNDESCORE_CODE = 2;
    public static final int SPACE_ENTER_CODE = 3;
    public static final int OPEN_BRAC_CODE = 4;
    public static final int CLOSE_BRAC_CODE = 5;
    public static final int SEMI_CODE = 6;
    public static final int QUOTES_CODE = 7;
    public static final int SLASH_CODE = 8;
    public static final int EQU_CODE = 9;
    public static final int NUM_CODE = 12;
    
    /**
     * Filling in decoding table.
     */
    public ConfigSymbolDecoder() {
        super(10, 11);        
        
        for (char i = 'a'; i <= 'z'; i++) {decodeMap.put(i, LETTER_CODE);}
        for (char i = 'A'; i <= 'Z'; i++) {decodeMap.put(i, LETTER_CODE);}
        
        for (char i = '0'; i <= '9'; i++) {decodeMap.put(i, NUMBER_UNDESCORE_CODE);}
        decodeMap.put('_', NUMBER_UNDESCORE_CODE);
        
        decodeMap.put(' ', SPACE_ENTER_CODE);
        //decodeMap.put('\n', SPACE_ENTER_CODE);
        decodeMap.put((char) 13, SPACE_ENTER_CODE);
        decodeMap.put((char) 10, SPACE_ENTER_CODE);
        
                      
        decodeMap.put('{', OPEN_BRAC_CODE);
        decodeMap.put('}', CLOSE_BRAC_CODE);
        decodeMap.put(';', SEMI_CODE);
        decodeMap.put('"', QUOTES_CODE);
        decodeMap.put('/', SLASH_CODE);
        decodeMap.put('=', EQU_CODE);
        decodeMap.put('#', NUM_CODE);
    }    
}
