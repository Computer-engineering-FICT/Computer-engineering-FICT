package email;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

import parcer.Actions;
import parcer.AutomateController;
import parcer.SymbolDecoder;

public class EmailParcerStart {

    public static void main(String[] args) {               
        SymbolDecoder decoder = new EmailSymbolDecoder();  
        
        try {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            new FileInputStream(new File("email.txt"))));
            
            Actions action = new EmailActions(reader);
            
            AutomateController controller = 
                new AutomateController(reader, 
                        new File("resources/email/table.txt"),
                        decoder, action);
            
            System.out.println("\nExit code: " + controller.start());
            controller.printResult();
        } catch (FileNotFoundException e) {
            System.out.println("Source file doesn't found");
            e.printStackTrace();
        }        
    }

}
