package string;

import java.io.BufferedReader;

import parcer.Actions;

public class StringActions extends Actions {
    ResultStructure struct;
    
    public StringActions(BufferedReader sourceFile) {
        super(sourceFile);
        
        addAction(1, Action1);
        addAction(2, Action2);
        
        addError(1, new ErrorClass("Unexpected end of line"));
        addError(2, new ErrorClass("Incorrect symbol after \\"));
        
        struct = new ResultStructure();
    }

    //=============== Action block ===============
    
    /** Buffer to output string. */
    private ActionClass Action1 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addChar(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** '*' + Buffer to output string. */
    private ActionClass Action2 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addChar('\\');
            struct.addChar(c);
            return SUCCESS_EXIT_CODE;
        }
    };
       
    //=============== End of action block ===============
    
    private class ResultStructure {
        private String outputStr;
              
        public ResultStructure() {
            outputStr = "";
        }        
        
        public void addChar(char c) {
            outputStr += c;
        }
                
        public String toString() {            
            return outputStr;
        }
    }
    
    @Override
    public void printResult() {
        System.out.println(struct);
    }

    @Override
    public String getResults() {
        return struct.toString();
    }
}
