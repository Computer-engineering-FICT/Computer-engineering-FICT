package parcer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * @author Pustovit Michael
 *  Transition table. Columns - nodes, rows - signals.
 *      n1  n2 n3   ...
 *  s1  1a2 ...
 *  s2
 *  .
 *  .
 *  .
 */
public class TransitionTable {
    /** Width of table. */
    private int width;
    /** Height of table. */
    private int height;
    /** Transition table. */
    private TableElement [][] table;
    
    /**
     * Constructor for transition table which parce file in format:
     * <next cell> <type of action> <number of action/error> | ...
     * ...
     * <next cell> <type of action> <number of action/error> | ...
     * @param tableFile Parcing file
     */
    public TransitionTable (File tableFile) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(tableFile));
            try {
                String s;
                StringTokenizer token;
                
                s = reader.readLine();
                token   = new StringTokenizer(s);
                width   = Integer.parseInt(token.nextToken());
                height  = Integer.parseInt(token.nextToken());
                
                table = new TableElement [height][width];
                
                int tempNumCell, tempNumAction;
                
                for (int i = 0; i < height; i++) {
                    s = reader.readLine();
                    token   = new StringTokenizer(s);
                    for (int j = 0; j < width; j++) {
                        String t = token.nextToken().trim();
                        tempNumCell = Integer.parseInt(t);                        
                        t = token.nextToken(" |").trim();
                        tempNumAction = Integer.parseInt(t);
                        
                        if (tempNumCell != -1) 
                            table[i][j] = new TableElement(tempNumCell, 
                                    tempNumAction, TableElement.ACTION);
                        else
                            table[i][j] = new TableElement(tempNumCell, 
                                    tempNumAction, TableElement.ERROR);                        
                    }
                }
            } catch (IOException e) {
                System.out.println("I/O error");
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("Table file not found");
            e.printStackTrace();
        }               
    }
    
    /**
     * Getter for XY cell.
     * @param x X coordinate of cell.
     * @param y Y coordinate of cell.
     * @return  Content of cell.
     */
    public TableElement getCell(int x, int y) {
        return table[x][y];
    }
    
    public String toString() {
        String str = "";
        
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                str += table[i][j].getNextCell() 
                     + (table[i][j].isError()?" e ":" a ") 
                     + table[i][j].getNumberOfAction() + " | ";                
            }
            str += "\n";
        }
        
        return str;
    }
}
