package parcer;

public class Automate {
    /** Transition table of automate. */
    private TransitionTable table;
    
    /** Class which consist actions for this table. */
    private Actions actions;
    
    /** Number of node in which automate is situated in current moment. */
    private int currentNode;
    
    /** Character to signal number decoder. */
    private SymbolDecoder decoder;
    
    public Automate (TransitionTable ptable, Actions pactions, int pstartNode, 
            SymbolDecoder pdecoder) {
        table = ptable;
        actions = pactions;
        currentNode = pstartNode;
        decoder = pdecoder;
    }
    
    /**
     * Making step of automate. Algorithm: find in table next cell and action 
     * which we have to make during transition. 
     * @param c
     * @return Exit code.
     */
    public int makeStep(int c) {
        int signal = decoder.decode(c);
        TableElement cell = table.getCell(signal - 1, currentNode - 1);
        int exitCode;
        
        currentNode = cell.getNextCell();
        
        //If we've found EOF or error
        if (currentNode == -1) {
            actions.doError(cell.getNumberOfAction(), c);
            exitCode = cell.getNumberOfAction(); 
        } else {
            exitCode = actions.doAction(cell.getNumberOfAction(), (char) c);
        }
        
        return exitCode;                
    }
}
