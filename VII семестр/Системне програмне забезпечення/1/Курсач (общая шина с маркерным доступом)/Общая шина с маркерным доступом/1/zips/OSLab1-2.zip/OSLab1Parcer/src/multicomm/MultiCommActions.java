package multicomm;

import java.io.BufferedReader;

import parcer.Actions;

public class MultiCommActions extends Actions {
    ResultStructure struct;
    
    public MultiCommActions(BufferedReader sourceFile) {
        super(sourceFile);
        
        addAction(1, Action1);
        addAction(2, Action2);
        
        addError(1, new ErrorClass(""));
        addError(2, new ErrorClass("Unexpected end of multi line comment"));
        
        struct = new ResultStructure();
    }

    //=============== Action block ===============
    
    /** Buffer to output string. */
    private ActionClass Action1 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addChar(c);
            return SUCCESS_EXIT_CODE;
        }
    };
    
    /** '*' + Buffer to output string. */
    private ActionClass Action2 = new ActionClass() {        
        @Override
        public int doAction(char c) {
            struct.addChar('*');
            struct.addChar(c);
            return SUCCESS_EXIT_CODE;
        }
    };
       
    //=============== End of action block ===============
    
    private class ResultStructure {
        private String outputStr;
              
        public ResultStructure() {
            outputStr = "";
        }        
        
        public void addChar(char c) {
            outputStr += c;
        }
                
        public String toString() {            
            return outputStr;
        }
    }
    
    @Override
    public void printResult() {
        System.out.println(struct);
    }

    @Override
    public String getResults() {
        return struct.toString();
    }
}
