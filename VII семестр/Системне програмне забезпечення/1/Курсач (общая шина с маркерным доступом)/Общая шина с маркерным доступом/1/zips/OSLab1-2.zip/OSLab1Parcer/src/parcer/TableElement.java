package parcer;

/**
 * @author Pustovit Michael
 *  Element of transition table - cell. Each cell consists of 2 fields:
 *  -transition cell
 *  -number of executing action  
 */
public class TableElement {
    public static final int ACTION = 0;
    public static final int ERROR  = 1;
    
    /** Next cell of transition. */
    private int nextCell;
    
    /** Number of executing action. */
    private int numberAction;

    /** Type of executing action. */
    private int actionType;
    
    public TableElement(int pnextCell, int pnumberAction, int ptype) {
        nextCell = pnextCell;
        numberAction = pnumberAction;
        actionType = ptype;
    }
    
    public int getNextCell() {
        return nextCell;
    }
    
    public int getNumberOfAction() {
        return numberAction;
    }
    
    public boolean isError() {
        if (actionType == ACTION) 
            return false;
        else
            return true;
    }
}

