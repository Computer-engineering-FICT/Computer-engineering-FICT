package multicomm;

import parcer.SymbolDecoder;

public class MultiCommSymbolDecoder extends SymbolDecoder {
    public static final int STAR_CODE = 1;
    public static final int SLASH_CODE = 2;
    
    /**
     * Filling in decoding table.
     */
    public MultiCommSymbolDecoder() {
        super(4, 3);        
        
        decodeMap.put('*', STAR_CODE);
        decodeMap.put('/', SLASH_CODE);
    }    
}
