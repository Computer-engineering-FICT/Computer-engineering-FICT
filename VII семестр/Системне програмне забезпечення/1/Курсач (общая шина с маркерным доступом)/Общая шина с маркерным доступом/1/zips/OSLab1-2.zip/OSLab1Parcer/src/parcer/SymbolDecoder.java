package parcer;

import java.util.HashMap;

/**
 * @author Pustovit Michael, pustovitm@gmail.com
 * Symbol decoder^ decode symbol into signal number. Contains decode HashMap, 
 * which is filled in constructor.
 */
public abstract class SymbolDecoder {
    public final int OTHER_CODE;
    public final int EOF_CODE;
    
    protected HashMap<Character, Integer> decodeMap;
    
    public SymbolDecoder(int other, int eof) {
        decodeMap = new HashMap<Character, Integer>();
        OTHER_CODE = other;
        EOF_CODE = eof;
    }
    
    /**
     * Decoding symbol c into signal number
     * @param c Decoding symbol
     * @return  Number of signal
     */
    public int decode(int c) {
        if (c == -1) {
            return EOF_CODE;
        } else {
            if (decodeMap.containsKey((char) c)) {
                return decodeMap.get((char) c);
            } else {
                return OTHER_CODE;
            }
        }
    };
}
