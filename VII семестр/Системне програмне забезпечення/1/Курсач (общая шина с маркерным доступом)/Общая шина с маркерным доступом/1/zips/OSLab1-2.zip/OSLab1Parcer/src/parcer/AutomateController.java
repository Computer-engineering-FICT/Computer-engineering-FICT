package parcer;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public class AutomateController {
    private BufferedReader reader;
    private TransitionTable table;
    private Automate automate;
    private Actions actions;
    
    /**
     * @param sourceFile    Reader build on source file.
     * @param tableFile     File which describe transition table
     * @param pdecoder      Symbol decoder
     * @param pactions      Actions of automate
     * @param noErr         Results of execution of actions. (If one of 
     * actions returns "false", then noErr will be "false" and automate'll stop)
     */
    public AutomateController(BufferedReader sourceFile, File tableFile, 
            SymbolDecoder pdecoder, Actions pactions) {
        reader = sourceFile;
        actions = pactions;
        table = new TransitionTable(tableFile);
        automate = new Automate(table, actions, 1, pdecoder);
    }

    public int start() {
        int exitCode = Actions.SUCCESS_EXIT_CODE;
        
        actions.setErrorCharExist(false);
        
        while (exitCode == Actions.SUCCESS_EXIT_CODE) {
            int c;
            try {
                if (actions.errorCharExist) {
                	c = actions.getErrorChar();
                	actions.setErrorCharExist(false);
                } else {
                	c =  reader.read();
                }
                exitCode = automate.makeStep(c);
                //actions.printResult();
            } catch (IOException e) {
                System.out.println("I/O problem");
                e.printStackTrace();
            }
        }
        
        return exitCode;
    }
    
    public void printResult() {
        actions.printResult();
    } 
}
