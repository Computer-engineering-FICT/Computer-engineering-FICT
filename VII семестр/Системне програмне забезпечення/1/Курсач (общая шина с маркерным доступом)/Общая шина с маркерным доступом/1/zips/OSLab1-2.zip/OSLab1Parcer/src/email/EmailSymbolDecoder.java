package email;

import parcer.SymbolDecoder;

/**
 * @author Pustovit Michael, pustovitm@gmail.com
 * Symbol decoder for e-mail parser. Decode letters, numbers and 
 * some special characters.
 */
public class EmailSymbolDecoder extends SymbolDecoder {
    public static final int LETTER_NUMBER_CODE = 1;
    public static final int SPACE_ENTER_CODE = 2;
    public static final int UNDERSCORE_CODE = 3;
    public static final int POINT_CODE = 4;
    public static final int AT_CODE = 5;
    public static final int DASH_CODE = 7;
    
    /**
     * Filling in decoding table.
     */
    public EmailSymbolDecoder() {
        super(8, 6);        
        
        for (char i = 'a'; i <= 'z'; i++) {decodeMap.put(i, LETTER_NUMBER_CODE);}
        for (char i = 'A'; i <= 'Z'; i++) {decodeMap.put(i, LETTER_NUMBER_CODE);}
        for (char i = '0'; i <= '9'; i++) {decodeMap.put(i, LETTER_NUMBER_CODE);}
        
        decodeMap.put(' ', SPACE_ENTER_CODE);
        //decodeMap.put('\n', SPACE_ENTER_CODE);
        decodeMap.put((char) 13, SPACE_ENTER_CODE);
        decodeMap.put((char) 10, SPACE_ENTER_CODE);
        
        decodeMap.put('_', UNDERSCORE_CODE);
        
        decodeMap.put('.', POINT_CODE);
        decodeMap.put('@', AT_CODE);
        decodeMap.put('-', DASH_CODE);
    }    
}
