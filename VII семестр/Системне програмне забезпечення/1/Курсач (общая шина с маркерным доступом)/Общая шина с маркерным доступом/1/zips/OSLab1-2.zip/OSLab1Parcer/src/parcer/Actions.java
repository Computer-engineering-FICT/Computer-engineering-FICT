package parcer;

import java.io.BufferedReader;
import java.util.HashMap;

/**
 * @author Pustovit Michael, pustovitm@gmail.com
 * All actions and errors which can be executed in used automate.
 */
public abstract class Actions {
    public static final int SUCCESS_EXIT_CODE = -1;
    public static final int ERROR_CHAR_CODE = -2;
             
    /** Source (analizing) file reader. */
    protected BufferedReader reader;
    
    /** HashMap of actions. Every action has its own number (key). */
    protected HashMap<Integer, ActionClass> actionMap;
    
    /** HashMap of errors. Every error has its own number (key). */
    protected HashMap<Integer, ErrorClass> errorMap;
    
    /** Action which does nothing. (Skip symbol). */
    protected ActionClass ActionNull = new ActionClass() {        
        @Override
        public int doAction(char c) { return SUCCESS_EXIT_CODE; }
    };
    
    /** One error which isn't error - successful end of processing. */
    protected ErrorClass ErrorNull = 
        new ErrorClass("");
    
    /** Symbol which triggered the error. */
    protected char errorChar;
    protected boolean errorCharExist;
    
    public void setErrorCharExist(boolean b) {
    	errorCharExist = b;
    }
    
    public boolean isErrorCharExist() {
    	return errorCharExist;
    }
    
    public void setErrorChar(int c) {
    	errorChar = (char) c;
    }   
    
    /**
     * @author Pustovit Michael, pustovitm@gmail.com
     * Abstract class for action. We use it in map of actions.
     */
    public abstract class ActionClass {
        public abstract int doAction(char c);
    }
    
    /**
     * @author Pustovit Michael, pustovitm@gmail.com
     * Error message class. It does only one thing - print error message.
     */
    protected class ErrorClass {
        private String message;
        
        public ErrorClass(String pmessage) {
            message = pmessage;
        }
        
        public void printError() {
            System.out.print(message);
        }
    }
    
    /**
     * Standard constructor which plugs in source file (while which is 
     * being analyzed).
     * @param sourceFile Analazing file reader.
     */
    public Actions(BufferedReader sourceFile) {
        reader = sourceFile;
        actionMap   = new HashMap<Integer, ActionClass>();
        errorMap    = new HashMap<Integer, ErrorClass>();
        actionMap.put(0, ActionNull);
        errorMap.put(0, ErrorNull);
    }    

    /**
     * Executing of action with number funcNumber. 
     * @param funcNumber Number of function.
     * @param c Control character.
     * @param Exit Code
     */
    public int doAction(int funcNumber, char c) {
        return (actionMap.get(funcNumber)).doAction(c);         
    }
    
    /**
     * Adding of new actions
     * @param number Number of action
     * @param action Action class
     */
    protected void addAction (int number, ActionClass action) {                
        actionMap.put(number, action);
    }
    
    /**
     * Adding of new actions
     * @param number Number of action
     * @param action Action class
     */
    protected void addError (int number, ErrorClass action) {                
        errorMap.put(number, action);
    }
    
    public void doError (int errNumber, int c) {
        (errorMap.get(errNumber)).printError();
         errorChar = (char) c;
    }
    
    /**
     * Returns count of able actions.
     * @return Count of able actions
     */
    protected int getActionCount() {
        return actionMap.size();
    }
    
    /**
     * Returns count of able errors.
     * @return Count of able errors
     */
    protected int getErrorCount() {
        return errorMap.size();
    }
    
    /**
     * Printing of result structure.
     */
    public abstract void printResult();
    
    /**
     * @return Same string as toString result.
     */
    public abstract String getResults();
    
    /**
     * @return Symbol which triggered the error.
     */
    public int getErrorChar() {
        return errorChar;
    }
}
