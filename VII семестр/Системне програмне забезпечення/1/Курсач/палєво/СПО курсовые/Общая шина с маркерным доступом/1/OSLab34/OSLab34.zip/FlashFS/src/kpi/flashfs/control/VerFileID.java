package kpi.flashfs.control;

public class VerFileID {
	public int maxVer, maxFileId;
}
