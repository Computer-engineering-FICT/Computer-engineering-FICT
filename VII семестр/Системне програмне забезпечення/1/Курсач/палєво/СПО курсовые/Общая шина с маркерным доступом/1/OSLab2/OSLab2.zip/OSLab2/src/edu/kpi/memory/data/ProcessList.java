package edu.kpi.memory.data;

public class ProcessList {

}
