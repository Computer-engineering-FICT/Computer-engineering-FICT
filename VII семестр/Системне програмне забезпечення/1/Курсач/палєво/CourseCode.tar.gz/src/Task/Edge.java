package Task;

/**
 * Edge between tasks. It has at least zero communication cost. *
 */
public class Edge {
	
	/**
	 * Edge cost, communication cost.
	 */
	private int cost;
	private int neighbour;
	
	public Edge(int cost, int neighbour) {
		setCost(cost);
		setNeighbour(neighbour);
	}

	private void setNeighbour(int neighbour2) {
		if (neighbour2 >= 0) {
			this.neighbour = neighbour2;
		} else {
			throw new IllegalArgumentException();
		}		
	}

	private void setCost(int cost2) {
		if (cost2 >= 0) {
			this.cost = cost2;
		} else {
			throw new IllegalArgumentException();			
		}
	}


	public int getCost() {
		return cost;
	}


	public int getNeighbour() {
		return neighbour;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cost;
		result = prime * result + neighbour;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Edge other = (Edge) obj;
		if (cost != other.cost)
			return false;
		if (neighbour != other.neighbour)
			return false;
		return true;
	}
}
