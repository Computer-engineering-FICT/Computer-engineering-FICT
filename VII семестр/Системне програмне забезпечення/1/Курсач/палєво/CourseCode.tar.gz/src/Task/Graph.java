package Task;

public class Graph {
	
	private Vertex[] tasks;

	public Graph(int numberOfTasks) {
		tasks = new Vertex[numberOfTasks];
	}
	
	public Graph(Vertex[] tasks2) {
		if (tasks2 != null) {
			tasks = tasks2;
		}
	}

	/**
	 * @return the tasks
	 */
	public Vertex[] getTasks() {
		return tasks;
	}

	/**
	 * @param tasks the tasks to set
	 */
	public void setTasks(Vertex[] tasks) {
		this.tasks = tasks;
	}
	
	public Vertex getTask(int i) {
		if (i < 0 || i >= tasks.length) {
			throw new IllegalArgumentException();
		}
		assert (tasks[i].getId() == i);
		return tasks[i];
	}
	
	public void setTask(Vertex task) {
		if (task.getId() >= tasks.length) {
			throw new IllegalArgumentException();
		}
		tasks[task.getId()] = task;
	}
	
	/**
	 * @return graph's size (number of tasks in graph).
	 */
	public int size() {
		return tasks.length;
	}

}
