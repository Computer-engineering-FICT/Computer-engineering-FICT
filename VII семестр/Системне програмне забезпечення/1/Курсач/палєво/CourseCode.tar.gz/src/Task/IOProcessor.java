package Task;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static javax.xml.stream.XMLStreamConstants.CHARACTERS;
import static javax.xml.stream.XMLStreamConstants.END_ELEMENT;

/**
 * Created with IntelliJ IDEA.
 * User: wiseman
 * Date: 1/6/13
 * Time: 1:08 PM
 * To change this template use File | Settings | File Templates.
 */

public class IOProcessor {

    public static Graph readFromXML(String path) throws XMLStreamException, IOException {

   		File f = new File(path);

   		if (!(f.exists() && f.canRead() && f.isFile())) {
   			throw new IllegalArgumentException();
   		}

   		InputStream in = new FileInputStream(f);
   		XMLInputFactory factory = XMLInputFactory.newInstance();

   		XMLStreamReader parser = factory.createXMLStreamReader(in);

   		Vertex[] tasks = null;
   		int numberOfTasks = -1,
   			taskId = -1,
   			w = -1,
   			c = 0,
   			childId = 0;
   		String value = null;
   		ArrayList<ArrayList<Edge>> backEdges = null;

   		while (parser.hasNext()) {

   			int event = parser.next();

   			if (event == CHARACTERS) {
   				value = parser.getText().trim();
   			} else if (event == END_ELEMENT) {
   				String element = parser.getLocalName();
   //				edge
   				if (element.equals("cost")) {
   					c = Integer.parseInt(value);
   				} else if (element.equals("child")) {
   					childId = Integer.parseInt(value);
   					if (childId < 0 || childId >= numberOfTasks) {
   						throw new IOException("Illegal value");
   					}
   				} else if (element.equals("edge")) {
   					tasks[taskId].addChild(new Edge(c, childId));
   					// adding new edge to back edges
   					backEdges.get(childId).add(new Edge(c, taskId));
   				}
   //				task
   				else if (element.equals("id")) {
   					taskId = Integer.parseInt(value);
   					if (taskId < 0 || taskId >= numberOfTasks) {
   						throw new IOException("Illegal value");
   					}
   				} else if (element.equals("weight")) {
   					w = Integer.parseInt(value);
   					tasks[taskId] = new Vertex(taskId, w);
   				}
   //				tasks creating
   				else if (element.equals("tasksNumber")) {
   					numberOfTasks = Integer.parseInt(value);
   					if (numberOfTasks <= 0) {
   						throw new IOException("Illegal value");
   					}
   					tasks = new Vertex[numberOfTasks];
   					backEdges = new ArrayList<ArrayList<Edge>>(numberOfTasks);
   					for (int i = 0; i < numberOfTasks; i++) {
   						backEdges.add(new ArrayList<Edge>());
   					}
   				}
   			}
   		} // end while

   		// adding parents edges
   		for (int i = 0; i < numberOfTasks; i++) {
   			ArrayList<Edge> edges = backEdges.get(i);
   			if (edges.size() > 0) {
   				for (Edge e : edges) {
   					tasks[i].addParent(e);
   				}
   			}
   		}
   		// graph is ready!
   		return new Graph(tasks);
   	}
}
