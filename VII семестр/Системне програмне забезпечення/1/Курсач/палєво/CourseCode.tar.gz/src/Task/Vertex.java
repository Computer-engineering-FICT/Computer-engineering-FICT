package Task;
import java.util.ArrayList;


/**
 * Vertex. It has a computational cost, edges to child tasks,
 * edges to parent tasks.
 *
 */
public class Vertex {
	

	private int id;
	private int w;
    private ArrayList<Edge> children;
	private ArrayList<Edge> parents;


	public Vertex(int id, int w) {
		this(id, w, null, null);
	}
	
	public Vertex(int id, int w, ArrayList<Edge> children, ArrayList<Edge> parents) {
		setId(id);
		setW(w);
		setChildren(children);
		setParents(parents);
	}

	public int getId() {
		return id;
	}

	public int getW() {
		return w;
	}

	public ArrayList<Edge> getChildren() {
		return children;
	}

	public ArrayList<Edge> getParents() {
		return parents;
	}

	private void setId(int id) {
		if (id < 0) {
			throw new IllegalArgumentException();
		}
		this.id = id;
	}


	private void setW(int w) {
		if (w < 0) {
			throw new IllegalArgumentException();
		}
		this.w = w;
	}


	public void setChildren(ArrayList<Edge> children) {
		if (children == null) {
			children = new ArrayList<Edge>();
		}
		children.trimToSize();
		this.children = children;
	}

	public void setParents(ArrayList<Edge> parents) {
		if (parents == null) {
			parents = new ArrayList<Edge>();
		}
		parents.trimToSize();
		this.parents = parents;
	}
	
	public void addChild(Edge e) {
		if (e == null) {
			throw new IllegalArgumentException();
		}
		children.add(e);
	}
	
	public void addParent(Edge e) {
		if (e == null) {
			throw new IllegalArgumentException();
		}
		parents.add(e);
	}
	
	public void addChild(int cost, int childId) {
		addChild(new Edge(cost, childId));
	}
	
	public void addParent(int cost, int childId) {
		addParent(new Edge(cost, childId));
	}
	
	public boolean hasChildren() {
		return children.size() != 0;
	}
	
	public boolean hasParent() {
		return parents.size() != 0;
	}

	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append('T').append(id).append(':').append(w);
		return s.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + w;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vertex other = (Vertex) obj;
		if (id != other.id)
			return false;
		if (w != other.w)
			return false;
		return true;
	}
}
