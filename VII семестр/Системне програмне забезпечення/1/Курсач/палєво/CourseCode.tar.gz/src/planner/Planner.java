package planner;

import Task.Edge;
import Task.Graph;
import Task.Vertex;
import computerSystem.AbstractResource;
import computerSystem.CUnit;
import computerSystem.SystemTopology;

import java.util.*;


public class Planner {

	
	private Graph g;
	private SystemTopology cs;
    private int[] taskProcessor;
   	private int[] taskST;
   	private int[] taskFT;

    private PriorityQueue<QueueNode<Integer, Edge>> messagesQueue;

	public Planner(Graph g, SystemTopology cs) {
		if (g == null || cs == null) {
			throw new IllegalArgumentException();
		}
		this.g = g;
		taskProcessor = new int[g.size()];
		taskST = new int[taskProcessor.length];
		taskFT = new int[taskProcessor.length];
		Arrays.fill(taskProcessor, -1);
		Arrays.fill(taskST, -1);
		Arrays.fill(taskFT, -1);
		this.cs = cs;
		this.messagesQueue = new PriorityQueue<Planner.QueueNode<Integer,Edge>>();
	}
	
	public SystemTopology plan() {
		// 1. Calculating sl
		Vertex[] tasks = g.getTasks();
		int[] sl = UtilGraphProcessing.calculateStaticLevels(g);
		CUnit[] processors = cs.getProcessors();
		int maximumTime = 0; // for determi
		
		PriorityQueue<QueueNode<Integer, Vertex>> tasksQueue = new PriorityQueue<
				QueueNode<Integer, Vertex>>(taskProcessor.length);

		LinkedList<QueueNode<Integer, Edge>> edgesToParent = 
				new LinkedList<QueueNode<Integer,Edge>>();
		
		ArrayList<Integer> processorsOrder = getProcessorsOrder(processors.length);
		// 2. Adding all ready tasks to priority queue
		for (Vertex t : tasks) {
			if (isReady(t)) {
				tasksQueue.add(new QueueNode<Integer, Vertex>(
						-sl[t.getId()], // priority is less than zero 'cause
//							the node with the least value has the highest priority
						t));
			}
		}
		assert (!tasksQueue.isEmpty());
		
		while (!tasksQueue.isEmpty()) {
			
			Vertex t =
					tasksQueue.poll().value;
			ArrayList<Edge> parents = t.getParents();
			edgesToParent.clear();
			// adding all edges to queue, according to parents' FT
			for (Edge e : parents) {
				int parentId = e.getNeighbour();
				// the lowest FT - the highest priority
				edgesToParent.add(
						new QueueNode<Integer, Edge>(taskFT[parentId], e));
			}
			// searching for processor which provides minimal finish time
				
			int minimalST = Integer.MAX_VALUE;			
			int minimalFT = Integer.MAX_VALUE;
			
			int i = 0;
			
			int bestProcessorId = -1;
			AbstractResource[] bestLink = null;
			
			while (i < processorsOrder.size()) {
				AbstractResource[] tempLink = cs.cloneLinks();
				
				messagesQueue.clear();
				messagesQueue.addAll(edgesToParent);
				
				int processor = processorsOrder.get(i);
				int currentST = 0; // ST(t, P[processor])
				int currentFT = -1; // FT(t, P[processor])
				int execTime = processors[processor].executionTime(t); // execution time on P[processor]
				// routing all messages from parents
				while (!messagesQueue.isEmpty()
						// if it is greater, there is no need to continue with this processor
						&& currentST + execTime < minimalFT
						) {
					Edge e = messagesQueue.poll().value;
					int parentId = e.getNeighbour();
					
					assert (taskST[parentId] >= 0 
							&& taskProcessor[parentId] >= 0
							&& taskFT[parentId] > 0);
					
					int time = taskFT[parentId];
					int length = e.getCost();
					int from = taskProcessor[parentId];
					
//					System.out.printf("Routing message for t%d from P%d to P%d, start time = %d, length = %d",
//							t.getId(), from, processor, time, length);
					int timeOfReceivingMessage = processors[from].
							route(time, length, tempLink, processor, "Hello=)");
					
					if (timeOfReceivingMessage > currentST) {
						currentST = timeOfReceivingMessage;
					}
//					System.out.printf(", got: %d\n", currentST);
				}
				currentFT = processors[processor].
						whenCanOccupy(currentST, execTime)
						+ execTime;
//				System.out.printf("Time of receiving all messages and FT for task %d on p%d is: ST=%d, FT=%d\n",
//						t.getId(), processor, currentST, currentFT);
				// If currentFT is lower than minimalFT, this processor is better than previous one.
				if (currentFT < minimalFT) {
					minimalST = currentST;
					minimalFT = currentFT;
					bestProcessorId = processor;
					bestLink = tempLink;
				}
				i++;
			} // end while, best processor is found
			
			// assigning task to the best processor
			int actualTime = occupyProcessor(bestProcessorId, minimalST, minimalFT, t);
			if (minimalFT > maximumTime) {
				maximumTime = minimalFT;
			}
//			System.out.printf("P%d is occupied by t%d starting from %d\n", bestProcessorId, t.getId(), actualTime);
			cs.setLinks(bestLink);
			// adding all ready successors to queue
			ArrayList<Edge> children = t.getChildren();
			for (Edge e : children) {
				int id = e.getNeighbour();
				if (isReady(tasks[id])) {
					tasksQueue.add(new QueueNode<Integer, Vertex>(
							- (sl[id]), tasks[id]));
				}
			}
		}
		printShedulingResults(maximumTime);
		return cs;
	}
	
	public void printShedulingResults(int maxTime) {
		final char FREE = '-';
		final char TRANSMISSION = 'T';
		if (maxTime <= 0) {
			throw new IllegalArgumentException();
		}
		CUnit[] processors = cs.getProcessors();
		AbstractResource[] links = cs.cloneLinks();

		System.out.printf("TRANSMISSION LINES NUMBER = %d, COMPUTING UNITS NUMBER = %d\n",
                links.length, processors.length);
        System.out.print("\n№");
        for (int i = 0; i<processors.length; i++) {
            System.out.print("\tP"+i);
        }
        for (int i = 0; i<links.length; i++) {
            System.out.print("\tT"+i);
        }
        System.out.println();

		assert (processors.length == links.length + 1);
		ArrayList<LinkedList<Integer>> tasksAssignedToP = 
				new ArrayList<LinkedList<Integer>>(processors.length);
		for (int i = 0; i < processors.length; i++) {
			tasksAssignedToP.add(new LinkedList<Integer>());
		}
		for (int i = 0; i < taskProcessor.length; i++) {
			if (taskProcessor[i] != -1) {
				tasksAssignedToP.get(taskProcessor[i]).add(i);				
			}
		}
		
		for (int i = 0; i <= maxTime; i++) {
			// tick | Pi | Li
			System.out.print(i);
			for (int j = 0; j < processors.length; j++) {
				if (!processors[j].isFreeAtTime(i)) {
					LinkedList<Integer> tasks = tasksAssignedToP.get(j);
					int id = -1;
					Iterator<Integer> it = tasks.iterator();
					while (id == -1 && it.hasNext()) {
						int taskId = it.next();
						if (i >= taskST[taskId] 
								&& i < taskST[taskId] + 
								processors[j].executionTime(g.getTask(taskId))) {
							id = taskId;
						}
					}
					assert (id != -1);
					System.out.print("\t" + id);
				} else {
					System.out.print("\t" + FREE);
				}
			}
			for (int j = 0; j < links.length; j++) {
				if (!links[j].isFreeAtTime(i)) {
					System.out.print("\t" + TRANSMISSION);
				} else {
					System.out.print("\t" + FREE);
				}
			}
			System.out.println();			
		}
	}
	
	private ArrayList<Integer> getProcessorsOrder(int p) {
		if (p < 1) {
			throw new IllegalArgumentException();
		}
		ArrayList<Integer> order = new ArrayList<Integer>(p);
		int delta = 1;
		int middle = p / 2;
		
		order.add(middle);
		while (middle - delta >= 0) {
			order.add(middle - delta);
			if (middle + delta < p) {
				order.add(middle + delta);
			}
			delta++;
		}
		return order;	
	}
	/**
	 * @param processor processor to occupy
	 * @param startTime task's start time
	 * @param FT 
	 * @param t task
	 * @return actual start time. It's greater or equal to startTime.
	 */
	private int occupyProcessor(int processor, int startTime, int FT, Vertex t) {
		if (processor < 0 || processor >= cs.size() 
				|| startTime < 0 || startTime >= FT || t == null) {
			throw new IllegalArgumentException();
		}
		CUnit p = cs.getProcessor(processor);
		int actualST = p.occupy(startTime, p.executionTime(t), t);
		taskProcessor[t.getId()] = processor;
		taskST[t.getId()] = actualST;
		taskFT[t.getId()] = actualST + p.executionTime(t);
		assert (taskFT[t.getId()] == FT);
		return actualST;
	}
	
	/**
	 * @param t
	 * @return if task is ready (it means that all parents are ready),
	 *  returns true;
	 *  false - otherwise.
	 */
	private boolean isReady(Vertex t) {
		ArrayList<Edge> p = t.getParents();
		if (p.size() == 0) {
			return true;
		} else {
			for (Edge e : p) {
				if (taskProcessor[e.getNeighbour()] == -1) {
					// this task isn't assigned to processor, so current is not ready
					return false;
				}
			}
			return true;
		}
	}
	
	private class QueueNode<K extends Comparable<K>, V> implements Comparable<QueueNode<K, V>> {
		
		public K priority;
		
		public V value;
		
		public QueueNode(K priority, V value) {
			if (priority == null || value == null) {
				throw new IllegalArgumentException();
			}
			this.priority = priority;
			this.value  = value;
		}
		
		public int compareTo(QueueNode<K, V> o) {
			return priority.compareTo(o.priority);
		}
	}

	/**
	 * @return the taskProcessor
	 */
	public int[] getTaskProcessor() {
		return taskProcessor;
	}

	/**
	 * @return the taskST
	 */
	public int[] getTaskST() {
		return taskST;
	}

	/**
	 * @return the taskFT
	 */
	public int[] getTaskFT() {
		return taskFT;
	}
}
