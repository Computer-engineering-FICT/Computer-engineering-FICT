package planner;

import Task.Edge;
import Task.Graph;
import Task.Vertex;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * Created with IntelliJ IDEA.
 * User: wiseman
 * Date: 1/7/13
 * Time: 11:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class UtilGraphProcessing {

    private final int WHITE = 0, GRAY = 2, BLACK = 3;

   		private boolean isReversed;

   		private LinkedList<Vertex> tasks;

   		private int[] color;

   		public UtilGraphProcessing() {

   		}

   		public LinkedList<Vertex> sortReversedTopological(Graph g) {
   			isReversed = true;
   			DFS(g);
   			return tasks;
   		}

   //		depth-first search
   		private void DFS(Graph g) {
   			color = new int[g.size()];
   			tasks = new LinkedList<Vertex>();
   			Vertex[] tasks = g.getTasks();
   			for (int i = 0; i < tasks.length; i++) {
   				if (color[i] == 0) {
   					DFS_Visit(g, tasks[i]);
   				}
   			}
   		}

   		private void DFS_Visit(Graph g, Vertex t) {
   			int i = t.getId();
   			if (i >= color.length) {
   				throw new IllegalArgumentException();
   			}
   			if (color[i] != WHITE) {
   				return;
   			}
   			color[i] = GRAY;
   			Iterator<Edge> edgeIt = t.getChildren().iterator();
   			Vertex child;
   			while (edgeIt.hasNext()) {
   				int childId = edgeIt.next().getNeighbour();
   				if (childId >= color.length) {
   					throw new IllegalArgumentException();
   				}
   				if (color[childId] == WHITE) {
   					child = g.getTask(childId);
   					DFS_Visit(g, child);
   				} else if (color[childId] == GRAY) {
   					throw new IllegalArgumentException("Graph g is not a DAG");
   				}
   			}
   			color[i] = BLACK;
   			// adding current task to list
   			if (isReversed) {
   				tasks.addLast(t);
   			} else {
   				tasks.addFirst(t);
   			}
   		}
   		/**
   		 * @param g Graph, which contains these tasks.
   		 * @return static b-levels for every node
   		 * (which are also known as static levels).
   		 * @throws IllegalArgumentException if tasks or graph is equal to null,
   		 * if tasks aren't sorted in topological order,
   		 * or if task has illegal id.
   		 */
   		public static int[] calculateStaticLevels(Graph g) {
   			UtilGraphProcessing p = new UtilGraphProcessing();
   			LinkedList<Vertex> tasks = p.sortReversedTopological(g);
   			return b_levels(tasks, g, true);
   		}

   		private static int[] b_levels(LinkedList<Vertex> tasks, Graph g, boolean isStatic) {
   			if (tasks == null || g == null || tasks.size() != g.size()) {
   				throw new IllegalArgumentException("Null arguments or illegal size");
   			}

   			int[] bLevels = new int[tasks.size()];
   			Arrays.fill(bLevels, -1); // -1 indicates that associated task wasn't visited

   			Iterator<Vertex> it = tasks.iterator();
   			Iterator<Edge> edgeIt;

   			Edge e;
   			Vertex t;

   			int maxBLevel = 0;
   			int childLevel = 0;
   			int childId;
   			while (it.hasNext()) {
   				t = it.next();
   				if (t.getId() >= bLevels.length) {
   					throw new IllegalArgumentException("Illegal task id");
   				}
   				edgeIt = t.getChildren().iterator();
   				// looking for maximum child's b-level.
   				maxBLevel = 0;
   				while (edgeIt.hasNext()) {
   					e = edgeIt.next();
   					childId = e.getNeighbour();
   					if (bLevels[childId] == -1) {
   						throw new IllegalArgumentException("Tasks are not sorted topologically");
   					} else {
   						childLevel = bLevels[childId];
   						if (!isStatic) {
   							// static b-level doesn't include communication cost.
   							childLevel += e.getCost();
   						}
   						if (childLevel > maxBLevel) {
   							maxBLevel = childLevel;
   						}
   					}
   				}
   				bLevels[t.getId()] = maxBLevel + t.getW();
   			}
   			return bLevels;
   		}

}
