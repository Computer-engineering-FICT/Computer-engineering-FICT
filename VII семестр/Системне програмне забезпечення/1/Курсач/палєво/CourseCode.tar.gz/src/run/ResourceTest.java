//package run;
//
//import static org.junit.Assert.*;
//
//import java.util.Iterator;
//
//import org.junit.Test;
//
//import computerSystem.AbstractResource;
//
//
//public class ResourceTest {
//
//	@Test
//	public void test() {
//		AbstractResource<Integer> r = new AbstractResource<Integer>();
//		int[] st = {0, 2, 10, 30, 40};
//		int[] l = {1, 4, 1, 20, 30};
//		for (int i = 0; i < st.length;i++) {
//			assertEquals(st[i], r.whenCanOccupy(st[i], l[i]));
//		}
//		System.out.println(r);
//		Integer i = 2;
//		// occupying 1
//		int s = 1;
//		int e = 3;
//		assertEquals(s, r.occupy(s, (e - s), i));
//
//		System.out.println(r);
//
//		// occupying 2
//		s = 2;
//		e = 4;
//		assertEquals(3, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 3
//		s = 5;
//		e = 7;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 4
//		s = 9;
//		e = 11;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 5
//		s = 7;
//		e = 9;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 6
//		s = 20;
//		e = 30;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 7
//		s = 12;
//		e = 15;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 8
//		s = 15;
//		e = 20;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 9
//		s = 11;
//		e = 12;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 10
//		s = 0;
//		e = 20;
//		assertEquals(30, r.occupy(s, (e - s), i));
//		System.out.println(r);
//		// occupying 11
//		s = 0;
//		e = 1;
//		assertEquals(s, r.occupy(s, (e - s), i));
//		System.out.println(r);
//
//
//		assertTrue(r.clone().equals(r));
//		assertTrue(r.equals(r.clone()));
//
//		Iterator<AbstractResource<Integer>.TSp> it = r.clone().iterator();
//		while (it.hasNext()) {
//			AbstractResource<Integer>.TSp space = it.next();
//			System.out.println(space.getStartTime() + ": " + space.getValue());
//		}
//	}
//
//}
