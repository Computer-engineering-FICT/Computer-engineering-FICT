//package run;
//
//import org.junit.runner.JUnitCore;
//import org.junit.runner.RunWith;
//import org.junit.runners.Suite;
//
//@RunWith(Suite.class)
//@Suite.SuiteClasses({
//	ResourceTest.class
//})
//public class TestAll {
//
//	/**
//	 * Launch the test.
//	 *
//	 * @param args the command line arguments
//	 *
//	 * @generatedBy CodePro at 30.09.12 14:14
//	 */
//	public static void main(String[] args) {
//		JUnitCore.runClasses(new Class[] { TestAll.class });
//	}
//}
