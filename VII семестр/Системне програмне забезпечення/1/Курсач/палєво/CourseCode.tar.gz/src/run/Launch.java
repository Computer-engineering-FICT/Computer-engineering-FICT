package run;

import Task.*;

import computerSystem.SystemTopology;
import planner.Planner;

import javax.xml.stream.XMLStreamException;
import java.io.IOException;
import java.util.*;

public class Launch {

    private static String pathToTask = "resources/test6.xml";
    private static boolean consoleInput = false;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Graph g;
        try {

            if (consoleInput==true) {
                g=consoleInput();
            }

            else {
                g = IOProcessor.readFromXML(pathToTask);
            }

			System.out.println(Arrays.toString(g.getTasks()));
			// Sheduling		
			Planner sheduler = new Planner(g, new SystemTopology(
//					new double[] {0.9, 0.6, 0.93, 0.7, 0.89}));
                    new double[] {0.9, 0.5, 0.93, 0.69}));
//                   new double[] {0.8, 0.75, 0.78, 0.63}));
//                    new double[] {0.5, 0.95, 0.7}));

//                    new double[] {1.0, 2.0, 1.0}));


//                    new double[]{}));

			sheduler.plan();

		} catch (XMLStreamException e) {
            System.out.println("Error occured while processing XML-file. Stack-trace:");
			e.printStackTrace();
		} catch (IOException e) {
            System.out.println("Error occured during input of data.");
			e.printStackTrace();
		}
	}


    public static Graph consoleInput() throws IOException {
        Scanner in = new Scanner(System.in);
        int nodesNumber = -1;
        do {
        	System.out.println("Input nodes number: ");
        	try {
        	    nodesNumber = in.nextInt();
        	} catch (InputMismatchException e) {
        	    in.next();
        	}
        } while (nodesNumber <= 0);

        ArrayList<LinkedList<Edge>> backEdges = new ArrayList<LinkedList<Edge>>(nodesNumber);
        for (int i = 0; i < nodesNumber; i++) {
            backEdges.add(new LinkedList<Edge>());
        }
        Graph g = new Graph(nodesNumber);
        for (int i = 0; i < nodesNumber; i++) {
            int w = -1;
        	do {
        	    System.out.printf("Input node's %d computational cost: ", i);
        		try {
        		    w = in.nextInt();
        		} catch (InputMismatchException e) {
        		    in.next();
        		}

        	} while (w <= 0);
        	Vertex task = new Vertex(i, w);

        	int c = -1;
        	int dest = -1;
        	int proceed = 'n';
        	do {
        	    System.out.println(
        		"Do you want to enter one more edge (1 for yes or 0 for not)?");
        		if ((proceed = in.nextInt()) == 1) {
        		do {
        		    c = -1;
        			dest = -1;
        		try {
        		    System.out.println("Input communication cost & destination task: ");
        			c = in.nextInt();
        			dest = in.nextInt();
        		} catch (InputMismatchException e) {
        		    in.next();
        		}

                } while (c <= 0 || dest < 0 || dest >= nodesNumber);
        	    // adding edge to the task
        	    task.addChild(new Edge(c, dest));
        	    // adding edge to this task from its child
        	    backEdges.get(dest).add(new Edge(c, i));
        	}
        	} while (proceed == 1);
        	    g.setTask(task);
        	}

        	// adding all backEdges
        	for (int i = 0; i < nodesNumber; i++) {
        		LinkedList<Edge> edges = backEdges.get(i);
        		if (edges.size() > 0) {
        			Vertex child = g.getTask(i);
        			for (Edge e : edges) {
        				child.addParent(e);
        			}
        		}
        	}
        in.close();
        return g;
    }

}
