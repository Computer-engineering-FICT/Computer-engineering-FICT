package computerSystem;

import Task.Vertex;

import java.util.ArrayList;

public class CUnit extends AbstractResource<Vertex> {
	
	private double k;
	private RoutingTable table;

	private final int id;
	
	public CUnit(int id, double k, RoutingTable table) {
		super();
		if (id < 0 || k <= 0 || table == null) {
			throw new IllegalArgumentException();
		}
		this.id = id;
		this.k = k;
		this.table = table;
	}
	
	public int executionTime(Vertex t) {
		return executionTime(t.getW());
	}

	private int executionTime(int w) {
		return (int) Math.ceil(w / k);
	}

    public double getK() {
   		return k;
   	}

   	public RoutingTable getTable() {
   		return table;
   	}

   	public void setTable(RoutingTable table) {
   		this.table = table;
   	}

	public int route(int time, int size,
			AbstractResource[] links, int to, Object message) {
		if (time < 0 || size <= 0 || 
				links == null || links.length < 1
				) {
			throw new IllegalArgumentException();
		}
		if (to == id) {
			return time;
		}
		ArrayList<Integer> route = table.findRoute(to);
		if (route == null) {
			throw new IllegalArgumentException();
		}
		int currentTime = time;
		for (int linkNumber : route) {
			if (linkNumber < 0 || linkNumber >= links.length) {
				throw new IllegalArgumentException();
			}
			currentTime = links[linkNumber].occupy(currentTime, size, message)
					+ size; // time of the transmission finishes			
		}		
		return currentTime;
	}	
	


}
