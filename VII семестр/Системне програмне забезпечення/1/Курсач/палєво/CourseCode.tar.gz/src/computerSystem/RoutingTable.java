package computerSystem;

import java.util.ArrayList;

public class RoutingTable {
	
	private int[] dest;
	private ArrayList<ArrayList<Integer>> route;
	
	public RoutingTable(int[] dest, ArrayList<ArrayList<Integer>> route) {
		if (dest == null || route == null ||
				dest.length != route.size()) {
			throw new IllegalArgumentException();
		}
		this.dest = dest;
		this.route = route;
	}

	public ArrayList<Integer> findRoute(int dest) {
		for (int i = 0; i < this.dest.length; i++) {
			if (this.dest[i] == dest) {
				return route.get(i);
			}
		}
		return null;
	}
	
	public String toString() {
		StringBuilder s = new StringBuilder();
		for (int i = 0; i < dest.length; i++) {
			s.append(dest[i]).append(':');
			for (Integer link : route.get(i)) {
				s.append(' ').append(link);
			}
			s.append('\n');
		}
		return s.toString();
	}
}
