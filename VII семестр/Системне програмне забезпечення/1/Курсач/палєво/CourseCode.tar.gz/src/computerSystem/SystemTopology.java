package computerSystem;

import java.util.ArrayList;

public class SystemTopology {
	
	private CUnit[] proc;
	
	private AbstractResource[] links;
	
	public SystemTopology(double[] c) {
		proc = new CUnit[c.length];
		links = new AbstractResource[c.length - 1];
		
		int last = c.length - 1;
		int[] destination;
		ArrayList<ArrayList<Integer>> routes;
		
		for (int i = 0; i < c.length; i++) {
			int k = 0;
			destination = new int[last];
			routes = new ArrayList<ArrayList<Integer>>(last);
			ArrayList<Integer> previousRoute = new ArrayList<Integer>();
			// Routes to 'left' processors
//			int j = i - 1;
//			for (; j >= 0; j--) {
//				previousRoute.add(j);
//
//				assert (k < last);
//				destination[k] = j;
//				routes.add(previousRoute);
//				k++;
//
//				previousRoute = (ArrayList<Integer>) previousRoute.clone();
//			}
			// Routes to 'right' processors
            k = fillLeftRoutes(destination, routes, i);
//			previousRoute.clear();

//			j = i + 1;
//			for (; j < c.length; j++) {
//				previousRoute = (ArrayList<Integer>) previousRoute.clone();
//				previousRoute.add(j - 1);
//
//				assert (k < last);
//				destination[k] = j;
//				routes.add(previousRoute);
//				k++;
//			}
            fillRightRoutes(destination, routes, i, k);
			proc[i] = new CUnit(i, c[i], new RoutingTable(destination, routes));
			if (i != last) {
				links[i] = new AbstractResource();
			}
//			System.out.printf("P%d:\n%s", i, proc[i].getTable());
		}		
	}
	
	public AbstractResource[] cloneLinks() {
		AbstractResource[] cloned = new AbstractResource[links.length];
		for (int i = 0; i < links.length; i++) {
			cloned[i] = links[i].clone();
		}
		return cloned;
	}

	public CUnit[] getProcessors() {
		return proc;
	}

	public CUnit getProcessor(int i) {
		if (i < 0 || i >= proc.length) {
			throw new IllegalArgumentException();
		}
		return proc[i];
	}

	public void setLinks(AbstractResource[] links) {
		if (links == null ||
				this.links == null ||
				links.length != this.links.length) {
			throw new IllegalArgumentException();
		}
		this.links = links;
	}

	public int size() {
		return proc.length;
	}

    private int fillLeftRoutes (int[] dest, ArrayList<ArrayList<Integer>> routes, int i) {
        int j = i - 1;
        int k = 0;
        int last = proc.length-1;
        ArrayList<Integer> previousRoute = new ArrayList<Integer>();
        for (; j >= 0; j--) {
            previousRoute.add(j);
        	assert (k < last);
        	dest[k] = j;
        	routes.add(previousRoute);
        	k++;
        	previousRoute = (ArrayList<Integer>) previousRoute.clone();
        }
        return k;
    }

    private void fillRightRoutes (int[] dest, ArrayList<ArrayList<Integer>> routes, int i, int k) {
        int j = i + 1;
        ArrayList<Integer> previousRoute = new ArrayList<Integer>();
        int last = proc.length-1;

        for (; j < proc.length; j++) {
            previousRoute = (ArrayList<Integer>) previousRoute.clone();
        	previousRoute.add(j - 1);
        	assert (k < last);
        	dest[k] = j;
        	routes.add(previousRoute);
        	k++;
        }
    }
	
}
