package computerSystem;

import java.util.Iterator;

/**
 * Contains information about resource's availability. 
 * Links, processors are resources.
 * @author �������� �.�.
 *
 */
public class AbstractResource<V> {
	
	private TSp firstSpace;
	
	private int numberOfOccupiedSlots;
	
	public AbstractResource() {
		firstSpace = new TSp();
		numberOfOccupiedSlots = 0;
	}
	
	private AbstractResource(TSp firstSpace, int numberOfOccupiedSlots) {
		if (firstSpace == null || firstSpace.startTime != 0) {
			throw new IllegalArgumentException();
		}
		this.firstSpace = firstSpace;
		this.numberOfOccupiedSlots = numberOfOccupiedSlots;
	}

	private TSp whatCanOccupy(int startTime, int length) {
		if (startTime < 0 || length <= 0) {
			throw new IllegalArgumentException();
		}
		Iterator<TSp> it = iterator();
		TSp space = null;
		while (it.hasNext()) {
			space = it.next();
			if (space.isFree) {
				
				if ( startTime >= space.startTime && 
						(space.length - (startTime - space.startTime) >= length
						|| space.length == -1)
					|| // there is no free space before startTime
					(startTime < space.startTime && space.length >= length)) {
					break;
				}
				
			}
		}
		assert (space != null 
				&& space.isFree);
		return space;
	}

	public int whenCanOccupy(int startTime, int length) {
		
		TSp space = whatCanOccupy(startTime, length);
		if (space.startTime <= startTime) {
			assert (space.length == -1 
					|| space.length - (startTime - space.startTime) >= length);
			return startTime;
		} else {
			try {
				assert (space.length == -1 || space.length >= length);				
			} catch (AssertionError e) {
				System.out.println(space);
				throw e;
			}
			return space.startTime;
		}
	}
	
	public int occupy(int startTime, int length, V value) {
		TSp space = whatCanOccupy(startTime, length);
		//
		int actualStartTime;
		if (space.startTime <= startTime) {
			actualStartTime = startTime;
		} else {
			actualStartTime = space.startTime;
		}
		if (actualStartTime == space.startTime && space.length == length) {
			// Time space fits accurately to specified start time and length
			space.isFree = false;
			space.value = value;
		} else {
			int spaceEnd = space.startTime + space.length;
			TSp freeSpaceBefore = null, freeSpaceAfter = null;
			if (actualStartTime > space.startTime) {
				// Creating new space before
				// so there is a free space
				int freeSpaceLength = actualStartTime - space.startTime;
				if (space.prev != null && space.prev.isFree) {
					space.prev.length += freeSpaceLength;
				} else {
					freeSpaceBefore = new TSp(space.startTime, freeSpaceLength,
							true, space, space.prev, null);
					if (space.prev == null) {
						firstSpace = freeSpaceBefore;
					} else {
						space.prev.next = freeSpaceBefore;
					}
					space.prev = freeSpaceBefore;
				}
			} else {
				assert (actualStartTime == space.startTime);
				// there is no free space before
			}
			
			if (actualStartTime + length < space.startTime + space.length
					|| space.length == -1) {
				// There is a free space after
				int freeSpaceAfterStart = actualStartTime + length,
						freeSpaceAfterLength = spaceEnd - freeSpaceAfterStart;
				if (space.next != null && space.next.isFree) {
					assert (space.length != -1);
					// merging next and new space
					space.next.startTime = freeSpaceAfterStart;
					if (space.next.length != -1) {
						space.next.length += freeSpaceAfterLength;
					}
				} else {
					// next space isn't free or does not exist at all.
					if (space.next == null) {
						freeSpaceAfterLength = -1;
					}						
					freeSpaceAfter = new TSp(freeSpaceAfterStart,
							freeSpaceAfterLength, true, space.next, space, null);
					if (space.next != null) {
						assert (!space.next.isFree);
						space.next.prev = freeSpaceAfter;
					}
				}
			}
			// applying new startTime, length, and neighbours if necessary
			space.startTime = actualStartTime;
			space.length = length;
			space.isFree = false;
			space.value = value;
			
			if (freeSpaceBefore != null) {
				space.prev = freeSpaceBefore;
			}
			if (freeSpaceAfter != null) {
				space.next = freeSpaceAfter;
			}
		}
		numberOfOccupiedSlots++;
		return actualStartTime;
	}
	
	public Iterator<TSp> iterator() {
		
		return new Iterator<TSp>() {
			
			TSp current = firstSpace;
			

			public boolean hasNext() {
				return current != null;
			}


			public TSp next() {
				TSp prev = current;
				current = prev.next;
				return prev;
			}


			public void remove() {
				throw new UnsupportedOperationException();
			}
			
		};
	}
	
	public int getNumberOfOccupiedSlots() {
		return numberOfOccupiedSlots;
	}
	
	public boolean isFreeAtTime(int time) {
		if (time < 0) {
			throw new IllegalArgumentException();
		}
		return whenCanOccupy(time, 1) == time;
	}
	
	public String toString() {
		StringBuilder s = new StringBuilder();
		Iterator<TSp> it = iterator();
		while (it.hasNext()) {
			s.append(it.next());
		}
		return s.toString();
	}
	
//	Provides deep clone of resource and all time spaces
	public AbstractResource<V> clone() {
		return new AbstractResource<V>(firstSpace.clone(), numberOfOccupiedSlots);
	}
	
	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		if (!(o instanceof AbstractResource)) {
			return false;
		}
		AbstractResource other = (AbstractResource) o;
		if (!firstSpace.equals(other.firstSpace)) {
			return false;
		}
		if (numberOfOccupiedSlots != other.numberOfOccupiedSlots) {
			return false;
		}
		return true;
		
	}

    public class TSp {

                V value;

                int startTime;
                int length;
                boolean isFree;
        		TSp next, prev;

        		public TSp(int startTime, int length, boolean isFree,
                           TSp next, TSp prev, V value) {
        			if (startTime < 0) {
        				throw new IllegalArgumentException();
        			}

        			if ((length == -1 && (next != null || !isFree)) ||
        					(!isFree && value == null)) {
        				throw new IllegalArgumentException();
        			}

        			this.startTime = startTime;
        			this.length = length;
        			this.isFree = isFree;
        			this.next = next;
        			this.prev = prev;
        			this.value = value;
        		}

        		/**
        		 * Creates time space from t = 0 with infinite length.
        		 */
        		public TSp() {
        			this(0, -1, true, null, null, null);
        		}

        		public int getStartTime() {
        			return startTime;
        		}

        		public int getLength() {
        			return length;
        		}

        		public boolean isFree() {
        			return isFree;
        		}

        		public V getValue() {
        			return value;
        		}

        		public String toString() {
        			StringBuilder s = new StringBuilder();
        			s.append('[');
        			if (isFree) {
        				s.append('F');
        			} else {
        				s.append('O');
        			}
        			s.append(':').append(startTime).append(',')
        			.append(length).append(']');
        			return s.toString();
        		}

        //		Clones only next spaces, cause previous was certainly cloned
        		public TSp clone() {
        			TSp clone = new TSp(startTime, length, isFree,
        					null, null, value);
        			if (next != null) {
        				TSp nextClone = next.clone();

        				clone.next = nextClone;
        				nextClone.prev = clone;
        			}
        			return clone;
        		}

        		@Override
        		public int hashCode() {
        			final int prime = 31;
        			int result = 1;
        			result = prime * result + getOuterType().hashCode();
        			result = prime * result + (isFree ? 1231 : 1237);
        			result = prime * result + length;
        			result = prime * result + startTime;
        			return result;
        		}

        		@Override
        		public boolean equals(Object obj) {
        			if (this == obj)
        				return true;
        			if (obj == null)
        				return false;
        			if (getClass() != obj.getClass())
        				return false;
        			TSp other = (TSp) obj;
        			if (!getOuterType().equals(other.getOuterType()))
        				return false;
        			if (isFree != other.isFree)
        				return false;
        			if (length != other.length)
        				return false;
        			if (startTime != other.startTime)
        				return false;

        			if (next == null) {
        				if (!(other.next == null)) {
        					return false;
        				}
        			} else if (!next.equals(other.next)) {
        				return false;
        			}

        			if (prev == null) {
        				if (!(other.prev == null)) {
        					return false;
        				}
        			} // previous spaces are not checked recursively

        			if (value == null) {
        				if (other.value != null) {
        					return false;
        				}
        			}

        			return true;
        		}

        		private AbstractResource<V> getOuterType() {
        			return AbstractResource.this;
        		}


        	}

}
