package com;

import java.util.ArrayList;
import java.util.List;

public class AlternativeConectionsList {


    public static List<AlternativeConection> changeConectionList(ConnectionList connectionList){
        List<AlternativeConection> res = new ArrayList<>();
        for (Connection connection : connectionList.getConnectionList()){
            res.add(new AlternativeConection(change(connection.getFromNode()),change(connection.getToNode()), connection.getProbability(), connection.getL()));
        }

        return res;
    }

    public static void print(List<AlternativeConection> conectionList){
        for (AlternativeConection conection : conectionList){
            System.out.println(conection);
        }
    }

    public static boolean isSuchConnectionInList(List<AlternativeConection> alternativeConectionsList, int NodeFrom, int NodeTo){
        for (AlternativeConection alternativeConection: alternativeConectionsList){
            if (alternativeConection.getFromNode()==NodeFrom && alternativeConection.getToNode()==NodeTo){
                return true;
            }
        }
        return false;
    }

    public static AlternativeConection searchConnectionInList(List<AlternativeConection> alternativeConectionsList, int NodeFrom, int NodeTo){
        for (AlternativeConection alternativeConection: alternativeConectionsList){
            if (alternativeConection.getFromNode()==NodeFrom && alternativeConection.getToNode()==NodeTo){
                return alternativeConection;
            }
        }
        return null;
    }

    private static int change(Node node){
        switch (node){
            case CPU: return 0;
            case NORTH_BRIDGE: return 1;
            case RAM: return 2;
            case SOUTH_BRIDGE: return 3;
            case ROUTER: return 4;
            case OPTIC_STORAGE: return 5;
            case MAGNETIC_STORAGE: return 6;
            case ISA: return 7;
            case LPT: return 8;
            case COM: return 9;
            case GPU: return 10;
            default: throw new IllegalArgumentException("node "+node+" was not found");
        }
    }

    static class AlternativeConection{
        private int fromNode;
        private int toNode;
        private double probability;
        private double L;

        public AlternativeConection(int fromNode, int toNode, double probability, double L) {
            this.fromNode = fromNode;
            this.toNode = toNode;
            this.probability = probability;
            this.L = L;
        }

        public double getL() {
            return L;
        }

        public int getFromNode() {
            return fromNode;
        }

        public int getToNode() {
            return toNode;
        }

        public double getProbability() {
            return probability;
        }

        @Override
        public String toString() {
            return "AlternativeConection{" +
                    "fromNode=" + fromNode +
                    ", toNode=" + toNode +
                    ", probability=" + probability +
                    "}\n";
        }
    }
}
