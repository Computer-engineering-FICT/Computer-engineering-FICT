package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Peak {
    private String name;
    private Condition condition;
    private List<VertexLink> nextNodes = new ArrayList<>();
    private List<Peak> previousNodes = new ArrayList<>();
    private List<String> nextNames = new ArrayList<>();
    private List<String> previousNames = new ArrayList<>();

    public Peak(String name, Condition condition) {
        this.name = name;
        this.condition = condition;
    }

    public void setNextNodes(VertexLink nextNodes) {
        this.nextNodes.add(nextNodes);
    }

    public void setPreviousNodes(Peak previousNodes) {
        this.previousNodes.add(previousNodes);
    }

    public String getName() {
        return name;
    }

    public Condition getCondition() {
        return condition;
    }

    public boolean equelsByCondition(Condition cond){
        if (this.getCondition().equals(cond)){
            return true;
        }
        return false;
    }

    public int getIntName(){
        StringBuilder res = new StringBuilder(name);
        res.deleteCharAt(0);
        return Integer.valueOf(res.toString());
    }

    public List<VertexLink> getNextNodes() {
        return nextNodes;
    }

    public List<Peak> getPreviousNodes() {
        return previousNodes;
    }

    @Override
    public String toString() {
        for (VertexLink vertexLink: nextNodes){
            nextNames.add(vertexLink.getVertex().getName());
        }
        for (Peak peak: previousNodes){
            previousNames.add(peak.getName());
        }
        return "\n"+"Peak{" +
                "name='" + name + '\'' +
                ", " + condition +
                ", nextNodes=" + nextNames +
                ", previousNodes=" + previousNames +
                '}';
    }

    static class Condition {
        private int[] condition = new int[Node.values().length];

        public Condition(int... condition) {
            this.condition = condition;
        }

        public int[] toArray(){
            return condition;
        }

        public static Condition conditionCopy(Condition condition){
            Condition res = new Condition(0,0,0,0,0,0,0,0,0,0,0);
            for (int i = 0; i <condition.toArray().length; i++) {
                res.toArray()[i] = condition.toArray()[i];
            }
//            System.out.println(res.toString());
            return res;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Condition condition1 = (Condition) o;

            return Arrays.equals(condition, condition1.condition);

        }

        @Override
        public String toString() {
            return "condition=" + Arrays.toString(condition);
        }
    }

    static class VertexLink{
        private Peak peak;
        private double LP;

        public VertexLink(Peak peak, double LP) {
            this.peak = peak;
            this.LP = LP;
        }

        public Peak getVertex() {
            return peak;
        }

        public double getLP() {
            return LP;
        }
    }
}
