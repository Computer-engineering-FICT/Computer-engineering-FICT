package com;

import static com.ConnectionList.check;
import static com.Node.*;

public class Model3Main {
    public static final int NumberOfTasks = 3;

    public static void main(String[] args) {
        ConnectionList connectionList = new ConnectionList();
        FillConnectionList(connectionList);
//        connectionList.print(connectionList);
        Tree tree = new Tree();

        tree.build(CPU, connectionList);
//        System.out.println(tree.toString());

        int n = values().length;
        double[] result = new double[n];
        result = TreeToResult.treeToTime(tree);


        System.out.println(CPU + ": " + String.format("%7.2f", (result[0] * 100.0)));
        System.out.println(NORTH_BRIDGE + ": " + String.format("%7.2f", result[1] * 100));
        System.out.println(RAM + ": " + String.format("%7.2f", result[2] * 100));
        System.out.println(SOUTH_BRIDGE + ": " + String.format("%7.2f", result[3] * 100));
        System.out.println(ROUTER + ": " + String.format("%7.2f", result[4] * 100));
        System.out.println(OPTIC_STORAGE + ": " + String.format("%7.2f", result[5] * 100));
        System.out.println(MAGNETIC_STORAGE + ": " + String.format("%7.2f", result[6] * 100));
        System.out.println(ISA + ": " + String.format("%7.2f", result[7] * 100));
        System.out.println(LPT + ": " + String.format("%7.2f", result[8] * 100));
        System.out.println(COM + ": " + String.format("%7.2f", result[9] * 100));
        System.out.println(GPU + ": " + String.format("%7.2f", result[10] * 100));

        System.out.println();

        //System.out.println(tree);

    }


    private static void FillConnectionList(ConnectionList connectionList) {

        connectionList.addConection(new Connection(CPU, NORTH_BRIDGE, 1.0));

        connectionList.addConection(new Connection(NORTH_BRIDGE, CPU, 0.25));
        connectionList.addConection(new Connection(NORTH_BRIDGE, GPU, 0.1));
        connectionList.addConection(new Connection(NORTH_BRIDGE, SOUTH_BRIDGE, 0.5));
        connectionList.addConection(new Connection(NORTH_BRIDGE, RAM, 0.15));

        connectionList.addConection(new Connection(RAM, NORTH_BRIDGE, 1.0));
        connectionList.addConection(new Connection(GPU, NORTH_BRIDGE, 1.0));

        connectionList.addConection(new Connection(SOUTH_BRIDGE, NORTH_BRIDGE, 1.0));
        connectionList.addConection(new Connection(SOUTH_BRIDGE, ISA, 0.0));
        connectionList.addConection(new Connection(SOUTH_BRIDGE, ROUTER, 0.0));
        connectionList.addConection(new Connection(SOUTH_BRIDGE, MAGNETIC_STORAGE, 0.0));
        connectionList.addConection(new Connection(SOUTH_BRIDGE, OPTIC_STORAGE, 0.0));

        connectionList.addConection(new Connection(ROUTER, SOUTH_BRIDGE, 1.0));
        connectionList.addConection(new Connection(OPTIC_STORAGE, SOUTH_BRIDGE, 1.0));
        connectionList.addConection(new Connection(MAGNETIC_STORAGE, SOUTH_BRIDGE, 1.0));

        connectionList.addConection(new Connection(ISA, COM, 0.4));
        connectionList.addConection(new Connection(ISA, LPT, 0.6));

        connectionList.addConection(new Connection(COM, ISA, 1.0));

        connectionList.addConection(new Connection(LPT, CPU, 1.0));

        check(connectionList);
    }
}
