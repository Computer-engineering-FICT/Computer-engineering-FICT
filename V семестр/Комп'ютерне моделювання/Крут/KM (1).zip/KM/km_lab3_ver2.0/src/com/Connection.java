package com;

public class Connection {
    private Node fromNode;
    private Node toNode;
    private double probability;
    private double L;

    public Connection(Node fromNode, Node toNode, double probability) {
        this.fromNode = fromNode;
        this.toNode = toNode;
        this.probability = probability;
        setL(fromNode);
    }

    public Node getFromNode() {
        return fromNode;
    }

    public Node getToNode() {
        return toNode;
    }

    public double getProbability() {
        return probability;
    }

    private void setL(Node fromNode) {
        switch (fromNode) {
            case CPU:
                L = 1.0/ 5;
                break;
            case NORTH_BRIDGE:
                L = 1.0 / 0.01;
                break;
            case RAM:
                L = 1.0 / 7;
                break;
            case SOUTH_BRIDGE:
                L = 1.0 / 12;
                break;
            case ROUTER:
                L = 1.0 / 20;
                break;
            case OPTIC_STORAGE:
                L = 1.0 / 22;
                break;
            case MAGNETIC_STORAGE:
                L = 1.0 / 25;
                break;
            case ISA:
                L = 1.0 / 32;
                break;
            case LPT:
                L = 1.0 / 27;
                break;
            case COM:
                L = 1.0 / 35;
                break;
            case GPU:
                L = 1.0 / 30;
                break;
            default:
                throw new IllegalArgumentException("No such device");
        }
    }

    public double getL() {
        return L;
    }

    @Override
    public String toString() {
        return "Connection{" +
                "fromNode=" + fromNode +
                ", toNode=" + toNode +
                ", probability=" + probability +
                '}';
    }
}
