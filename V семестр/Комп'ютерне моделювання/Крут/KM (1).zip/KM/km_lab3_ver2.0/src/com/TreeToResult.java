package com;

import java.util.List;

import static com.Peak.*;

public class TreeToResult {
    public static double[] treeToTime(Tree tree){
        int n = tree.getSize();
        double[][] res = new double[n][n];
        for (int i = 0; i <n; i++) {
            for (int j = 0; j <n; j++) {
                res[i][j] = 0;
            }
        }
        List<VertexLink> vertexLinks;
        for (int i = 0; i < n; i++) {
            vertexLinks = tree.getVertexByIndex(i).getNextNodes();
            for (int j = 0; j < n; j++) {
                for (VertexLink vertexlink: vertexLinks){
                    if (j==vertexlink.getVertex().getIntName()){
                        res[i][j] = vertexlink.getLP();
                    }
                }
            }

//            System.out.println("================================================");
//            for (VertexLink link : vertexLinks) {
//                System.out.println(link.getVertex().toString());
//            }
        }

        return probabilityToTime(MatrixToSystem(res),tree);
    }

    private static double[] MatrixToSystem(double[][] l_matix){
        int n = l_matix.length;
        double[][] res = new double[n][n];
        double[]res2 = new double[n];
        for (int i = 0; i <n; i++) {
            res2[i]=0;
            for (int j = 0; j <n; j++) {
                res[i][j] = 0;
            }
            if (i==n-1){
                for (int j = 0; j <n; j++) {
                    res[i][j] = 1;
                }
                res2[i]=1;
            }
        }

        double buf;
        for (int i = 0; i <n-1; i++) {
            buf=0;
            for (int j = 0; j < n; j++) {
                if(i==j){
                    for (int k = 0; k < n; k++) {
                        buf=buf-l_matix[i][k];
                    }
                    res[i][j]=buf;
                }
                else {
                    res[i][j] = l_matix[j][i];
                }
            }
        }

        return Gauss.gauss(res, res2);

    }

    public static double[] probabilityToTime(double[] prob, Tree tree){
        int n = prob.length;
        double[] res = new double[Node.values().length];
        for (int i = 0; i < res.length; i++) {
            res[i]=0;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < Node.values().length; j++) {
                if (tree.getVertexByIndex(i).getCondition().toArray()[j]>0){
                    res[j]=res[j]+prob[i];
                }
            }
        }
        return res;
    }

}
