package com;

import java.util.ArrayList;
import java.util.List;

public class ConnectionList {

    private List<Connection> connectionList = new ArrayList<>();

    public void addConection(Connection connection) {
        this.connectionList.add(connection);
    }

    public List<Connection> getConnectionList() {
        return connectionList;
    }

    public List<Connection> getConectionFromNode(Node node) {
        List<Connection> res = new ArrayList<>();
        for (Connection connection : connectionList){
            if (connection.getFromNode().equals(node)){
                res.add(connection);
            }
        }
        return res;
    }

    public static void check(ConnectionList connectionList){
        double i = 0;
        for (Connection connection : connectionList.getConnectionList()) {
            i = i+ connection.getProbability();
        }
        if (i!=Node.values().length) throw new IllegalArgumentException("False probability");
    }

    public static void print(ConnectionList connectionList){
        for (Connection connection : connectionList.getConnectionList()){
            System.out.println(connection);
        }
    }
}
