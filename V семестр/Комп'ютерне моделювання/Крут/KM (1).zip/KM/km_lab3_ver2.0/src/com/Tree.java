package com;

import java.util.ArrayList;
import java.util.List;

import static com.AlternativeConectionsList.*;
import static com.Model3Main.NumberOfTasks;
import static com.Peak.Condition;
import static com.Peak.Condition.conditionCopy;
import static com.Peak.VertexLink;

public class Tree {
    private List<Peak> tree = new ArrayList<>();

    public Peak getVertexByIndex(int index) {
        return tree.get(index);
    }

    public void addVertex(Peak peak) {
        tree.add(peak);
    }

    private void setStartNode(Node startNode) {
        switch (startNode) {
            case CPU:
                this.tree.add(new Peak("M0", new Condition(NumberOfTasks, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)));
                break;
            case NORTH_BRIDGE:
                this.tree.add(new Peak("M0", new Condition(0, NumberOfTasks, 0, 0, 0, 0, 0, 0, 0, 0, 0)));
                break;
            case RAM:
                this.tree.add(new Peak("M0", new Condition(0, 0, NumberOfTasks, 0, 0, 0, 0, 0, 0, 0, 0)));
                break;
            case SOUTH_BRIDGE:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, NumberOfTasks, 0, 0, 0, 0, 0, 0, 0)));
                break;
            case ROUTER:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, NumberOfTasks, 0, 0, 0, 0, 0, 0)));
                break;
            case OPTIC_STORAGE:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, 0, NumberOfTasks, 0, 0, 0, 0, 0)));
                break;
            case MAGNETIC_STORAGE:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, 0, 0, NumberOfTasks, 0, 0, 0, 0)));
                break;
            case ISA:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, 0, 0, 0, NumberOfTasks, 0, 0, 0)));
                break;
            case LPT:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, 0, 0, 0, 0, NumberOfTasks, 0, 0)));
                break;
            case COM:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, 0, 0, 0, 0, 0, NumberOfTasks, 0)));
                break;
            case GPU:
                this.tree.add(new Peak("M0", new Condition(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NumberOfTasks)));
                break;
            default:
                throw new IllegalArgumentException("no such device");
        }
    }

    public Peak getStartVertex() {
        return tree.get(0);
    }

    public int getSize() {
        return tree.size();
    }

    public void build(Node startNode, ConnectionList connectionList) {
        this.setStartNode(startNode);
        List<AlternativeConection> alternativeConnectionsList = changeConectionList(connectionList);
        AlternativeConection buf;
        Condition bufCondition;
        Peak existVertex;
        int t = 1;

        for (int k = 0; k < tree.size(); k++) {
            bufCondition = conditionCopy(tree.get(k).getCondition());
            for (int i = 0; i < Node.values().length; i++) {

                for (int j = 0; j < Node.values().length; j++) {

                    buf = searchConnectionInList(alternativeConnectionsList, i, j);
                    if (buf != null) {

                        if (bufCondition.toArray()[i] > 0) {

                            bufCondition.toArray()[i]--;
                            bufCondition.toArray()[j]++;
                            existVertex = existSuchVertex(bufCondition);

                            if (existVertex == null) {

                                tree.add(new Peak("M" + t, conditionCopy(bufCondition)));
                                tree.get(tree.size() - 1).setPreviousNodes(tree.get(k));
                                tree.get(k).setNextNodes(new VertexLink(tree.get(tree.size() - 1), buf.getL() * buf.getProbability()));
                                t++;
                            } else {

                                tree.get(k).setNextNodes(new VertexLink(existVertex, buf.getProbability() * buf.getL()));
                                existVertex.setPreviousNodes(tree.get(k));
//                                System.out.println(existVertex.toString());
                            }

                            bufCondition.toArray()[i]++;
                            bufCondition.toArray()[j]--;
                        }
                    }
                }
            }
        }
//        System.out.println(alternativeConnectionsList.toString());

    }

    public Peak getVertex(String name) {
        for (Peak peak : tree) {
            if (peak.getName().equals(name)) return peak;
        }
        return null;
    }

    private Peak existSuchVertex(Condition condition) {
        for (Peak v : tree) {
            if (v.equelsByCondition(condition)) {
                return v;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "Tree{" +
                "tree=" + tree +
                '}';
    }
}
