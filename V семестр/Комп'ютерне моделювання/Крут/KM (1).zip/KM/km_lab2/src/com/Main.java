package com;

/**
 * Created by User on 30.09.2016.
 */
public class Main {

    public static void main(String[] args) {
        Computer computer = new Computer(2, 3);
        computer.start();
        computer.printStatistics();
    }
}
