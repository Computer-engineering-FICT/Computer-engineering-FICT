package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by User on 30.09.2016.
 */
public class ComputerPart implements Computable {

    private ArrayList<Task> queue;
    private double timeOfProcessing;
    private boolean isOpen;
    private Task currentTask;
    private Map<Computable, Double> outPut;

    private String title;

    private double timeInWork;

    public ComputerPart(double timeOfProcessing, String title) {
        queue = new ArrayList<Task>();
        this.timeOfProcessing = timeOfProcessing;
        isOpen = true;
        outPut = new HashMap<Computable, Double>();
        this.title = title;
    }

    @Override
    public Computable findNextTarget() { //���� ������� �����
        Computable result = null;

        ArrayList<Map.Entry<Computable,Double>> pairs = new ArrayList<>();
        for (Map.Entry<Computable, Double> pair : outPut.entrySet()) {
            pairs.add(pair);
        }

        double rand = Math.random();
        double chance = 0;
        for (int i = 0; i < pairs.size(); i++) {
            chance += pairs.get(i).getValue();
            if (chance > rand) {
                result = pairs.get(i).getKey();
                break;
            }
        }

        if (result == null) {
            result = pairs.get(pairs.size() - 1).getKey();
        }
        return result;
    }

    public void addTaskInQueue(Task task) {
        queue.add(task);
        if (currentTask == null) {
            nextTaskFromQueue();
        }
    }


    @Override
    public void nextTaskFromQueue(){
        if (currentTask == null && queue.size() > 0){
            currentTask = queue.get(0);
            currentTask.setTimeStarted(Computer.currentTime);
            queue.remove(0);
            increaseTimeInWork();
        } else {
            currentTask = null;
        }
    }

    public void increaseTimeInWork() {
        timeInWork += timeOfProcessing;
    }
    public double getTimeInWork() {
        return timeInWork;
    }

    @Override
    public Task getNextFinishingTask() {
        return getCurrentTask();
    }

    public Map<Computable, Double> getOutPut() {
        return outPut;
    }
    public Task getCurrentTask() {
        return currentTask;
    }
    public void setCurrentTask(Task currentTask) {
        this.currentTask = currentTask;
    }
    public double getTimeOfProcessing() {
        return timeOfProcessing;
    }
    public String getTitle() {
        return title;
    }
}
