package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by User on 30.09.2016.
 */
public class CPU implements Computable{

    private ArrayList<Task> queue;
    private double timeOfProcessing;
    private boolean isOpen;
    private Task[] tasks;
    private Map<Computable, Double> outPut;

    private double timeInWork;

    public CPU(double timeOfProcessing, int cores, int countOfTasks) {
        this.timeOfProcessing = timeOfProcessing;
        tasks = new Task[cores];
        queue = new ArrayList<Task>();
        outPut = new HashMap<Computable, Double>();

        if (cores < countOfTasks) {
            for (int i = 0; i < cores; i++) {
                tasks[i] = new Task();
            }
            for (int i = 0; i < countOfTasks - cores; i++) {
                queue.add(new Task());
            }
        } else {
            for (int i = 0; i < countOfTasks; i++) {
               tasks[i] = new Task();
            }
        }
    }

    public int indexOfTask(Task task) {
        int result = -1;
        for (int i = 0; i < tasks.length; i++) {
            if (tasks[i] != null && tasks[i].equals(task)) {
                result = i;
                break;
            }
        }
        return result;
    }

    @Override
    public Computable findNextTarget() {
        Computable result = null;
        if (outPut.size() == 1) {
            for (Map.Entry<Computable, Double> entry : outPut.entrySet()) {
                result = entry.getKey();
            }
        } else {
            double rand = Math.random();
            double chance = 0;
            for (Map.Entry<Computable, Double> pair : outPut.entrySet()) {
                if (chance > rand) {
                    result = pair.getKey();
                    break;
                } else {
                    chance += pair.getValue();
                }
            }
            if (result == null) {
                for (Map.Entry<Computable, Double> entry : outPut.entrySet()) {
                    result = entry.getKey();
                }
            }
        }
        return result;
    }

    @Override
    public void nextTaskFromQueue() {
        for (int i = 0; i < tasks.length; i++) {
            if (queue.size() == 0) {
                break;
            }
            if (tasks[i] == null) {
                tasks[i] = queue.get(0);
                queue.remove(0);
                tasks[i].setTimeStarted(Computer.currentTime);
                increaseTimeInWork();
            }
        }
    }

    @Override
    public Task getNextFinishingTask() {
        Task result = null;

        for (int i = 0; i < tasks.length; i++) {
            if (tasks[i] != null) {
                result = tasks[i];
                break;
            }
        }
        if (result != null) {
            for (int i = 0; i < tasks.length; i++) {
                if (tasks[i] != null && tasks[i].getTimeStarted() < result.getTimeStarted()) {
                    result = tasks[i];
                }
            }

        }
        return result;
    }

    @Override
    public double getTimeOfProcessing() {
        return timeOfProcessing;
    }

    public void addTaskInQueue(Task task) {
        queue.add(task);
        for (int i = 0; i < tasks.length; i++) {
            if (queue.size() == 0) {
                break;
            }
            if (tasks[i] == null) {
                nextTaskFromQueue();
            }
        }
    }

    public void increaseTimeInWork() {
        Task task = getNextFinishingTask();
        timeInWork += task.getTimeStarted() + timeOfProcessing - Computer.currentTime;
    }
    public double getTimeInWork() {
        return timeInWork;
    }
    public Task[] getTasks() {
        return tasks;
    }
    public Map<Computable, Double> getOutPut() {
        return outPut;
    }

    @Override
    public String getTitle() {
        return "CPU";
    }
}
