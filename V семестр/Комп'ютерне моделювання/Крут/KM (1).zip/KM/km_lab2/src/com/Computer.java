package com;

/**
 * Created by User on 30.09.2016.
 */
public class Computer {

    private static final double finishTime = 10000;

    public static double currentTime;
    private static double timeToNextTask;
    private static Computable nextComputerPart;


        private CPU CPU;

        private ComputerPart RAM;
        private ComputerPart northBridge;
        private ComputerPart southBridge;
        private ComputerPart router;
        private ComputerPart opticDiskStorage;
        private ComputerPart magneticDiskStorage;

        private ComputerPart GPU;
        private ComputerPart ISA;
        private ComputerPart LPT;
        private ComputerPart COM;


    public Computer(int cores, int countOfTask) {
        CPU = new CPU(5, cores,countOfTask);

        RAM = new ComputerPart(7, "RAM");
        northBridge = new ComputerPart(10, "northBridge");
        southBridge = new ComputerPart(12, "southBridge");
        router = new ComputerPart(20, "router");
        opticDiskStorage = new ComputerPart(22, "opticDisk");
        magneticDiskStorage = new ComputerPart(25, "magneticDisk");

        GPU = new ComputerPart(1000, "GPU");
        ISA = new ComputerPart(32, "ISA");
        LPT = new ComputerPart(27, "LPT");
        COM = new ComputerPart(35, "COM");

        createRelations();

    }

    private void createRelations() {
        // CPU
        CPU.getOutPut().put(northBridge, 1.0);

        // North Bridge
        northBridge.getOutPut().put(CPU, 0.0);
        northBridge.getOutPut().put(RAM, 0.0);
        northBridge.getOutPut().put(GPU, 1.0);
        northBridge.getOutPut().put(southBridge, 0.0);

        // South Bridge
        southBridge.getOutPut().put(router, 0.15);
        southBridge.getOutPut().put(opticDiskStorage, 0.1);
        southBridge.getOutPut().put(magneticDiskStorage, 0.1);
        southBridge.getOutPut().put(ISA, 0.15);
        southBridge.getOutPut().put(northBridge, 0.5);

        // RAM
        RAM.getOutPut().put(northBridge, 0.7);
        RAM.getOutPut().put(RAM, 0.3);

        // Optic drive
        opticDiskStorage.getOutPut().put(southBridge, 1.0);

        // Magnetic drive
        magneticDiskStorage.getOutPut().put(southBridge, 1.0);

        // Router
        router.getOutPut().put(southBridge, 1.0);

        // GPU
        GPU.getOutPut().put(northBridge, 1.0);

        // LPT
        LPT.getOutPut().put(CPU, 1.0);

        // ISA
        ISA.getOutPut().put(LPT, 0.6);
        ISA.getOutPut().put(COM, 0.4);

        // COM
        COM.getOutPut().put(ISA, 1.0);
    }

    public void start() {

        while(currentTime <= finishTime) {
            findNext();
            currentTime += timeToNextTask;
            computeNextTask(nextComputerPart);
        }

    }

    private void findNext() { //find next part and calculate time to next task
        timeToNextTask = Integer.MAX_VALUE;
        double temp;


        temp = timeToFinishTask(CPU);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = CPU;
        }
        temp = timeToFinishTask(RAM);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = RAM;
        }
        temp = timeToFinishTask(northBridge);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = northBridge;
        }

        temp = timeToFinishTask(southBridge);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = southBridge;
        }
        temp = timeToFinishTask(router);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = router;
        }
        temp = timeToFinishTask(opticDiskStorage);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = opticDiskStorage;
        }
        temp = timeToFinishTask(magneticDiskStorage);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = magneticDiskStorage;
        }
        temp = timeToFinishTask(GPU);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = GPU;
        }
        temp = timeToFinishTask(ISA);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = ISA;
        }
        temp = timeToFinishTask(LPT);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = LPT;
        }
        temp = timeToFinishTask(COM);
        if (temp >= 0 && temp < timeToNextTask) {
            timeToNextTask = temp;
            nextComputerPart = COM;
        }

    }
    private double timeToFinishTask(Computable part) { //return -1 if nor task;
        double result = -1;
        Task task = part.getNextFinishingTask();
        if (task != null) {
            result = task.getTimeStarted() + part.getTimeOfProcessing() - currentTime;
        }
        return result;
    }

    private void computeNextTask(Computable part) {
        Task task = part.getNextFinishingTask();
        task.setTimeFinished(currentTime);

        if (part.equals(CPU)) {
            int index = CPU.indexOfTask(task);
            CPU.getTasks()[index] = null;
        }
        else {
            ComputerPart computerPart = (ComputerPart)part;
            computerPart.setCurrentTask(null);
        }
        part.nextTaskFromQueue();

        Computable nextTarget = part.findNextTarget();
        nextTarget.addTaskInQueue(task);
    }

    public void printStatistics() {
        System.out.println("Time passed : " + currentTime);
        System.out.println("CPU worked : " + CPU.getTimeInWork() + " = " + timeToPercent(CPU) + "%");
        System.out.println("RAM worked : " + RAM.getTimeInWork() + " = " + timeToPercent(RAM) + "%");
        System.out.println("northBridge worked : " + northBridge.getTimeInWork() + " = " + timeToPercent(northBridge) + "%");
        System.out.println("southBridge worked : " + southBridge.getTimeInWork() + " = " + timeToPercent(southBridge) + "%");
        System.out.println("router worked : " + router.getTimeInWork() + " = " + timeToPercent(router) + "%");
        System.out.println("opticDiskStorage worked : " + opticDiskStorage.getTimeInWork() + " = " + timeToPercent(opticDiskStorage) + "%");
        System.out.println("magneticDiskStorage worked : " + magneticDiskStorage.getTimeInWork() + " = " + timeToPercent(magneticDiskStorage) + "%");
        System.out.println("GPU worked : " + GPU.getTimeInWork() + " = " + timeToPercent(GPU) + "%");
        System.out.println("ISA worked : " + ISA.getTimeInWork() + " = " + timeToPercent(ISA) + "%");
        System.out.println("LPT worked : " + LPT.getTimeInWork() + " = " + timeToPercent(LPT) + "%");
        System.out.println("COM worked : " + COM.getTimeInWork() + " = " + timeToPercent(COM) + "%");
    }

    private double timeToPercent(Computable part) {
        double result = part.getTimeInWork()/currentTime*10000;
        int res = (int)result;
        return (double)res/100;
    }
}
