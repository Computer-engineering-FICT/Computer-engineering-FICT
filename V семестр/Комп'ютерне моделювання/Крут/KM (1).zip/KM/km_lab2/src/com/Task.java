package com;

/**
 * Created by User on 30.09.2016.
 */
public class Task {

    private static int count = 0;

    private int id;
    private double timeStarted;
    private double timeFinished;

    public Task() {
        count++;
        this.id = count;
    }

    public double getTimeStarted() {
        return timeStarted;
    }

    public void setTimeStarted(double timeStarted) {
        this.timeStarted = timeStarted;
    }

    public void setTimeFinished(double timeFinished) {
        this.timeFinished = timeFinished;
    }
}
