package com;

/**
 * Created by User on 06.10.2016.
 */
public interface Computable {

    Computable findNextTarget();

    Task getNextFinishingTask();

    void nextTaskFromQueue();

    double getTimeOfProcessing();

    void addTaskInQueue(Task task); //and move to core

    void increaseTimeInWork();
    double getTimeInWork();

    String getTitle();
}
