/*
 * PetriNetView.java
 */
package petrinet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.filechooser.FileFilter;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import ptr.petri.view.PanelPetri;

/**
 * The application's main frame.
 */
public class PetriNetView extends FrameView {

    /**
     * Правая нижняя точка панели на которой будет строится сеть Петри
     */
    public static final Point2D.Double maxP = new Point2D.Double(8000, 8000);

    public PetriNetView(SingleFrameApplication app) {
        super(app);

        initComponents();


        Point2D.Double _maxP = new Point2D.Double(maxP.getX(), maxP.getY());
        panPetri = new PanelPetri(1.5f, _maxP, statusLbl, vertexLst, markerTxt, labelTxt, okBtn);

        panPetri.setName("panPetri");
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(panPetri);
        panPetri.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 734, Short.MAX_VALUE));
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 416, Short.MAX_VALUE));

        panPetri.setBackground(Color.WHITE);
        panPetri.setAutoscrolls(true);
        panPetri.setPreferredSize(new Dimension((int) maxP.getX(), (int) maxP.getY()));
        panPetri.setSize(new Dimension((int) maxP.getX(), (int) maxP.getY()));
        panPetri.setDoubleBuffered(true);
        scrlPanPetri.setViewportView(panPetri);

        this.getFrame().setTitle("Графический редактор сетей Петри. "+openFile);

        this.getFrame().addComponentListener(new java.awt.event.ComponentAdapter() {

            @Override
            public void componentShown(java.awt.event.ComponentEvent evt) {
                panPetriToPoint(maxP, true);
            }
        });


        //Добавляем действие при нажатии на ENTER на кнопку ОК
        AbstractAction okAct = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                panPetri.setFieldsV();
            }
        };
        InputMap iMap = markerPanel.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        ActionMap aMap = markerPanel.getActionMap();
        iMap.put(KeyStroke.getKeyStroke("ENTER"), "markerPanel");
        aMap.put("markerPanel", okAct);

        AbstractAction action = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                panPetri.deleteSelected();
            }
        };

        iMap = panPetri.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        aMap = panPetri.getActionMap();
        iMap.put(KeyStroke.getKeyStroke("ctrl D"), "delSelected");
        aMap.put("delSelected", action);

        AbstractAction copy = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                panPetri.copyVertex();
            }
        };

        iMap.put(KeyStroke.getKeyStroke("ctrl C"), "copyAction");
        aMap.put("copyAction", copy);

        AbstractAction paste = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                panPetri.pasteVertex();
            }
        };

        iMap.put(KeyStroke.getKeyStroke("ctrl V"), "pasteAction");
        aMap.put("pasteAction", paste);

        AbstractAction step = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                panPetri.step();
            }
        };

        iMap.put(KeyStroke.getKeyStroke("S"), "stepAction");
        aMap.put("stepAction", step);

        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                statusLbl.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {

            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String) (evt.getNewValue());
                    statusLbl.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer) (evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = PetriNetApp.getApplication().getMainFrame();
            aboutBox = new PetriNetAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        PetriNetApp.getApplication().show(aboutBox);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        toolBarPanel = new javax.swing.JPanel();
        petriTool = new javax.swing.JToolBar();
        btnPanel = new javax.swing.JPanel();
        arrow = new javax.swing.JButton();
        addPosition = new javax.swing.JButton();
        addTransition = new javax.swing.JButton();
        addEdgeLine = new javax.swing.JButton();
        propTool = new javax.swing.JToolBar();
        propPanel = new javax.swing.JPanel();
        scrlPropPanel = new javax.swing.JScrollPane();
        vertexLst = new javax.swing.JList();
        markerPanel = new javax.swing.JPanel();
        markerTxt = new javax.swing.JTextField();
        labelTxt = new javax.swing.JTextField();
        okBtn = new javax.swing.JButton();
        lblMarker = new javax.swing.JLabel();
        lblLabel = new javax.swing.JLabel();
        lblVertex = new javax.swing.JLabel();
        btnCmd = new javax.swing.JButton();
        tmpPetriPanel = new javax.swing.JPanel();
        scrlPanPetri = new javax.swing.JScrollPane();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        newMnIm = new javax.swing.JMenuItem();
        openMnIm = new javax.swing.JMenuItem();
        saveMnIm = new javax.swing.JMenuItem();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusLbl = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();

        mainPanel.setAutoscrolls(true);
        mainPanel.setMinimumSize(new java.awt.Dimension(150, 300));
        mainPanel.setName("mainPanel"); // NOI18N

        toolBarPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        toolBarPanel.setName("toolBarPanel"); // NOI18N
        toolBarPanel.setLayout(new java.awt.BorderLayout());

        petriTool.setFloatable(false);
        petriTool.setOrientation(1);
        petriTool.setRollover(true);
        petriTool.setAutoscrolls(true);
        petriTool.setMinimumSize(new java.awt.Dimension(150, 35));
        petriTool.setName("petriTool"); // NOI18N
        petriTool.setPreferredSize(new java.awt.Dimension(170, 38));

        btnPanel.setAutoscrolls(true);
        btnPanel.setMinimumSize(new java.awt.Dimension(144, 41));
        btnPanel.setName("btnPanel"); // NOI18N
        btnPanel.setPreferredSize(new java.awt.Dimension(170, 35));
        btnPanel.setLayout(new java.awt.GridLayout(1, 0));

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(petrinet.PetriNetApp.class).getContext().getResourceMap(PetriNetView.class);
        arrow.setIcon(resourceMap.getIcon("arrow.icon")); // NOI18N
        arrow.setText(resourceMap.getString("arrow.text")); // NOI18N
        arrow.setMinimumSize(new java.awt.Dimension(65, 39));
        arrow.setName("arrow"); // NOI18N
        arrow.setPreferredSize(new java.awt.Dimension(35, 35));
        arrow.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                arrowMouseClicked(evt);
            }
        });
        btnPanel.add(arrow);

        addPosition.setIcon(resourceMap.getIcon("addPosition.icon")); // NOI18N
        addPosition.setText(resourceMap.getString("addPosition.text")); // NOI18N
        addPosition.setToolTipText(resourceMap.getString("addPosition.toolTipText")); // NOI18N
        addPosition.setIconTextGap(5);
        addPosition.setName("addPosition"); // NOI18N
        addPosition.setPreferredSize(new java.awt.Dimension(35, 35));
        addPosition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPositionActionPerformed(evt);
            }
        });
        btnPanel.add(addPosition);

        addTransition.setIcon(resourceMap.getIcon("addTransition.icon")); // NOI18N
        addTransition.setToolTipText(resourceMap.getString("addTransition.toolTipText")); // NOI18N
        addTransition.setAlignmentY(0.0F);
        addTransition.setName("addTransition"); // NOI18N
        addTransition.setPreferredSize(new java.awt.Dimension(35, 35));
        addTransition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addTransitionActionPerformed(evt);
            }
        });
        btnPanel.add(addTransition);

        addEdgeLine.setIcon(resourceMap.getIcon("addEdgeLine.icon")); // NOI18N
        addEdgeLine.setText(resourceMap.getString("addEdgeLine.text")); // NOI18N
        addEdgeLine.setToolTipText(resourceMap.getString("addEdgeLine.toolTipText")); // NOI18N
        addEdgeLine.setName("addEdgeLine"); // NOI18N
        addEdgeLine.setPreferredSize(new java.awt.Dimension(35, 35));
        addEdgeLine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addEdgeLineActionPerformed(evt);
            }
        });
        btnPanel.add(addEdgeLine);

        petriTool.add(btnPanel);

        toolBarPanel.add(petriTool, java.awt.BorderLayout.PAGE_START);

        propTool.setFloatable(false);
        propTool.setOrientation(1);
        propTool.setRollover(true);
        propTool.setAutoscrolls(true);
        propTool.setMargin(new java.awt.Insets(0, 3, 0, 0));
        propTool.setName("propTool"); // NOI18N

        propPanel.setAutoscrolls(true);
        propPanel.setName("propPanel"); // NOI18N

        scrlPropPanel.setName("scrlPropPanel"); // NOI18N

        vertexLst.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        vertexLst.setName("vertexLst"); // NOI18N
        vertexLst.setValueIsAdjusting(true);
        vertexLst.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                vertexLstValueChanged(evt);
            }
        });
        scrlPropPanel.setViewportView(vertexLst);

        markerPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(resourceMap.getString("markerPanel.border.title"))); // NOI18N
        markerPanel.setName("markerPanel"); // NOI18N

        markerTxt.setEditable(false);
        markerTxt.setText(resourceMap.getString("markerTxt.text")); // NOI18N
        markerTxt.setName("markerTxt"); // NOI18N

        labelTxt.setEditable(false);
        labelTxt.setText(resourceMap.getString("labelTxt.text")); // NOI18N
        labelTxt.setName("labelTxt"); // NOI18N

        okBtn.setText(resourceMap.getString("okBtn.text")); // NOI18N
        okBtn.setEnabled(false);
        okBtn.setName("okBtn"); // NOI18N
        okBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okBtnActionPerformed(evt);
            }
        });

        lblMarker.setText(resourceMap.getString("lblMarker.text")); // NOI18N
        lblMarker.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        lblMarker.setName("lblMarker"); // NOI18N

        lblLabel.setText(resourceMap.getString("lblLabel.text")); // NOI18N
        lblLabel.setName("lblLabel"); // NOI18N

        javax.swing.GroupLayout markerPanelLayout = new javax.swing.GroupLayout(markerPanel);
        markerPanel.setLayout(markerPanelLayout);
        markerPanelLayout.setHorizontalGroup(
            markerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(markerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(markerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblMarker, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                    .addGroup(markerPanelLayout.createSequentialGroup()
                        .addComponent(lblLabel)
                        .addContainerGap(71, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, markerPanelLayout.createSequentialGroup()
                        .addGroup(markerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(markerTxt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                            .addComponent(labelTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, markerPanelLayout.createSequentialGroup()
                        .addComponent(okBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        markerPanelLayout.setVerticalGroup(
            markerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(markerPanelLayout.createSequentialGroup()
                .addComponent(lblMarker)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(markerTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(labelTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(okBtn))
        );

        lblVertex.setText(resourceMap.getString("lblVertex.text")); // NOI18N
        lblVertex.setName("lblVertex"); // NOI18N

        btnCmd.setText(resourceMap.getString("btnCmd.text")); // NOI18N
        btnCmd.setName("btnCmd"); // NOI18N
        btnCmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCmdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout propPanelLayout = new javax.swing.GroupLayout(propPanel);
        propPanel.setLayout(propPanelLayout);
        propPanelLayout.setHorizontalGroup(
            propPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(markerPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnCmd, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(propPanelLayout.createSequentialGroup()
                .addComponent(lblVertex)
                .addContainerGap())
            .addComponent(scrlPropPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        propPanelLayout.setVerticalGroup(
            propPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(propPanelLayout.createSequentialGroup()
                .addComponent(markerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCmd)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblVertex)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrlPropPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE))
        );

        propTool.add(propPanel);

        toolBarPanel.add(propTool, java.awt.BorderLayout.CENTER);

        tmpPetriPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        tmpPetriPanel.setName("tmpPetriPanel"); // NOI18N

        scrlPanPetri.setName("scrlPanPetri"); // NOI18N

        javax.swing.GroupLayout tmpPetriPanelLayout = new javax.swing.GroupLayout(tmpPetriPanel);
        tmpPetriPanel.setLayout(tmpPetriPanelLayout);
        tmpPetriPanelLayout.setHorizontalGroup(
            tmpPetriPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrlPanPetri, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
        );
        tmpPetriPanelLayout.setVerticalGroup(
            tmpPetriPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrlPanPetri, javax.swing.GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(toolBarPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tmpPetriPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tmpPetriPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(toolBarPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        newMnIm.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        newMnIm.setText(resourceMap.getString("newMnIm.text")); // NOI18N
        newMnIm.setName("newMnIm"); // NOI18N
        newMnIm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newMnImActionPerformed(evt);
            }
        });
        fileMenu.add(newMnIm);

        openMnIm.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        openMnIm.setText(resourceMap.getString("openMnIm.text")); // NOI18N
        openMnIm.setName("openMnIm"); // NOI18N
        openMnIm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openMnImActionPerformed(evt);
            }
        });
        fileMenu.add(openMnIm);

        saveMnIm.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveMnIm.setText(resourceMap.getString("saveMnIm.text")); // NOI18N
        saveMnIm.setName("saveMnIm"); // NOI18N
        saveMnIm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMnImActionPerformed(evt);
            }
        });
        fileMenu.add(saveMnIm);

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(petrinet.PetriNetApp.class).getContext().getActionMap(PetriNetView.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setText(resourceMap.getString("exitMenuItem.text")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        jMenu1.setText(resourceMap.getString("jMenu1.text")); // NOI18N
        jMenu1.setName("jMenu1"); // NOI18N

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText(resourceMap.getString("jMenuItem1.text")); // NOI18N
        jMenuItem1.setName("jMenuItem1"); // NOI18N
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText(resourceMap.getString("jMenuItem2.text")); // NOI18N
        jMenuItem2.setName("jMenuItem2"); // NOI18N
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText(resourceMap.getString("jMenuItem3.text")); // NOI18N
        jMenuItem3.setName("jMenuItem3"); // NOI18N
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        menuBar.add(jMenu1);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setText(resourceMap.getString("aboutMenuItem.text")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusLbl.setName("statusLbl"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 840, Short.MAX_VALUE)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(statusLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 670, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusLbl)
                    .addComponent(statusAnimationLabel)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3))
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents

    private void addEdgeLineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addEdgeLineActionPerformed
        this.changeButton(PanelPetri.LINE);
    }//GEN-LAST:event_addEdgeLineActionPerformed

    private void arrowMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_arrowMouseClicked
        this.changeButton(PanelPetri.ARROW);
    }//GEN-LAST:event_arrowMouseClicked

    private void addPositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPositionActionPerformed
        this.changeButton(PanelPetri.POSITION);
    }//GEN-LAST:event_addPositionActionPerformed

    private void addTransitionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addTransitionActionPerformed
        this.changeButton(PanelPetri.TRANSITION);
    }//GEN-LAST:event_addTransitionActionPerformed

    private void openMnImActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openMnImActionPerformed
        JFileChooser ch = new JFileChooser(new File("netXml"));
        ch.setDialogTitle("Открыть файл");
        FileFilter filter = new FileFilter() {

            @Override
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".xml");
            }

            @Override
            public String getDescription() {
                return ".xml файлы";
            }
        };
        ch.setFileFilter(filter);
        int res = ch.showOpenDialog(null);

        if (res == JFileChooser.APPROVE_OPTION) {
            File f = ch.getSelectedFile();
            f = ch.getSelectedFile();
            if (f.canRead()) {
                openFile = f.getName();
                this.getFrame().setTitle("Графический редактор сетей Петри. "+openFile);
                panPetri.loadFromXml(f);
            } else {
                JOptionPane.showMessageDialog(mainPanel, "Файл защищен от чтения", "Невозможно прочитать файл", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_openMnImActionPerformed

    private void saveMnImActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMnImActionPerformed
        JFileChooser ch = new JFileChooser("netXml");
        ch.setDialogTitle("Сохранить файл");
        ch.setSelectedFile(new File(openFile));
        FileFilter filter = new FileFilter() {

            @Override
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".xml");
            }

            @Override
            public String getDescription() {
                return ".xml файлы";
            }
        };
        ch.setFileFilter(filter);
        int res = ch.showSaveDialog(ch);
        if (res == JFileChooser.APPROVE_OPTION) {
            File out = ch.getSelectedFile();
            panPetri.saveToXml(out);
            openFile = out.getName();
            this.getFrame().setTitle("Графический редактор сетей Петри. "+openFile);
        }
    }//GEN-LAST:event_saveMnImActionPerformed

    private void newMnImActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newMnImActionPerformed
        openFile = "newPetriNet.xml";
        this.getFrame().setTitle("Графический редактор сетей Петри. "+openFile);
        panPetri.newPetriNet();
        panPetri.repaint();
    }//GEN-LAST:event_newMnImActionPerformed

    private void okBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okBtnActionPerformed
        panPetri.setFieldsV();
    }//GEN-LAST:event_okBtnActionPerformed

    private void btnCmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCmdActionPerformed
        panPetri.step();
    }//GEN-LAST:event_btnCmdActionPerformed

    private void vertexLstValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_vertexLstValueChanged
        // TODO add your handling code here:
        if (!evt.getValueIsAdjusting()) {
            Point2D.Double pNew = panPetri.changeCurrent(vertexLst.getSelectedValue());
            if (pNew != null) {
                panPetriToPoint(pNew, false);
                scrlPanPetri.repaint();
            }
        }
        //
    }//GEN-LAST:event_vertexLstValueChanged

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
         panPetri.copyVertex();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        panPetri.pasteVertex();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        panPetri.deleteSelected();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addEdgeLine;
    private javax.swing.JButton addPosition;
    private javax.swing.JButton addTransition;
    private javax.swing.JButton arrow;
    private javax.swing.JButton btnCmd;
    private javax.swing.JPanel btnPanel;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JTextField labelTxt;
    private javax.swing.JLabel lblLabel;
    private javax.swing.JLabel lblMarker;
    private javax.swing.JLabel lblVertex;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel markerPanel;
    private javax.swing.JTextField markerTxt;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem newMnIm;
    private javax.swing.JButton okBtn;
    private javax.swing.JMenuItem openMnIm;
    private javax.swing.JToolBar petriTool;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JPanel propPanel;
    private javax.swing.JToolBar propTool;
    private javax.swing.JMenuItem saveMnIm;
    private javax.swing.JScrollPane scrlPanPetri;
    private javax.swing.JScrollPane scrlPropPanel;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusLbl;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JPanel tmpPetriPanel;
    private javax.swing.JPanel toolBarPanel;
    private javax.swing.JList vertexLst;
    // End of variables declaration//GEN-END:variables
    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;
    private JDialog aboutBox;
    private PanelPetri panPetri;
    private String openFile = "newPetriNet.xml";
    private org.jdesktop.application.ResourceMap resource = org.jdesktop.application.Application.getInstance(petrinet.PetriNetApp.class).getContext().getResourceMap(PetriNetView.class);

    /**
     * Переместить область просмотра в центр
     */
    private void panPetriToPoint(Point2D.Double p, boolean isCenter) {
        //по вертикали
        double amountV = scrlPanPetri.getSize().getHeight();
        double numScrV = p.y / amountV;
        //по горизонтали
        double amountH = scrlPanPetri.getSize().getWidth();
        double numScrH = p.x / amountH;
        Point _p = null;
        if (isCenter) {
            _p = new Point((int) (amountH * numScrH / 4 - 300), (int) (amountV * numScrV / 2 - amountV / 2));
        } else {
            _p = new Point((int) (amountH * numScrH - amountH / 4), (int) (amountV * numScrV - amountV / 4));
        }
        scrlPanPetri.getHorizontalScrollBar().setValue(_p.x);
        //по вертикали
        scrlPanPetri.getVerticalScrollBar().setValue(_p.y);
    }

    /**
     * Изменить видимость нажатой клавиши
     * @param newBtn номер кнопки нажатой пользователем
     */
    private void changeButton(int newBtn) {
        int btn = panPetri.getButtonId();
        switch (btn) {
            case PanelPetri.ARROW: {
                arrow.setIcon(resource.getIcon("arrow.icon"));
                break;
            }
            case PanelPetri.POSITION: {
                addPosition.setIcon(resource.getIcon("addPosition.icon"));
                break;
            }
            case PanelPetri.TRANSITION: {
                addTransition.setIcon(resource.getIcon("addTransition.icon"));
                break;
            }
            case PanelPetri.LINE: {
                addEdgeLine.setIcon(resource.getIcon("addEdgeLine.icon"));
                break;
            }
        }
        switch (newBtn) {
            case PanelPetri.ARROW: {
                arrow.setIcon(resource.getIcon("arrow.icon_press"));
                break;
            }
            case PanelPetri.POSITION: {
                addPosition.setIcon(resource.getIcon("addPosition.icon_press"));
                break;
            }
            case PanelPetri.TRANSITION: {
                addTransition.setIcon(resource.getIcon("addTransition.icon_press"));
                break;
            }
            case PanelPetri.LINE: {
                addEdgeLine.setIcon(resource.getIcon("addEdgeLine.icon_press"));
                break;
            }
        }
        panPetri.setButtonId(newBtn);
    }
}
