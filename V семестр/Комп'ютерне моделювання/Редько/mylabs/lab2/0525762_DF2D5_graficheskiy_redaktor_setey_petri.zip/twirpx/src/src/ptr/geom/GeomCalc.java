/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ptr.geom;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;

/**
 * Геометрические вычисления
 * @author st
 */
public class GeomCalc {

    /**
     * точность выбора точки при двойном нажатии
     */
    private static final double precisionClickDB = 1000;

    /**
     * Вычислить расстояние между двумя точками
     * @param p1
     * @param p2
     * @return
     */
    public static double distace2point(Point2D.Double p1, Point2D.Double p2) {
        return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
    }

    /**
     * Вычислить расстояние между двумя точками
     * @param p1
     * @param p2
     * @return
     */
    public static double distace2point(Point p1, Point p2) {
        return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
    }

    /**
     * Вычислить точку деления отрезка <em>(p1,p2)</em> отрезком dis1
     * @param p1 начальная точка первого отрезка
     * @param p2 конечная точка второго отрезка
     * @param dis1
     * @return
     */
    public static Point2D.Double divideP(Point.Double p1, Point.Double p2, double dis) {
        double lambda = (GeomCalc.distace2point(p1, p2) - dis) / dis;
        double X = (p1.x + lambda * p2.x) / (1 + lambda);
        double Y = (p1.y + lambda * p2.y) / (1 + lambda);
        return new Point2D.Double(X, Y);
    }

    public static Point2D.Double divideP(Point p1, Point p2, double dis) {
        double lambda = (GeomCalc.distace2point(p1, p2) - dis) / dis;
        double X = (p1.x + lambda * p2.x) / (1 + lambda);
        double Y = (p1.y + lambda * p2.y) / (1 + lambda);
        return new Point2D.Double(X, Y);
    }

    /**
     * Проверить лежит ли точка на отрезке
     * @param p проверяем точка
     * @param p1 начальная координата отрезка
     * @param p2 конечная координата отрезка
     * @return
     */
    public static boolean isPointLine(Point p, Point2D.Double p1, Point2D.Double p2) {
        double a = p2.y - p1.y;
        double b = p1.x - p2.x;
        double c = -a * p1.x - b * p1.y;
        double d1 = Math.sqrt(Math.pow((p1.x - p.x), 2) + Math.pow((p1.y - p.y), 2));
        double d2 = Math.sqrt(Math.pow((p2.x - p.x), 2) + Math.pow((p2.y - p.y), 2));
        double d3 = Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));
        double precision = Math.abs(a * p.x + b * p.y + c);
        return ((precision < precisionClickDB) && (Math.abs(d3 - d2 - d1) < 0.1));
    }
}
