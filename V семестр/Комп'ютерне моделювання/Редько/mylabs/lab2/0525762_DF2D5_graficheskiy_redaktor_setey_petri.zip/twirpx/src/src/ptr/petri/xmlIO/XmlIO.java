package ptr.petri.xmlIO;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;
import ru.ulstu.ptr.petrinetsch.*;

/**
 * Класс для работы загрузки и выгрузки сети Петри в xml файл
 * @author petr
 */
public class XmlIO {

    /**
     * Запись данных студентов xml
     * @param root - корневой элемент xml файла в виде java класса
     * @param fileName - файл в который записывать данные
     * @param dirNameXml - директория, в которую необходимо записывать данные
     */
    public void writeXML(PetriNet root, String fileName, String dirNameXml) {
        JAXBContext jaxb;
        try {
            jaxb = JAXBContext.newInstance(PetriNet.class.getPackage().getName());

            Marshaller marshaller = jaxb.createMarshaller();
            JAXBElement<PetriNet> rootXml = (new ObjectFactory()).createPetriNet(root);
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, "http://ptr.ulstu.ru/petriNetSch petriNet.xsd");
            Schema schema = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI).newSchema(new File(dirNameXml + File.separator + "petriNet.xsd"));
            marshaller.setSchema(schema);

            File dir = new File(dirNameXml);
            if (!dir.exists() || !dir.isDirectory() || !dir.canWrite()) {
                dir.mkdir();
            }
            marshaller.marshal(rootXml, new File(dir + File.separator + fileName));
        } catch (SAXException ex) {
            Logger.getLogger(XmlIO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JAXBException e) {
            Logger.getLogger(XmlIO.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    	/**
	 * Получение данных о студентах из xml- Файла
	 * @param fileName - название xml-файла
	 * @return
	 * @throws JAXBException
	 */
	public PetriNet readXML(String fileName, String dirNameXml) throws JAXBException {
		JAXBContext jaxb = JAXBContext.newInstance(PetriNet.class.getPackage().getName());
		Unmarshaller un = jaxb.createUnmarshaller();

		Schema schema = null;
		//Проверяем существует ли схема файла студентов
		File studSchemeFile = new File(dirNameXml+File.separator+"petriNet.xsd");
		if(!studSchemeFile.isFile() || !studSchemeFile.canRead()) {
			Logger.getLogger(XmlIO.class.getName()).log(Level.SEVERE,null,"Xsd схема petriNet.xsd "+studSchemeFile.getAbsolutePath()+
					" не существует или у Вас нет прав на его чтение");
			return null;
		}
		try {
			schema = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI).newSchema(studSchemeFile);
		} catch (SAXException e) {
			Logger.getLogger(XmlIO.class.getName()).log(Level.SEVERE,null,"Ошибка при разборе xsd схемы файла студентов: \n"+e.getMessage());
		}
		un.setSchema(schema);

		//Проверяем есть ли файл студентов
		File studFile = new File(dirNameXml+File.separator+fileName);
		if(!studFile.isFile() || !studFile.canRead()) {
			Logger.getLogger(XmlIO.class.getName()).log(Level.SEVERE,null,"Входной файл"+studFile.getAbsolutePath()+
					" не существует или у Вас нет прав на его чтение");
			return null;
		}
		JAXBElement<PetriNet> root = (JAXBElement<PetriNet>) un.unmarshal(studFile);
		return root.getValue();

	}
}
