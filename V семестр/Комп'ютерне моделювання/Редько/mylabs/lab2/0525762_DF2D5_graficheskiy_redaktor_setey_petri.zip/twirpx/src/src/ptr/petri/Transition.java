package ptr.petri;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 * Переход сети Петри
 * @author st
 */
public class Transition extends Vertex {

    public static final int _WIDTH = 8;
    public static final int _HEIGHT = 50;
    private double _width;
    private double _height;

    public Transition(Integer vertexId, int marker, String label, float scale) {
        super(vertexId, marker, label, scale);
        _width = 8 * scale;
        _height = 50 * scale + 4 * scale;
        this.setSize((int) _width, (int) _height);
    }

    public void addWidh() {
        _height += 25 * scale;
        this.setSize((int) _width, (int) _height);
    }

    /**
     * Определить разрешен ли переход.<br/>
     * Перход разрешен, когда кол-во маркеров = кол-ву входящих ребер
     * @return true - переход разрешен <br/> false - переход запрещен
     */
    public boolean isResolved() {
        int numOutEdge = 0;
        for (Integer num : outVertex.values()) {
            numOutEdge += num;
        }
        return marker == (edgeIdLst.size() - numOutEdge) && marker != 0;
    }

    @Override
    public void setScale(float scl) {
        this.scale = scl;
        _width = 8 * scale;
        _height = 50 * scale + 4 * scale;
        this.setSize((int) _width, (int) _height);
        this.lnTkns = 1.1f * scale;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLACK);
        Rectangle2D.Double rect = new Rectangle2D.Double(0, 0, _width, _height);
        g2.fill(rect);
    }
}
