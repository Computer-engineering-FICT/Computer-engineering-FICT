/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ptr.petri.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import javax.swing.JPanel;

/**
 * панель точки контакта
 * @author st
 */
public class PanelPointEdge extends JPanel {

    /*
     * Индекс точки ребка
     */
    private Integer index =null;
    /**
     * Первоначальная точка ребра до перетаскивания
     * Нужна для того, чтобы можно было вернуться к той же вершине
     * в которой и находилось ребро, если пользователь неправильно перенесет
     * точку.
     */
    private Point2D.Double begin= null;
    /**
     * Панель указывает на начальную вершину
     */
    private boolean inVertex = false;
    /**
     * Панель указывает на конечную вершину
     */
    private boolean outVertex = false;

    public PanelPointEdge(Integer index, Point2D.Double begin, float scale) {
        this.index = index;
        this.begin = begin;
        this.setSize(new Dimension((int)(10), (int)(10)));
        this.setBackground(Color.BLUE);
    }

    public Double getBegin() {
        return begin;
    }

    public void setBegin(Double begin) {
        this.begin = begin;
    }

    
    public Integer getIndex() {
        return index;
    }

    public boolean isInVertex() {
        return inVertex;
    }

    public void setInVertex(boolean inVertex) {
        this.inVertex = inVertex;
    }

    public boolean isOutVertex() {
        return outVertex;
    }

    public void setOutVertex(boolean outVertex) {
        this.outVertex = outVertex;
    }

    

}
