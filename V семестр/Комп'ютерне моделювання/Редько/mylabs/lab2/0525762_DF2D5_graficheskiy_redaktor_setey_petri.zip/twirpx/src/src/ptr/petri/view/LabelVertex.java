package ptr.petri.view;


/**
 * Элемент списка надписей вершин сети Петри
 * @author st
 */
public class LabelVertex{
    /**
     * масштаб надписи
     */
    private String name;
    private Integer vertexId;

    public LabelVertex(Integer vertexId,String text) {
        this.vertexId = vertexId;
        name = text;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getName() {
        return name;
    }

    public Integer getVertexId() {
        return vertexId;
    }

    
}
