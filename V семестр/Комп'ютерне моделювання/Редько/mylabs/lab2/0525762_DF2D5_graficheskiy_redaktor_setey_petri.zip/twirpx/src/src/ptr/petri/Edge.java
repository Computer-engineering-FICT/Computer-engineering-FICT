package ptr.petri;

import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.LinkedList;

/**
 * Ребро графа сети Петри
 * @author st
 */
public class Edge {

    /**
     * ребро в виде линии
     */
    public static final int LINE = 1;
    /**
     * Ребро в виде кривой второго порядка
     */
    public static final int CURVE = 1;
    /**
     * id ребра
     */
    private Integer edgeId;
    /**
     * id вершины начала ребка
     */
    private Integer inVertex;
    /**
     * id вершины в которую направлено ребро
     */
    private Integer outVertex;
    /**
     * Координаты ребра
     */
    private LinkedList<Point2D.Double> point;
    /**
     * Вид ребра.
     */
    private int type;

    public Edge(Integer edgeId, Integer inVertex, Integer outVertex, int type) {
        this.edgeId = edgeId;
        this.inVertex = inVertex;
        this.outVertex = outVertex;
        this.type = type;
        point = new LinkedList<Double>();
    }

    public Edge(Integer edgeId, Integer inVertex, Integer outVertex, int type, LinkedList<Double> point) {
        this.edgeId = edgeId;
        this.inVertex = inVertex;
        this.outVertex = outVertex;
        this.point = point;
        this.type = type;
    }

    public Integer getInVertex() {
        return inVertex;
    }

    public void setInVertex(Integer inVertex) {
        this.inVertex = inVertex;
    }

    public Integer getOutVertex() {
        return outVertex;
    }

    public void setOutVertex(Integer outVertex) {
        this.outVertex = outVertex;
    }

    public LinkedList<Double> getPoint() {
        return point;
    }

    public void setPoint(LinkedList<Double> point) {
        this.point = point;
    }

    public int getType() {
        return type;
    }

    public Integer getEdgeId() {
        return edgeId;
    }

    @Override
    public String toString() {
        return "Edge{" + "edgeId=" + edgeId + " inVertex=" + inVertex + " outVertex=" + outVertex + '}';
    }
}
