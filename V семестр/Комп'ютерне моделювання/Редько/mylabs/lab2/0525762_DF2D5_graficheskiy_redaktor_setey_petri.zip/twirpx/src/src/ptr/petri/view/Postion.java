/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ptr.petri.view;

/**
 *
 * @author st
 */
class Postion {

}
