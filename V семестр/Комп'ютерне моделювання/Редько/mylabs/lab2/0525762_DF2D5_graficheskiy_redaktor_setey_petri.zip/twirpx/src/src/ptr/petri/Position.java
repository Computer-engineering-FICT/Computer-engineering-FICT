package ptr.petri;

import java.awt.*;
import java.awt.geom.Ellipse2D;

/**
 * Позиция сети Петри
 * @author st
 */
public class Position extends Vertex {

    public static final int RADIUS = 25;
    public static final int MARKER_RADIUS = 5;
    /**
     * радиус окружности
     */
    private double radius;
    /**
     * радиус фишек
     */
    private double markRadius;
    /**
     * шрифт надписи фишек
     */
    private Font fnt;

    /**
     * в какой последовательности осуществляется переход из позиции
     * массив хранит id переходов
     */
    private int[] seq = null;
    
    /**
     * Создать новую позицию
     * @param vertexId - id позиции
     * @param marker кол-во маркеров
     * @param label название позиции
     */
    public Position(Integer vertexId, int marker, String label, float scale) {
        super(vertexId, marker, label, scale);
        radius = RADIUS * scale;
        markRadius = 5 * scale;
        int fntSize = (int) (0.20 * scale * 72);
        fnt = new Font(Font.SERIF, Font.PLAIN, fntSize);
        this.setSize(new Dimension((int) (radius*2), (int) (radius*2)));
    }

    @Override
    public void setScale(float scl) {
        this.scale = scl;
        radius = RADIUS * scale;
        markRadius = 5 * scale;
        int fntSize = (int) (0.20 * scale * 72);
        fnt = new Font(Font.SERIF, Font.PLAIN, fntSize);
        this.setSize(new Dimension((int) (radius*2), (int) (radius*2)));
        this.lnTkns = 1.1f * scale;
    }

    public int[] getSeq() {
        return seq;
    }

    public void setSeq(int[] seq) {
        this.seq = seq;
    }


    public double getRadius() {
        return radius;
    }

    public Font getFnt() {
        return fnt;
    }

    public void setFnt(Font fnt) {
        this.fnt = fnt;
    }

    public double getMarkRadius() {
        return markRadius;
    }

    public void setMarkRadius(double markRadius) {
        this.markRadius = markRadius;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLACK);
        Stroke strk = new BasicStroke(lnTkns, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
        g2.setStroke(strk);
        Ellipse2D.Double el = new Ellipse2D.Double(lnTkns, lnTkns, radius*2 - lnTkns * 2, radius*2 - lnTkns * 2);
        g2.draw(el);

        double mr2 = markRadius + lnTkns / 2;
        double markD = markRadius*2;
        double r2 = radius + lnTkns;
        double r2_mr2 = r2 - mr2;
        double offX = 0;
        double offY = 0;
        //отображаем маркеры
        switch (marker) {
            case 0: {
                break;
            }
            case 1: {
                el = new Ellipse2D.Double(r2_mr2, r2_mr2, markD, markD);
                g2.fill(el);
                break;
            }
            case 2: {
                offX = mr2 + 2 * scale;
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2, markD, markD);
                g2.fill(el);
                break;
            }
            case 3: {
                offX = lnTkns + mr2 + 2 * scale;
                offY = offX - scale;
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                break;
            }
            case 4: {
                offX = lnTkns + mr2 + 2 * scale;
                offY = offX;
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                break;
            }
            case 5: {

                offY = lnTkns + mr2 + 7.5 * scale;
                el = new Ellipse2D.Double(r2_mr2, r2_mr2 - offY, markD, markD);
                g2.fill(el);

                offY = lnTkns + 3.2 * scale;
                offX = lnTkns + mr2 + 6 * scale;
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);

                offY = lnTkns + mr2 + 3 * scale;
                offX = lnTkns + mr2 + 1.2 * scale;
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                break;
            }
            case 6: {
                offX = lnTkns + mr2 + 7 * scale;
                offY = lnTkns;
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);

                offY = lnTkns + mr2 + 7 * scale;
                offX = lnTkns + mr2 + 1 * scale;
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 - offY, markD, markD);
                g2.fill(el);

                offY = lnTkns + mr2 + 5 * scale;
                el = new Ellipse2D.Double(r2_mr2 + offX, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2 + offY, markD, markD);
                g2.fill(el);
                break;
            }
            default: {
                if (marker < 1000) {
                    if (marker < 10) {
                        offX = lnTkns + 3 * scale;
                    } else if (marker > 9 && marker < 100) {
                        offX = lnTkns + 6 * scale;
                    } else if (marker > 99 && marker < 1000) {
                        offX = lnTkns + 11 * scale;
                    }
                    el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2, markD, markD);
                    g2.fill(el);
                    g2.setFont(fnt);
                    g2.drawString(String.valueOf(marker), (float) (r2_mr2 - offX + markD + 2 * scale), (float) (r2 + markD / 4));
                } else {
                    offX = lnTkns + 11 * scale;
                    el = new Ellipse2D.Double(r2_mr2 - offX, r2_mr2, markD, markD);
                    g2.fill(el);
                    g2.setFont(fnt);
                    g2.drawString("???", (float) (r2_mr2 - offX + markD + 2 * scale), (float) (r2 + markD / 4));
                }
            }
        }
    }
}
