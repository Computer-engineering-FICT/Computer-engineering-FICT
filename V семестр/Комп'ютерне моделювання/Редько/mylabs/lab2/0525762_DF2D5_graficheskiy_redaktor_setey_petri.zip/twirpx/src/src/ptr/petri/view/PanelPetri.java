package ptr.petri.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.io.File;
import java.util.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import javax.xml.bind.JAXBException;
import ptr.geom.GeomCalc;
import ptr.petri.Edge;
import ptr.petri.Position;
import ptr.petri.Transition;
import ptr.petri.Vertex;
import ptr.petri.xmlIO.XmlIO;
import ru.ulstu.ptr.petrinetsch.EdgeJoin;
import ru.ulstu.ptr.petrinetsch.EdgeLst;
import ru.ulstu.ptr.petrinetsch.PetriNet;
import ru.ulstu.ptr.petrinetsch.VertexLst;

/**
 * Панель на которой отображаются все элементы сети Петри
 * @author st
 */
public class PanelPetri extends JPanel {

    /**
     * Кнопка указатель мыши
     */
    public static final int ARROW = 1;
    /**
     * Кнопка добавить позицию
     */
    public static final int POSITION = 2;
    /**
     * Кнопка добавить переход
     */
    public static final int TRANSITION = 3;
    /**
     * Кнопка добавить ребро в виде линии
     */
    public static final int LINE = 4;
    /**
     * Максимальная точка панели 
     */
    private Point2D.Double maxP;
    /**
     * масштаб схемы
     * лучше всего 1
     */
    private float scale = 1.0f;
    /**
     * Вершины графа
     */
    private SortedMap<Integer, Vertex> vertexMap;
    /**
     * Ребра графа
     */
    private HashMap<Integer, Edge> edgeMap;
    /**
     * Надписи вершин
     */
    private HashMap<Integer, JLabel> labelMap;
    /**
     * id выбранного ребра
     */
    private Integer selEdgeId = null;
    /**
     * Массив панель для выделения точек контакта
     */
    private ArrayList<PanelPointEdge> panEdgeLst;
    /**
     * Id следующей вершины
     */
    private int nextVertexId = 1;
    /**
     * индекс следующей позиции
     */
    private int nextPositionInd = 1;
    /**
     * индекс следующего перехода
     */
    private int nextTransitionInd = 1;
    /**
     * Id следующего ребра
     */
    private int nextEdgeId = 1;
    /**
     * Id нажатой кнопки на панели инструментов
     */
    private int buttonId = 1;
    /**
     * текущий выбранный элемент
     */
    private JComponent current = null;
    /**
     * толщина линий
     */
    private float lnTkns;
    /**
     * Последовательность точек панели на которые нажимал пользователь
     */
    private LinkedList<Point> curPLst = new LinkedList<Point>();
    /**
     * Статусная надпись
     */
    private JLabel statusLbl;
    /**
     * Список для отображения вершин
     */
    private JList vertexList;
    /**
     * Шрифт надписей
     */
    private Font petriFnt;
    /**
     * Текстовое поля для ввода кол-ва маркеров
     */
    private JTextField txtMark;
    /**
     * Текстовое поля для ввода надписи вершины
     */
    private JTextField txtLabel;
    /**
     * Кнопка подтверждения изменения полей
     */
    private JButton btn;
    /**
     * Последовательность из двух точек.
     * Первая откуда, вторая куда пользователь перетещил элемент
     */
    private LinkedList<Point> moveP = new LinkedList<Point>();
    /**
     * точки, которые отмечает пользоваль, чтобы провести ребро
     */
    private Point _p1;
    private Point _p2;
    /**
     * Точки прямоугольника, который выбрал пользователь
     */
    private Point rectUser1;
    private Point rectUser2;

    /*
     * Массив id вершин, которые отметил пользователь
     */
    private ArrayList<Integer> selVertexLst;

    /*
     * Массив id вершин, которые скопировал пользователь
     */
    private ArrayList<Integer> copyVertexLst;

    /**
     *
     * @param scale
     * @param maxP
     * @param status
     * @param vLst
     * @param txtMark
     * @param txtLabel
     */
    public PanelPetri(float scale, Point2D.Double maxP, JLabel status, JList vLst, JTextField txtMark, JTextField txtLabel, JButton btn) {
        this.scale = scale;
        this.maxP = maxP;
        vertexMap = new TreeMap<Integer, Vertex>();
        edgeMap = new HashMap<Integer, Edge>();
        labelMap = new HashMap<Integer, JLabel>();
        statusLbl = status;
        this.vertexList = vLst;
        DefaultListModel mod = new DefaultListModel();
        vLst.setModel(mod);
        this.addMouseListener(new MouseHandler());
        this.addMouseMotionListener(new MouseMoutionHandler());
        lnTkns = 1.1f * scale;
        int fntSize = (int) (0.28 * scale * 72);
        petriFnt = new Font(Font.SERIF, Font.PLAIN, fntSize);
        this.txtMark = txtMark;
        this.txtLabel = txtLabel;
        this.btn = btn;
        this.panEdgeLst = new ArrayList<PanelPointEdge>();
        selVertexLst = new ArrayList<Integer>();
        copyVertexLst = new ArrayList<Integer>();
    }

    public int getButtonId() {
        return buttonId;
    }

    public void setButtonId(int buttonId) {
        if (buttonId == PanelPetri.ARROW && current != null && current instanceof Vertex) {
            this.enableVertexField((Vertex) current);
            Point pos = current.getLocation();
            Point p = new Point((int) (pos.x + current.getSize().width / 2), pos.y);
            curPLst.add(p);
        } else {
            this.disableVertexField();
        }
        if (buttonId != PanelPetri.ARROW && current != null) {
            current.setBorder(BorderFactory.createEmptyBorder());
            current = null;
            curPLst.clear();
        }
        statusLbl.setText("");
        this.buttonId = buttonId;
    }

    public float getScale() {
        return scale;
    }

    /**
     * Создать новую сеть Петри
     */
    public void newPetriNet() {
        this.removeAll();
        vertexMap.clear();
        edgeMap.clear();
        labelMap.clear();
        nextEdgeId = 1;
        nextPositionInd = 1;
        nextTransitionInd = 1;
        nextVertexId = 1;
        statusLbl.setText("");
        current = null;
        curPLst.clear();
        selEdgeId = null;
        _p1 = null;
        _p2 = null;
        rectUser1 = null;
        rectUser2 = null;
        panEdgeLst.clear();
        moveP.clear();
        selVertexLst.clear();
        copyVertexLst.clear();
        panEdgeLst.clear();
        DefaultListModel model = (DefaultListModel) vertexList.getModel();
        model.clear();
    }

    /**
     * Установить кол-во фишек и надпись для выбранной позиции или
     * установить надпись для выбранного перехода
     */
    public void setFieldsV() {
        if (current == null || !(current instanceof Vertex)) {
            return;
        } else {
            Vertex v = (Vertex) current;
            if (!v.getLabel().equals(txtLabel.getText())) {
                v.setLabel(txtLabel.getText());
                changeVertexLabel(txtLabel.getText(), v);
            }
            if (current instanceof Position) {
                try {
                    Integer count = Integer.parseInt(txtMark.getText());
                    if (count < 0) {
                        JOptionPane.showMessageDialog(null, "Значение поля кол-во фишек должно быть больше, либо равно 0", "Ошибка", JOptionPane.ERROR_MESSAGE);
                    } else {
                        v.setMarker(count);
                        current.repaint();
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Значение поля кол-во фишек не является целым числом", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    /**
     * Удалить выбранный элемент
     */
    public void deleteSelected() {
        if (current != null && !(current instanceof PanelPetri)) {
            //выбран какой-то элемент сети петри
            if (current instanceof PanelPointEdge) {
                //выбрана точка ребра
                PanelPointEdge panEdge = (PanelPointEdge) current;
                Edge edge = edgeMap.get(selEdgeId);
                if (panEdge.getIndex() != 0 && panEdge.getIndex() != edge.getPoint().size() - 1) {
                    //выбранная точка находится между началом и концом ребра
                    edge.getPoint().remove(edge.getPoint().get(panEdge.getIndex()));
                    selectedEdgeP(edge);
                    current = null;
                }
            } else if (current instanceof Vertex) {
                //удаляем вершину вместе с прилегающими ребрами
                Vertex v = (Vertex) current;
                deleteVertex(v);
                repaint();
            }
        } else if (selEdgeId != null) {
            //выбрано ребро
            //удаляем ребро
            deleteEdge(selEdgeId);
            repaint();
        } else if (!selVertexLst.isEmpty()) {
            //выделена область
            for (Integer vertexId : selVertexLst) {
                deleteVertex(vertexMap.get(vertexId));
            }
            rectUser1 = null;
            rectUser2 = null;
            repaint();
        }
    }

    /**
     * Осуществить переход 
     */
    public void step() {
        //определяем разрешенные переходы
        for (Vertex v : vertexMap.values()) {
            if (v instanceof Position) {
                //вычисляем в какие вершины разрешен переход
                ArrayList<Integer> outVertex = new ArrayList<Integer>();
                int numMarker = v.getMarker();
                //общее количество выходящих ребер из вершины
                for (Map.Entry<Integer, Integer> tr : v.getOutVertex().entrySet()) {
                    Integer count = tr.getValue();
                    if (count <= numMarker) {
                        outVertex.add(tr.getKey());
                    }
                }
                int sizeOut = outVertex.size();
                if (sizeOut > 0) {
                    //хотя бы в одну вершину разрешен переход
                    int seq[] = randomSeqVertex(outVertex);
                    Position pos = (Position) v;
                    pos.setSeq(seq);
                    for (int i = 0; i < seq.length; i++) {
                        Integer count = v.getOutVertex().get(seq[i]);
                        //находим сколько маркеров осталось к этому времени в позиции
                        int prevMarker = 0;
                        for (int j = 0; j < i; j++) {
                            prevMarker += v.getOutVertex().get(seq[j]);
                        }
                        int marker = v.getMarker() - prevMarker;

                        if (count <= marker) {
                            //ребер меньше чем маркеров, тогда переходим
                            vertexMap.get(seq[i]).addMarker(count);
                        }
                    }
                }

            }
        }
        //проходим по всем позициям и если разрешен переход, то переходим
        for (Vertex v : vertexMap.values()) {
            if (v instanceof Position) {
                Position pos = (Position) v;
                int[] seq = pos.getSeq();
                if (seq != null) {
                    for (int i = 0; i < seq.length; i++) {
                        int marker = pos.getMarker();
                        int countEdge = pos.getOutVertex().get(seq[i]);
                        Transition outV = (Transition) vertexMap.get(seq[i]);
                        if (outV.isResolved() && (marker >= countEdge)) {
                            pos.subMarker(countEdge);
                        }
                    }
                    pos.setSeq(null);
                }
            }

        }


        //теперь проходим по всем перходам и если переход разрешен перходим
        for (Vertex v : vertexMap.values()) {
            if (v instanceof Transition) {
                Transition transition = (Transition) v;
                if (transition.isResolved()) {
                    //переход разрешен передаем маркеры
                    for (Map.Entry<Integer, Integer> tr : v.getOutVertex().entrySet()) {
                        Integer outVId = tr.getKey();
                        int num = tr.getValue();
                        vertexMap.get(outVId).addMarker(num);
                    }
                }
                //в любом случае кол-во маркеров в преходе устанавливаем в 0
                v.setMarker(0);
            }
        }
        repaint();

    }

    /**
     * Занести id выделенных вершин в буфер для последующей вставки
     */
    public void copyVertex() {
        copyVertexLst.clear();
        if (isUserArea()) {
            for (Vertex v : vertexMap.values()) {
                if (vertexIsUserArea(v)) {
                    copyVertexLst.add(v.getVertexId());
                }
            }
        }
    }

    /**
     * Вставить выделенные вершины
     */
    public void pasteVertex() {
        //if (isUserArea()) {
        Point p1 = rectUser1;
        Point p2 = rectUser2;
        int height = p2.y - p1.y;

        //если пользователь выбрал область для копирования
        for (Integer vertexId : selVertexLst) {

            Vertex _v = vertexMap.get(vertexId);
            Vertex v = null;
            if (_v instanceof Position) {
                v = new Position(nextVertexId, _v.getMarker(), "p" + nextPositionInd, scale);
                nextPositionInd++;
            } else {
                v = new Transition(nextVertexId, _v.getMarker(), "t" + nextTransitionInd, scale);
                nextTransitionInd++;
            }
            _v.setCopyVertexId(nextVertexId);

            //устанавливаем позицию вершины
            Point pos = _v.getLocation();
            int maxY = calcMaxY(height, pos.y);
            v.setLocation(pos.x, maxY);
            addLabelVertex(v, null);
            vertexMap.put(nextVertexId, v);
            this.add(v);
            nextVertexId++;
        }
        //копируем ребра вершин
        for (Integer vertexId : selVertexLst) {
            Vertex _v = vertexMap.get(vertexId);
            Vertex v = vertexMap.get(_v.getCopyVertexId());
            ArrayList<Integer> edgeLst = new ArrayList<Integer>();
            for (Integer edgeId : getEdgeOut(_v)) {
                Edge _edge = edgeMap.get(edgeId);
                Integer newVIn = vertexMap.get(_edge.getInVertex()).getCopyVertexId();
                Integer newVOut = vertexMap.get(_edge.getOutVertex()).getCopyVertexId();
                if (isEdgeCopy(_edge.getPoint().getFirst(), _edge.getPoint().getLast())
                        && vertexIsUserArea(vertexMap.get(_edge.getInVertex()))
                        && vertexIsUserArea(vertexMap.get(_edge.getOutVertex()))) {
                    //ребро находится в выделенной области
                    LinkedList<Point2D.Double> pLst = new LinkedList<Point2D.Double>();
                    for (Point2D.Double _p : _edge.getPoint()) {
                        int maxY = calcMaxY(height, (int) _p.y);
                        Point2D.Double p = new Double(_p.x, maxY);
                        pLst.add(p);
                    }
                    Edge edge = new Edge(nextEdgeId, newVIn, newVOut, Edge.LINE, pLst);
                    edgeMap.put(nextEdgeId, edge);
                    edgeLst.add(nextEdgeId);
                    nextEdgeId++;
                    //подсчитываем кол-во выходящих ребер
                    if (v.getVertexId() == newVIn) {
                        Integer count = v.getOutVertex().get(newVOut);
                        if (count == null) {
                            count = 1;
                        } else {
                            count++;
                        }
                        v.getOutVertex().put(newVOut, count);
                    }
                    //добавляем ребро к вершине в которую входит ребро
                    vertexMap.get(newVOut).getEdgeIdLst().add(edge.getEdgeId());
                }
            }
            v.addEdgeLst(edgeLst);
        }
        rectUser1 = null;
        rectUser2 = null;
        repaint();
        // }
    }

    /**
     * Пользователь выбрал вершину
     * @param selectedValue
     * @return левая нижняя точка выбранной вершины
     */
    public Point2D.Double changeCurrent(Object selectedValue) {
        LabelVertex lbl = (LabelVertex) selectedValue;
        if (lbl == null) {
            return null;
        }
        Vertex v = vertexMap.get(lbl.getVertexId());
        if (current != null && !(current instanceof PanelPetri)) {
            current.setBorder(BorderFactory.createEmptyBorder());
        }
        curPLst.clear();
        Point p = v.getLocation();
        Dimension size = v.getSize();
        Point center = new Point(p.x + size.width / 2, p.y + size.height / 2);
        curPLst.add(center);
        current = v;
        current.setBorder(BorderFactory.createLineBorder(Color.GREEN, 1));
        return new Double(v.getLocation().x, v.getLocation().y);
    }

    /**
     * Загрузить из xml файл
     * @param in
     */
    public void loadFromXml(File in) {
        try {
            XmlIO xml = new XmlIO();
            PetriNet net = xml.readXML(in.getName(), in.getParent());
            //Удаляем предыдущую сеть
            newPetriNet();
            nextEdgeId = net.getNextEdgeId();
            nextPositionInd = net.getNextPositionIndex();
            nextTransitionInd = net.getNextTransitionId();
            nextVertexId = net.getNextVertexId();
            scale = (float) net.getDim().getScale();
            //загружаем список вершин
            Vertex v = null;
            HashMap<Integer, Integer> outEdge = null;
            ArrayList<Integer> edge = null;
            for (ru.ulstu.ptr.petrinetsch.Vertex vXml : net.getVertexLst().getVertex()) {
                if (vXml.getType() == 1) {
                    v = new Position(vXml.getVertexId(), vXml.getMarker(), vXml.getLabelName(), scale);
                } else {
                    v = new Transition(vXml.getVertexId(), vXml.getMarker(), vXml.getLabelName(), scale);
                }
                //добавляем исходящие из вершины ребра
                outEdge = new HashMap<Integer, Integer>();
                for (EdgeJoin join : vXml.getEdgeJoinOut()) {
                    outEdge.put(join.getVertexId(), join.getCount());
                }
                v.setOutVertex(outEdge);
                edge = new ArrayList<Integer>();
                for (Integer e : vXml.getEdgeIdLst()) {
                    edge.add(e);
                }
                v.setEdgeIdLst(edge);
                Point p1 = new Point((int) vXml.getPlace().getX(), (int) vXml.getPlace().getY());
                v.setLocation(p1);
                vertexMap.put(vXml.getVertexId(), v);

                //создаем новую метку для вершины
                Point p = new Point((int) vXml.getLabelPlace().getX(), (int) vXml.getLabelPlace().getY());
                addLabelVertex(v, p);
            }
            //загружаем список ребер
            Edge e = null;
            LinkedList<Point2D.Double> pLst = null;
            Point2D.Double p = null;
            for (ru.ulstu.ptr.petrinetsch.Edge eXml : net.getEdgeLst().getEdge()) {
                pLst = new LinkedList<Point2D.Double>();
                for (ru.ulstu.ptr.petrinetsch.Point pXml : eXml.getPointLst()) {
                    p = new Point2D.Double(pXml.getX(), pXml.getY());
                    pLst.add(p);
                }
                e = new Edge(eXml.getEdgeId(), eXml.getInVertexId(), eXml.getOutVertexId(), eXml.getTypeEdge(), pLst);
                edgeMap.put(eXml.getEdgeId(), e);
            }
            this.rebuildNet();
        } catch (JAXBException ex) {
            JOptionPane.showMessageDialog(this, "Ошибка", "Не удалось прочитать файл " + in.getAbsolutePath(), JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(PanelPetri.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Сохранить в xml файл
     * @param out
     */
    public void saveToXml(File out) {
        XmlIO xml = new XmlIO();
        PetriNet net = new PetriNet();
        //служебные данные
        net.setNextEdgeId(nextEdgeId);
        net.setNextPositionIndex(nextPositionInd);
        net.setNextTransitionId(nextTransitionInd);
        net.setNextVertexId(nextVertexId);
        //размеры
        ru.ulstu.ptr.petrinetsch.Dimension dim = new ru.ulstu.ptr.petrinetsch.Dimension();
        dim.setScale(scale);
        dim.setPositionRadius(Position.RADIUS * scale);
        dim.setMarkerRadius(Position.MARKER_RADIUS * scale);
        dim.setTransitionWidth(Transition._WIDTH * scale);
        dim.setTransitionHeight(Transition._HEIGHT * scale);
        net.setDim(dim);
        //собственно сама сеть
        //список вершин
        VertexLst vLst = new VertexLst();
        ru.ulstu.ptr.petrinetsch.Vertex vXml = null;
        ru.ulstu.ptr.petrinetsch.Point p = null;
        for (Vertex v : vertexMap.values()) {
            vXml = new ru.ulstu.ptr.petrinetsch.Vertex();
            vXml.setVertexId(v.getVertexId());
            vXml.setLabelName(v.getLabel());
            vXml.setMarker(v.getMarker());
            p = new ru.ulstu.ptr.petrinetsch.Point();
            p.setX(v.getLocation().x);
            p.setY(v.getLocation().y);
            vXml.setPlace(p);
            p = new ru.ulstu.ptr.petrinetsch.Point();
            JLabel lbl = labelMap.get(v.getVertexId());
            p.setX(lbl.getLocation().x);
            p.setY(lbl.getLocation().y);
            vXml.setLabelPlace(p);
            //p.setX(lbl.getP)
            //p.setX(scale);
            if (v instanceof Position) {
                vXml.setType(1);
            } else {
                vXml.setType(2);
            }
            //добавляем количество исходящих из вершины ребер
            EdgeJoin eJoin = null;
            for (Map.Entry<Integer, Integer> outV : v.getOutVertex().entrySet()) {
                eJoin = new EdgeJoin();
                eJoin.setVertexId(outV.getKey());
                eJoin.setCount(outV.getValue());
                vXml.getEdgeJoinOut().add(eJoin);
            }
            //добавляем ребра прилежащие к вершине
            for (Integer edgeId : v.getEdgeIdLst()) {
                vXml.getEdgeIdLst().add(edgeId);
            }
            vLst.getVertex().add(vXml);
        }
        net.setVertexLst(vLst);
        //список ребер
        EdgeLst eLst = new EdgeLst();
        ru.ulstu.ptr.petrinetsch.Edge eXml = null;
        for (Edge val : edgeMap.values()) {
            eXml = new ru.ulstu.ptr.petrinetsch.Edge();
            eXml.setEdgeId(val.getEdgeId());
            eXml.setInVertexId(val.getInVertex());
            eXml.setOutVertexId(val.getOutVertex());
            eXml.setTypeEdge(Edge.LINE);
            //добавляем координаты ребер
            for (Point2D.Double point : val.getPoint()) {
                p = new ru.ulstu.ptr.petrinetsch.Point();
                p.setX(point.x);
                p.setY(point.y);
                eXml.getPointLst().add(p);
            }
            eLst.getEdge().add(eXml);
        }
        net.setEdgeLst(eLst);
        xml.writeXML(net, out.getName(), out.getParent());
    }

    /**
     * Сгенерировать последовательность id вершин, в которые нужно будет перейти
     * @param countV во сколько вершин нужно перейти из позиции
     * @return
     */
    private int[] randomSeqVertex(ArrayList<Integer> outV) {
        int[] seq = new int[outV.size()];
        Random rnd = new Random();
        for (int i = 0; i < outV.size(); i++) {
            int num = 0;
            while (true) {
                num = rnd.nextInt(outV.size());
                boolean isUse = false;
                for (int j = 0; j < i; j++) {
                    if (seq[j] == outV.get(num)) {
                        isUse = true;
                    }
                }
                if (!isUse) {
                    seq[i] = outV.get(num);
                    break;
                }
            }
        }
        return seq;
    }

    /**
     * Получить массив ребер, которые выходят из вершины
     * @param v
     * @return
     */
    private ArrayList<Integer> getEdgeOut(Vertex v) {
        ArrayList<Integer> vOutLst = new ArrayList<Integer>();
        for (Map.Entry<Integer, Integer> obj : v.getOutVertex().entrySet()) {
            Integer vOut = obj.getKey();
            //находим все ребра которые исходят из текущей вершины
            for (Integer edgeId : v.getEdgeIdLst()) {
                Edge edge = edgeMap.get(edgeId);
                if (edge.getOutVertex() == vOut) {
                    vOutLst.add(edge.getEdgeId());
                }
            }
        }
        return vOutLst;
    }

    /**
     * Находится ли вершина в области выделения
     * @param v
     * @return
     */
    private boolean vertexIsUserArea(Vertex v) {
        Point pos = v.getLocation();
        Dimension size = v.getSize();
        if (rectUser1.x < pos.x && rectUser1.y < pos.y
                && (pos.x + size.width) < rectUser2.x && (pos.y + size.height) < rectUser2.y) {
            //вершина лежит в области выделения
            return true;
        }
        return false;
    }

    /**
     * Удалить вершину
     * @param v вершина для удаления
     */
    private void deleteVertex(Vertex v) {
        ArrayList<Integer> edgeIdLst = new ArrayList<Integer>();
        for (Integer edgeId : v.getEdgeIdLst()) {
            edgeIdLst.add(edgeId);
        }
        for (Integer edgeId : edgeIdLst) {
            deleteEdge(edgeId);
        }

        //удаляем надписи вершины
        JLabel lbl = labelMap.get(v.getVertexId());
        this.remove(lbl);
        labelMap.remove(v.getVertexId());
        //удаляем из списка вершин
        DefaultListModel mod = (DefaultListModel) vertexList.getModel();
        for (int i = 0; i < mod.size(); i++) {
            LabelVertex lblV = (LabelVertex) mod.get(i);
            if (lblV.getVertexId() == v.getVertexId()) {
                mod.remove(i);
                break;
            }
        }
        //теперь можно удалять и саму вершину
        this.remove(v);
        vertexMap.remove(v.getVertexId());
    }

    /**
     * Удалить ребро
     * @param edgeId id ребра
     */
    private void deleteEdge(Integer edgeId) {
        Edge edge = edgeMap.get(edgeId);
        //удаляем из вершин
        Vertex vIn = vertexMap.get(edge.getInVertex());
        ArrayList<Integer> oldEdge = vIn.getEdgeIdLst();
        for (int i = 0; i < oldEdge.size(); i++) {
            if (oldEdge.get(i) == edgeId) {
                oldEdge.remove(i);
                break;
            }
        }
        Vertex vOut = vertexMap.get(edge.getOutVertex());
        oldEdge = vOut.getEdgeIdLst();
        for (int i = 0; i < oldEdge.size(); i++) {
            if (oldEdge.get(i) == edgeId) {
                oldEdge.remove(i);
                break;
            }
        }
        //удаляем количество выходных ребер из первой вершины
        Integer count = vIn.getOutVertex().get(vOut.getVertexId());
        count--;
        if (count < 1) {
            vIn.getOutVertex().remove(vOut.getVertexId());
        } else {
            vIn.getOutVertex().put(vOut.getVertexId(), count);
        }
        edgeMap.remove(edgeId);
        removePanEgdeP();
    }

    /**
     * Вычислить смещение по Y на которое необходимо преместить эдемент сети
     * петри при копировании
     * @param height - высота области выделения
     * @param y - значения ординаты перемещаемого элемента сети петри
     * @return
     */
    private int calcMaxY(int height, int y) {
        if (rectUser2.y + height > maxP.y) {
            return (int) (rectUser2.y - 2 * Position.HEIGHT * scale - 10);
        }
        return height + y;
    }

    /**
     * Построить заново отображение сети
     */
    private void rebuildNet() {
        this.removeAll();
        for (Vertex v : vertexMap.values()) {
            this.add(v);
        }
        for (JLabel lbl : labelMap.values()) {
            this.add(lbl);
        }
        this.repaint();
    }

    /**
     * Изменить надпись вершины
     * @param txt новый текст надписи
     * @param v вершина, к которой прикреплена надпись
     */
    private void changeVertexLabel(String txt, Vertex v) {
        JLabel lbl = labelMap.get(v.getVertexId());
        lbl.setText(txt);
        //вычисляем ширину шрифта, чтобы установить надпись посередине вершины
        Dimension size = lbl.getPreferredSize();
        Dimension sizeV = v.getSize();
        Point pos = v.getLocation();
        lbl.setBounds((int) (pos.x + (sizeV.width - size.width) / 2), (int) (pos.y - sizeV.height / 2 - scale), (int) size.getWidth() + 2, (int) size.getHeight() + 2);
    }

    /**
     * Добавить надпись вершины
     * @param v вершина
     */
    private void addLabelVertex(Vertex v, Point p) {
        //создаем метку
        JLabel lbl = new JLabel(v.getLabel());
        lbl.setFont(petriFnt);
        //вычисляем ширину шрифта, чтобы установить надпись посередине вершины
        Dimension size = lbl.getPreferredSize();
        Dimension sizeV = v.getSize();
        if (p != null) {
            lbl.setBounds((int) (p.x), (int) (p.y), (int) size.getWidth() + 2, (int) size.getHeight() + 2);
        } else {
            Point pos = v.getLocation();
            lbl.setBounds((int) (pos.x + (sizeV.width - size.width) / 2), (int) (pos.y - sizeV.height / 2 - scale), (int) size.getWidth() + 2, (int) size.getHeight() + 2);
        }
        labelMap.put(v.getVertexId(), lbl);
        DefaultListModel mod = (DefaultListModel) vertexList.getModel();
        LabelVertex _lbl = new LabelVertex(v.getVertexId(), v.getLabel());
        mod.addElement(_lbl);
        this.add(lbl);
    }

    /**
     * Добавить вершину
     * @param pos - точка левого нижнего угла
     * @param type - тип вершины
     */
    private void addVertex(Point pos, int type) {
        Vertex v = null;

        if (type == POSITION) {
            v = new Position(nextVertexId, 0, "p" + nextPositionInd, scale);
            nextPositionInd++;
        } else {
            v = new Transition(nextVertexId, 0, "t" + nextTransitionInd, scale);
            nextTransitionInd++;
        }
        vertexMap.put(nextVertexId, v);
        Dimension size = v.getSize();
        Point pLeft = new Point((int) (pos.x - size.getWidth() / 2), (int) (pos.y - size.getHeight() / 2));
        v.setLocation(pLeft);
        this.add(v);
        this.enableVertexField(v);
        this.addLabelVertex(v, null);
        if (current != null) {
            current.setBorder(BorderFactory.createEmptyBorder());
        }
        current = v;
        current.setBorder(BorderFactory.createLineBorder(Color.GREEN, 1));
        this.repaint();
        nextVertexId++;
    }

    /**
     * Разблокировать поле для ввода надиси для позиции и перехода
     * или разблокировать поля для ввода надписи для перехода
     * @param v вершина графа сети Петри
     */
    private void enableVertexField(Vertex v) {
        if (v instanceof Position) {
            txtMark.setText(String.valueOf(v.getMarker()));
            txtMark.setEditable(true);
            txtMark.setFocusable(true);
            txtMark.selectAll();
            txtMark.requestFocus();
        } else {
            txtMark.setText("");
            txtMark.setEditable(false);
        }
        txtLabel.setText(v.getLabel());
        txtLabel.setEditable(true);
        txtLabel.setFocusable(true);
        btn.setEnabled(true);
    }

    /**
     * Заблокировать поля для воода надписей и маркеров вершин
     */
    private void disableVertexField() {
        txtLabel.setText("");
        txtLabel.setEditable(false);
        txtLabel.setFocusable(false);
        txtMark.setText("");
        txtMark.setEditable(false);
        txtMark.setFocusable(false);
        btn.setEnabled(false);
        this.setFocusable(true);
    }

    /**
     * Определить выбрал ли пользоватлеь область выделения
     * @return
     */
    private boolean isUserArea() {
        if (rectUser1 != null && rectUser2 != null) {
            return true;
        }
        return false;
    }

    /**
     * Определить принадлежит, ли точка выделенной пользователем области
     * @param p
     * @return
     */
    private boolean isPointUserArea(Point p) {
        if (rectUser1 == null) {
            return false;
        }
        int x = (rectUser1.x < rectUser2.x) ? rectUser1.x : rectUser2.x;
        int y = (rectUser1.y < rectUser2.y) ? rectUser1.y : rectUser2.y;
        int x1 = Math.abs(rectUser1.x - rectUser2.x) + x;
        int y1 = Math.abs(rectUser1.y - rectUser2.y) + y;
        return (x < p.x && y < p.y
                && p.x < x1 && p.y < y1);

    }

    /**
     * Проверяем копирует ли пользователь ребро 
     * @param p1
     * @param p2
     * @return
     */
    private boolean isEdgeCopy(Point2D.Double p1, Point2D.Double p2) {
        return isPointUserArea(new Point((int) p1.x, (int) p1.y)) && isPointUserArea(new Point((int) p2.x, (int) p2.y));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        Stroke strk = new BasicStroke(lnTkns, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER);
        g2.setStroke(strk);
        g2.setColor(Color.BLACK);
        //отображаем ребра сети Петри
        for (Edge e : edgeMap.values()) {
            LinkedList<Point2D.Double> pLst = e.getPoint();
            for (int i = 0; i < pLst.size() - 1; i++) {
                g2.draw(new Line2D.Double(pLst.get(i), pLst.get(i + 1)));
            }
            //рисуем стрелки
            double len = 10 * scale;
            Point2D.Double point1 = pLst.get(pLst.size() - 1);
            Point2D.Double point2 = pLst.get(pLst.size() - 2);
            double alpha;

            if (point1.y == point2.y) {
                if (point2.x < point1.x) {
                    alpha = Math.PI;
                } else {
                    alpha = 0;
                }
            } else {
                Point2D.Double p0 = GeomCalc.divideP(point2, point1, len);
                alpha = Math.acos((p0.x - point1.x) / (len));
            }
            int k1 = 1;
            if (point1.y > point2.y) {
                k1 = -1;
            }
            Point2D.Double p1 = new Point2D.Double(point1.x + len * Math.cos(k1 * alpha + 0.261), point1.y + len * Math.sin(k1 * alpha + 0.261));
            Point2D.Double p2 = new Point2D.Double(point1.x + len * Math.cos(k1 * alpha - 0.261), point1.y + len * Math.sin(k1 * alpha - 0.261));

            g2.draw(new Line2D.Double(p1, point1));
            g2.draw(new Line2D.Double(p2, point1));
        }

        boolean isEdge = false;
        if (_p2 != null) {
            //пользователь выбрал вторую точку ребра
            JComponent comp = (JComponent) getComponentAt(_p2);
            if (comp instanceof Vertex) {
                //точка принадлежит вершине, ищем ближайшую точку на границе вершины
                _p2 = findFirstP(_p2, comp);
                isEdge = true;
            }
        }
        if (_p1 != null && _p2 != null) {
            //пользователь рисует ребро
            g2.draw(new Line2D.Double(_p1.x, _p1.y, _p2.x, _p2.y));
            if (isEdge) {
                //рисуем стрелки
                double len = 10 * scale;
                Point2D.Double p0 = GeomCalc.divideP(_p1, _p2, len);
                double alpha = Math.acos((p0.x - _p2.x) / (len));
                int k1 = 1;
                if (_p2.y > _p1.y) {
                    k1 = -1;
                }
                Point2D.Double p1 = new Point2D.Double(_p2.x + len * Math.cos(k1 * alpha + 0.261), _p2.y + len * Math.sin(k1 * alpha + 0.261));
                Point2D.Double p2 = new Point2D.Double(_p2.x + len * Math.cos(k1 * alpha - 0.261), _p2.y + len * Math.sin(k1 * alpha - 0.261));

                g2.draw(new Line2D.Double(p1, _p2));
                g2.draw(new Line2D.Double(p2, _p2));
            }
        }

        if (isUserArea()) {
            //пользователь выделяет какую-то область
            float dash[] = {10, 10};
            Stroke strk1 = new BasicStroke(lnTkns, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 10, dash, 0);
            g2.setStroke(strk1);
            g2.setColor(Color.GREEN);
            int x = (rectUser1.x < rectUser2.x) ? rectUser1.x : rectUser2.x;
            int y = (rectUser1.y < rectUser2.y) ? rectUser1.y : rectUser2.y;

            int _w = Math.abs(rectUser1.x - rectUser2.x);
            int _h = Math.abs(rectUser1.y - rectUser2.y);
            g2.draw(new Rectangle(x, y, _w, _h));
        }

    }

    /**
     * Отобразить точки ребра
     * @param edge ребро
     */
    private void selectedEdgeP(Edge edge) {
        selEdgeId = edge.getEdgeId();
        //удаляем предыдущие метки
        for (JPanel pan : panEdgeLst) {
            this.remove(pan);
        }
        panEdgeLst.clear();
        PanelPointEdge pan = null;
        for (int i = 0; i < edge.getPoint().size(); i++) {
            pan = new PanelPointEdge(i, (Point2D.Double) edge.getPoint().get(i).clone(), scale);
            if (i == 0) {
                pan.setInVertex(true);
            } else if (i == edge.getPoint().size() - 1) {
                pan.setOutVertex(true);
            }
            int _w = (int) pan.getSize().width;
            pan.setLocation((int) (edge.getPoint().get(i).x - _w / 2), (int) (edge.getPoint().get(i).y - _w / 2));
            panEdgeLst.add(pan);
            this.add(pan, 0);
        }
        this.repaint();
    }

    /**
     * Найти ближайшую точку к вершине
     * @param p точка внутри вершины
     * @param comp вершина
     * @return
     */
    private Point findFirstP(Point p, JComponent comp) {
        Vertex v = (Vertex) (comp);
        Point res = null;
        Point pos = v.getLocation();
        Dimension size = v.getSize();
        if (v instanceof Transition) {
            if (p.x - pos.x < pos.x + size.width - p.x) {
                res = new Point(pos.x + 1, p.y);
            } else {
                res = new Point(pos.x + size.width - 1, p.y);
            }
        } else {
            Position vertP = (Position) v;
            Point2D.Double center = v.getCenter();
            //находим уго поворота выбранной точки
            double dis1 = GeomCalc.distace2point(center, new Point2D.Double(p.x, p.y));
            double alpha = Math.acos((p.x - center.x) / (dis1));
            if (p.y - pos.y < pos.y + size.width - p.y) {
                alpha = -alpha;
            }
            //находим саму точку
            res = new Point((int) Math.round(center.x + vertP.getRadius() * Math.cos(alpha)), (int) Math.round(center.y + vertP.getRadius() * Math.sin(alpha)));
        }
        return res;
    }

    /**
     * Поиск компонента, который содержит точку <code>p</code>.
     * При этом устанавливается выбранный пользователем элемент в
     * <code>current</code>.
     * <p>После чего выбранная пользователем точка добавляется
     * в последовательность выбранных пользователем точек</p>
     * @param p точка на панели
     */
    private void find(Point p) {
        JComponent comp = (JComponent) getComponentAt(p);
        current = comp;
        if (!curPLst.isEmpty()) {
            JComponent comp1 = (JComponent) getComponentAt(curPLst.getLast());
            if (!comp1.equals(comp)) {
                curPLst.offer(p);
            }
        } else {
            curPLst.offer(p);
        }
    }

    private void debug() {
        System.out.println("\n\nВершины");
        for (Vertex v : vertexMap.values()) {
            System.out.println(v.toString());
        }
        System.out.println("Ребра");
        for (Edge e : edgeMap.values()) {
            System.out.println(e.toString());
        }
    }

    private void removePanEgdeP() {
        selEdgeId = null;
        for (PanelPointEdge pan : panEdgeLst) {
            remove(pan);
        }
        panEdgeLst.clear();
    }

    /**
     * Перенести связанные с вершиной элементы
     * @param x смещение по x
     * @param y смещение по у
     */
    private void moveVertex(Vertex v, int x, int y) {
        JLabel lbl = labelMap.get(v.getVertexId());
        Point posLbl = lbl.getLocation();
        lbl.setLocation(posLbl.x + x, posLbl.y + y);

        //переносим все ребра прилегающие к вершине
        for (Integer edgeId : v.getEdgeIdLst()) {
            Edge edge = edgeMap.get(edgeId);
            Point2D.Double posEdge = null;
            if (edge.getOutVertex() == v.getVertexId()) {
                //последняя точка прилегает к вершине
                posEdge = edge.getPoint().getLast();
                posEdge.setLocation((posEdge.x + x), (posEdge.y + y));
                edge.getPoint().set(edge.getPoint().size() - 1, posEdge);
            } else {
                //первая точка прилегает к лершине
                posEdge = edge.getPoint().getFirst();
                posEdge.setLocation((posEdge.x + x), (posEdge.y + y));
                edge.getPoint().set(0, posEdge);
            }
        }
    }

    private class MouseHandler extends MouseInputAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            Point _p = e.getPoint();
            switch (buttonId) {
                case PanelPetri.POSITION:
                case PanelPetri.TRANSITION: {
                    //Нажата кнопка добавить позицию или переход
                    removePanEgdeP();
                    addVertex(_p, buttonId);
                    rectUser1 = null;
                    rectUser2 = null;
                    selVertexLst.clear();
                    break;
                }
                case PanelPetri.LINE: {
                    JComponent comp1 = (JComponent) getComponentAt(_p);
                    if (comp1 instanceof Vertex) {
                        //Пользователь хочет провести ребро
                        _p1 = findFirstP(_p, comp1);
                    }
                    //removePanEgdeP();
                    rectUser1 = null;
                    rectUser2 = null;
                    selVertexLst.clear();
                    break;
                }
                case PanelPetri.ARROW: {
                    //при нажатии на кнопку устанвливаем рамку над выбранным элементом
                    //над предыдущим убираем
                    find(_p);
                    if (!(current instanceof PanelPetri)) {
                        //если это какой то элемент сети претри
                        current.setBorder(BorderFactory.createLineBorder(Color.GREEN, 1));
                        if (current instanceof Vertex) {
                            enableVertexField((Vertex) current);
                        } else {
                            disableVertexField();
                        }
                        if (current instanceof Vertex || current instanceof JLabel) {
                            removePanEgdeP();
                        }
                        rectUser1 = null;
                        rectUser2 = null;
                        selVertexLst.clear();
                        repaint();
                    } else {
                        if (current instanceof PanelPetri) {
                            //пользователь хочет выделить облать прямоугольника
                            if (!isUserArea() || selVertexLst.isEmpty() || !isPointUserArea(_p)) {
                                //все таки пользователь перетаскивает элементы,
                                rectUser1 = _p;
                                rectUser2 = null;
                            } else {
                                //а добавляем новую область
                            }
                        }
                        disableVertexField();
                        //возможно пользователь выбрал ребро
                        //проверяем
                        boolean isEdge = false;
                        for (Edge edge : edgeMap.values()) {
                            LinkedList<Point2D.Double> pLst = edge.getPoint();
                            for (int i = 0; i < pLst.size() - 1; i++) {
                                if (GeomCalc.isPointLine(_p, pLst.get(i), pLst.get(i + 1))) {
                                    //все таки есть выбранное ребро, отображаем его точки
                                    selectedEdgeP(edge);
                                    isEdge = true;
                                    break;
                                }
                            }
                        }
                        if (!isEdge) {
                            removePanEgdeP();
                            repaint();
                        }
                    }

                    if (curPLst.size() > 1) {
                        //значит пользователь уже выбирал какой - то элемент
                        JComponent prev = (JComponent) getComponentAt(curPLst.poll());
                        if (prev != current) {
                            //у предыдущего элемента убираем рамку
                            prev.setBorder(BorderFactory.createEmptyBorder());
                            prev.repaint();
                        }
                    }
                }
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            //Удаляем последнюю точку при перетаскивании
            moveP.poll();
            if (_p1 != null && _p2 != null) {
                //пользователь выбрал две предположительные вершины
                JComponent comp1 = (JComponent) getComponentAt(_p1);
                JComponent comp2 = (JComponent) getComponentAt(_p2);
                if (comp1 instanceof Vertex && comp2 instanceof Vertex) {
                    //точно вершнины, тогда добавляем ребро
                    Vertex v1 = (Vertex) comp1;
                    Vertex v2 = (Vertex) comp2;
                    if ((v1 instanceof Position && v2 instanceof Transition || v2 instanceof Position && v1 instanceof Transition)
                            && v1.getVertexId() != v2.getVertexId()) {
                        //вершины не одинакового типа, теперь добавляем
                        LinkedList<Point2D.Double> pLst = new LinkedList<Point2D.Double>();
                        pLst.add(new Point2D.Double(_p1.x, _p1.y));
                        pLst.add(new Point2D.Double(_p2.x, _p2.y));
                        Edge edge = new Edge(nextEdgeId, v1.getVertexId(), v2.getVertexId(), LINE, pLst);
                        edgeMap.put(nextEdgeId, edge);
                        Integer countE = v1.getOutVertex().get(v2.getVertexId());
                        if (countE == null) {
                            countE = 1;
                        } else {
                            countE++;
                        }
                        v1.getOutVertex().put(v2.getVertexId(), countE);
                        v1.getEdgeIdLst().add(nextEdgeId);
                        v2.getEdgeIdLst().add(nextEdgeId);
                        nextEdgeId++;
                    } else {
                        repaint();
                    }
                } else {
                    repaint();
                }
            }
            _p1 = null;
            _p2 = null;

            if (current instanceof PanelPointEdge) {
                //перенесли точку ребра
                PanelPointEdge panEdge = (PanelPointEdge) current;
                //находим в какую вершину перенесли точку
                Edge _edge = edgeMap.get(selEdgeId);
                Point2D.Double _pEdge = _edge.getPoint().get(panEdge.getIndex());
                JComponent _comp = (JComponent) getComponentAt((int) _pEdge.x, (int) _pEdge.y);
                if (_comp instanceof Vertex) {
                    //перенесли в какую-то вершину
                    Vertex v = (Vertex) _comp;
                    if ((_edge.getInVertex() == v.getVertexId() && panEdge.getIndex() == 0)
                            || (_edge.getOutVertex() == v.getVertexId() && panEdge.getIndex() == _edge.getPoint().size() - 1)) {
                        //перенесли в ту же самую вершину, в которое было направлено ребро до перетаскивания
                    } else if ((_edge.getInVertex() == v.getVertexId() && panEdge.getIndex() == _edge.getPoint().size() - 1)
                            || (_edge.getOutVertex() == v.getVertexId() && panEdge.getIndex() == 0)) {
                        //перенесли ребро указывающее на одну и ту же вершину
                        //возвращаем ребро на первоначальное место
                        _edge.getPoint().set(panEdge.getIndex(), panEdge.getBegin());
                    } else {
                        //перенесли в новую вершину
                        if (panEdge.isInVertex()) {
                            if ((v instanceof Transition && (vertexMap.get(_edge.getOutVertex())) instanceof Transition)
                                    || (v instanceof Position && vertexMap.get(_edge.getOutVertex()) instanceof Position)) {
                                //нельзя соединять ребром две одинаковые вершины //возвращаем ребро на первоначальное место
                                _edge.getPoint().set(panEdge.getIndex(), panEdge.getBegin());
                                selectedEdgeP(_edge);
                                return;
                            }
                            //перенесли начало контакта
                            //удаляем ребро из старой вершины
                            ArrayList<Integer> oldEdge = vertexMap.get(_edge.getInVertex()).getEdgeIdLst();
                            for (int i = 0; i < oldEdge.size(); i++) {
                                if (oldEdge.get(i) == _edge.getEdgeId()) {
                                    oldEdge.remove(i);
                                    break;
                                }
                            }
                            //удаляем выходные ребра исходящие из вершины
                            Integer oldCount = vertexMap.get(_edge.getInVertex()).getOutVertex().get(_edge.getOutVertex()) - 1;
                            if (oldCount < 1) {
                                vertexMap.get(_edge.getInVertex()).getOutVertex().remove(_edge.getOutVertex());
                            } else {
                                vertexMap.get(_edge.getInVertex()).getOutVertex().put(_edge.getOutVertex(), oldCount);
                            }

                            //устанавливаем в какие новыве вершины направлено ребро
                            boolean isVertex = false;
                            for (Integer edgeId : v.getEdgeIdLst()) {
                                if (edgeId == _edge.getEdgeId()) {
                                    isVertex = true;
                                }
                            }
                            if (!isVertex) {
                                //к вершине еще не прилегает такое ребро
                                v.getEdgeIdLst().add(_edge.getEdgeId());
                            }
                            Integer newCount = v.getOutVertex().get(_edge.getOutVertex());
                            if (newCount == null) {
                                newCount = 1;
                            } else {
                                newCount++;
                            }
                            v.getOutVertex().put(_edge.getOutVertex(), newCount);
                            _edge.setInVertex(v.getVertexId());
                        } else if (panEdge.isOutVertex()) {
                            //перенесли конец ребра
                            if ((v instanceof Transition && (vertexMap.get(_edge.getInVertex())) instanceof Transition)
                                    || (v instanceof Position && vertexMap.get(_edge.getInVertex()) instanceof Position)) {
                                //нельзя соединять ребром две одинаковые вершины //возвращаем ребро на первоначальное место
                                _edge.getPoint().set(panEdge.getIndex(), panEdge.getBegin());
                                selectedEdgeP(_edge);
                                return;
                            }
                            //перенесли начало ребра
                            //удаляем ребро из старой вершины
                            ArrayList<Integer> oldEdge = vertexMap.get(_edge.getOutVertex()).getEdgeIdLst();
                            for (int i = 0; i < oldEdge.size(); i++) {
                                if (oldEdge.get(i) == _edge.getEdgeId()) {
                                    oldEdge.remove(i);
                                    break;
                                }
                            }
                            //удаляем выходные ребра исходящие из вершины
                            Integer oldCount = vertexMap.get(_edge.getInVertex()).getOutVertex().get(_edge.getOutVertex()) - 1;
                            if (oldCount < 1) {
                                vertexMap.get(_edge.getInVertex()).getOutVertex().remove(_edge.getOutVertex());
                            } else {
                                vertexMap.get(_edge.getInVertex()).getOutVertex().put(_edge.getOutVertex(), oldCount);
                            }

                            //устанавливаем в какие новыве вершины направлено ребро
                            boolean isVertex = false;
                            for (Integer edgeId : v.getEdgeIdLst()) {
                                if (edgeId == _edge.getEdgeId()) {
                                    isVertex = true;
                                }
                            }
                            if (!isVertex) {
                                //к вершине еще не прилегает такое ребро
                                v.getEdgeIdLst().add(_edge.getEdgeId());
                            }
                            Integer newCount = vertexMap.get(_edge.getInVertex()).getOutVertex().get(v.getVertexId());
                            if (newCount == null) {
                                newCount = 1;
                            } else {
                                newCount++;
                            }
                            vertexMap.get(_edge.getInVertex()).getOutVertex().put(v.getVertexId(), newCount);
                            _edge.setOutVertex(v.getVertexId());
                        }
                    }
                } else {
                    if (panEdge.getIndex() == 0 || panEdge.getIndex() == edgeMap.get(selEdgeId).getPoint().size() - 1) {
                        //перенесли начало или конец ребра незнамо куда в пустое место
                        //возвращаем ребро на первоначальное место
                        _edge.getPoint().set(panEdge.getIndex(), panEdge.getBegin());
                    }
                }
                Integer ind = panEdge.getIndex();
                selectedEdgeP(_edge);
                panEdgeLst.get(ind).setBorder(BorderFactory.createLineBorder(Color.GREEN, 1));

            }

            if (isUserArea()) {
                selVertexLst.clear();
                //пользователь отметил область выделения
                //находим вершины, которые в ней лежат
                int x = (rectUser1.x < rectUser2.x) ? rectUser1.x : rectUser2.x;
                int y = (rectUser1.y < rectUser2.y) ? rectUser1.y : rectUser2.y;
                int x1 = Math.abs(rectUser1.x - rectUser2.x) + x;
                int y1 = Math.abs(rectUser1.y - rectUser2.y) + y;

                rectUser1 = new Point(x, y);
                rectUser2 = new Point(x1, y1);

                for (Vertex v : vertexMap.values()) {
                    if (vertexIsUserArea(v)) {
                        //вершина лежит в области выделения
                        selVertexLst.add(v.getVertexId());
                    }
                }
            }
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            //после двойного щелчка пытаемя добавить дополнительное ребро
            Point p = e.getPoint();
            JComponent comp = (JComponent) getComponentAt(p);
            if (comp instanceof PanelPetri && e.getClickCount() >= 2 && selEdgeId != null) {
                //пользователь решил добавить дополнительную точку к ребру
                //находим между какими точками
                LinkedList<Point2D.Double> pLst = edgeMap.get(selEdgeId).getPoint();
                for (int i = 1; i < pLst.size(); i++) {
                    if (GeomCalc.isPointLine(p, pLst.get(i - 1), pLst.get(i))) {
                        //нашли, добавляем
                        pLst.add(i, new Point2D.Double(p.x, p.y));
                        selectedEdgeP(edgeMap.get(selEdgeId));
                        break;
                    }
                }
            }
        }
    }

    private class MouseMoutionHandler implements MouseMotionListener {

        @Override
        public void mouseMoved(MouseEvent e) {
            if (isUserArea() && isPointUserArea(e.getPoint()) && !selVertexLst.isEmpty()) {
                //мышь находится над выделенной пользователем областью
                //меняем курсор
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                return;
            }
            JComponent comp = (JComponent) getComponentAt(e.getPoint());
            switch (buttonId) {
                case ARROW: {
                    if (!(comp instanceof JPanel)) {
                        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    } else {
                        setCursor(Cursor.getDefaultCursor());
                    }
                    break;
                }
                default: {
                    setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
                }
            }
        }

        public void mouseDragged(MouseEvent e) {

            if (buttonId == LINE) {
                //пользователь пытается провести ребро
                if (_p1 != null) {
                    //первая вершина уже выбрана
                    _p2 = e.getPoint();
                }

                repaint();
            }
            if (buttonId == ARROW) {
                if (!(current instanceof PanelPetri)) {
                    //перетаскиваем какой-то элемент
                    moveP.offer(e.getPoint());
                    if (moveP.size() > 1) {
                        //перенесли во вторую точку
                        Point p2 = e.getPoint();
                        Point p1 = moveP.pop();
                        Point p0 = current.getLocation();
                        double x = p2.getX() - p1.getX();
                        double y = p2.getY() - p1.getY();
                        Point pNew = new Point((int) (p0.getX() + x), (int) (p0.getY() + y));
                        current.setLocation(pNew);
                        if (current instanceof Vertex) {
                            //при перетаскивании вершины, положение метки также меняется
                            Vertex v = (Vertex) current;
                            moveVertex(v, (int) x, (int) y);
                            repaint();
                        } else if (current instanceof PanelPointEdge) {
                            //перетаскиваем точки ребра
                            //находим какую точку ребра перетаскиваем
                            Edge _edge = edgeMap.get(selEdgeId);
                            Integer index = ((PanelPointEdge) current).getIndex();
                            //временно удаляем с панели
                            remove(current);
                            //перетаскиваем первую или последнюю точки ребра
                            JComponent _comp = (JComponent) getComponentAt(pNew);
                            if (_comp instanceof Vertex
                                    && (index == 0 || index == _edge.getPoint().size() - 1)) {
                                //пользователь перетаскивает точку ребра в вершину
                                Point newP = findFirstP(pNew, _comp);
                                _edge.getPoint().set(index, new Point2D.Double(newP.x, newP.y));
                            } else {
                                _edge.getPoint().set(index, new Point2D.Double(pNew.x, pNew.y));
                            }
                            repaint();
                        }
                        if (curPLst.size() > 0) {
                            // изменяем положение предыдущей точки на новую
                            curPLst.set(0, pNew);
                        }
                    }
                } else if (isUserArea() && isPointUserArea(e.getPoint()) && !selVertexLst.isEmpty()) {
                    //пользователь уже выделил область и в ней находятся элементы сети петри
                    //значит он их перетаскивает
                    moveP.offer(e.getPoint());
                    if (moveP.size() > 1) {
                        //перенесли во вторую точку
                        Point p2 = e.getPoint();
                        Point p1 = moveP.pop();
                        Point p0 = rectUser1;
                        double x = p2.getX() - p1.getX();
                        double y = p2.getY() - p1.getY();
                        Point pNew = new Point((int) (p0.x + x), (int) (p0.y + y));

                        //переносим вершины, которые находятся в выделенной области
                        for (Integer vertexId : selVertexLst) {
                            Vertex v = vertexMap.get(vertexId);
                            Point pos = v.getLocation();
                            v.setLocation((int) (pos.x + x), (int) (pos.y + y));
                            moveVertex(v, (int) x, (int) y);
                        }

                        rectUser1 = pNew;
                        rectUser2 = new Point((int) (rectUser2.x + x), (int) (rectUser2.y + y));
                        repaint();
                        if (curPLst.size() > 0) {
                            // изменяем положение предыдущей точки на новую
                            curPLst.set(0, pNew);
                        }
                    }

                } else {
                    //пользователь захотел выделить элементы сети петри
                    if (rectUser1 != null) {
                        rectUser2 = e.getPoint();
                        repaint();
                    }
                }
            }
        }
    }
}
