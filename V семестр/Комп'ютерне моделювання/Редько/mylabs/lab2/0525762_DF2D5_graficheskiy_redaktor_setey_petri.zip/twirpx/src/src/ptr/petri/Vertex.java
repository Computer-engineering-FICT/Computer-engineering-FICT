package ptr.petri;

import java.awt.Font;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComponent;

/**
 * Вершина графа
 * @author st
 */
public class Vertex extends JComponent {

    /**
     * id вершины
     */
    protected Integer vertexId;
    /**
     * Кол-во маркеров
     */
    protected int marker;
    /**
     * Количество ребер исходящих из вершины( ключ- в какую вершину направлено ребро, значение -сколько ребер)
     */
    protected HashMap<Integer, Integer> outVertex;
    /**
     * id ребер, прилегающих к вершине
     */
    protected ArrayList<Integer> edgeIdLst;
    /**
     * Название вершины
     */
    protected String label;
    /**
     * масштаб
     * По умолчанию 100%
     */
    protected float scale = 1.0f;
    /**
     * Толщина линии при черчении элемента
     */
    protected float lnTkns;
    private Integer copyVertexId = null;

    public Vertex(Integer vertexId, int marker, String label, float scale) {
        this.vertexId = vertexId;
        this.marker = marker;
        this.label = label;
        this.scale = scale;
        edgeIdLst = new ArrayList<Integer>();
        outVertex = new HashMap<Integer, Integer>();
        lnTkns = 1.1f * scale;
    }

    public void addMarker(int num) {
        this.marker += num;
    }

    public void subMarker(int num) {
        this.marker -= num;
        if(marker <0) {
            System.out.println("маркеров меньше 0!!!!!!!!!!!!!!!!!!!!!!!!");
        }
    }

    public void addEdgeLst(ArrayList<Integer> edgeLst) {
        for(Integer edgeId: edgeLst) {
            edgeIdLst.add(edgeId);
        }
    }

    public float getLnTkns() {
        return lnTkns;
    }

    public void setLnTkns(float lnTkns) {
        this.lnTkns = lnTkns;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getMarker() {
        return marker;
    }

    public void setMarker(int marker) {
        this.marker = marker;
    }

    public Integer getCopyVertexId() {
        return copyVertexId;
    }

    public void setCopyVertexId(Integer copyVertexId) {
        this.copyVertexId = copyVertexId;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
    }

    public Integer getVertexId() {
        return vertexId;
    }

    /**
     * Добавить ребро исходящее из вершины
     * @param vertexId id вершины
     * @param edgeId id ребра
     */
    public void addEdgeOut(Integer vertexId, Integer edgeId) {
        this.addEdge(vertexId, 2, edgeId);
    }

    /**
     * Добавить ребро прилегающее к вершине
     * @param edgeId id ребра
     */
    public void addEdgeIn(Integer edgeId) {
        edgeIdLst.add(edgeId);
    }

    private void addEdge(Integer vertexId, int type, Integer edgeId) {
        //ребро направлено из вершины
        Integer count = outVertex.get(vertexId);
        if (count == null) {
            outVertex.put(vertexId, 1);
        } else {
            count++;
            outVertex.put(vertexId, count);
        }
        edgeIdLst.add(edgeId);
    }

    /**
     * Получить id ребер, которые прилегают к вершине
     * @return
     */
    public ArrayList<Integer> getEdgeIdLst() {
        return edgeIdLst;
    }

    public HashMap<Integer, Integer> getOutVertex() {
        return outVertex;
    }

    public void setEdgeIdLst(ArrayList<Integer> edgeIdLst) {
        this.edgeIdLst = edgeIdLst;
    }

    public void setOutVertex(HashMap<Integer, Integer> outVertex) {
        this.outVertex = outVertex;
    }

    public Point2D.Double getCenter() {
        Point2D.Double center = new Double(getLocation().x + getSize().width / 2, getLocation().y + getSize().height / 2);
        return center;
    }

    @Override
    public String toString() {
        StringBuilder res = new StringBuilder("Vertex vertexId=" + vertexId + " marker=" + marker + " label=" + label + ":\n ");
        res.append("В какие вершины направлены ребра: \n");
        for (Map.Entry<Integer, Integer> e : outVertex.entrySet()) {
            res.append("\t В ").append(e.getKey()).append(" = ").append(e.getValue()).append(" ребер \n");
        }
        res.append("Ребра прилегающие к вершине: \n");
        for (Integer edge : edgeIdLst) {
            res.append(" ").append(edge).append(", ");
        }
        return res.toString();
    }
}
