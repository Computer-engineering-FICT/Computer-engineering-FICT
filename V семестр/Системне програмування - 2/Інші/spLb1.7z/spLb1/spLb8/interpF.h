float cnvTo_f(int td, union gnDat *p1, union gnDat *p2);
double cnvTo_d(int td, union gnDat *p1, union gnDat *p2);
int cnvTo_i(int td, union gnDat *p1, union gnDat *p2);
union gnDat _fadd(union gnDat*,union gnDat*);
