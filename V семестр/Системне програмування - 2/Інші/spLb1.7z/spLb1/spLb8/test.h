float a=2.4, e=3.77, b[3]={12,3,7.3}, *p;
int n=0, c=4, d;
e=n?4:a;
e=b[++n]*2*c;
