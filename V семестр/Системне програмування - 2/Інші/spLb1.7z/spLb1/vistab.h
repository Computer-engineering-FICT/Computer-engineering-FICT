enum color
{violet, blue, green, yellow, orange, red
};
void prClr(enum color cl);
void prRow(struct recrd* rw);
void prTab(struct recrd* tb, short n);
