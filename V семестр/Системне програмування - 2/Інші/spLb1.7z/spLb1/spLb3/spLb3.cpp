// spLb3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>
#include "visgrp.h"
#include "token.h"
#include "automat.h"
char *imgs[100] = {"a","b","n","1","0"};

struct lxNode pic[]={
{_EOS,&pic[1],NULL,0,0,0,0,0,NULL,0}, // ;
{_whileP,&pic[2],&pic[4],0,0,0,0,0,NULL,0},// whileP 
{_ne,&pic[14],&pic[3],0,0,0,0,0,NULL,0}, //n<>0
{_nam,(struct lxNode*)imgs[4],NULL,0,0,0,0,0,NULL,0}, //0
{_EOS,&pic[5],&pic[10],0,0,0,0,0,NULL,0}, // ;
{_ass,&pic[7],&pic[6],0,0,0,0,0,NULL,0}, // :=
{_add,&pic[7],&pic[8],0,0,0,0,0,NULL,0},//+ 
{_nam,(struct lxNode*)imgs[1],NULL,0,0,0,0,0,NULL,0}, //b
{_ixbz,&pic[9],&pic[14],0,0,0,0,0,NULL,0},//[]
{_nam,(struct lxNode*)imgs[0],NULL,0,0,0,0,0,NULL,0},//a
{_ass,&pic[14],&pic[12],0,0,0,0,0,NULL,0}, //:=
{_EOS,&pic[1],&pic[11],0,0,0,0,0,NULL,0}, // ;
{_sub,&pic[14],&pic[13],0,0,0,0,0,NULL,0},//-
{_nam,(struct lxNode*)imgs[3],NULL,0,0,0,0,0,NULL,0}, //1;
{_nam,(struct lxNode*)imgs[2],NULL,0,0,0,0,0,NULL,0},//n
};

extern char *oprtrC[], *oprtrP[], *oprtrV[], *cprC[], *cprP[], *cprV[];

char **oprtr = oprtrP, **cpr = cprP, modeP = 1, // ��� ���������� ����������� ����� ��� �������
		modeC = 0, // ��� ���������� ����������� ����� ��� �

		modeL = modeP;

int n = 3, b=0, a[3] = { 0, 1, 2 };

int main(int argc, char* argv[]) {
	int press_key;

	prLxTxt(pic + 0);
	printf("\n");

	enum autSgn ASgn[14]={sg0,sg0,sg0,sg0,sg0,sg0,sg0,cfr,sg0,sg0,sg0,sg0,sg0};
	for(n=0;n<14;n++){
	enum autStat temp=nxtStat(ASgn[n]);	
	printf("->%2d\n",temp);
	}
	scanf("%i", &press_key);
	return 0;

















}
