#include "stdafx.h"
#include "automat.h"
#include <stdio.h>
enum autStat nxtSts[Se][sgE+1] =
{
 {S2,S7,S8,S2,S1},	//��� S1
 {S3,S7,S8,S2,S2},	//	  S2
 {S4,S7,S8,S2,S3},	//	  S3
 {S5,S7,S8,S2,S4},	//	  S4
 {S6,S7,S8,S2,S5},	//	  S5
 {S7,S7,S8,S2,S6},	//	  S6
 {S8,S7,S8,S2,S7},	//	  S7
 {Se,S7,S8,S2,S8},  //    S8
 {S1,S7,S8,S2,Se},	//	  Se
};

enum autStat nxtStat(enum autSgn sgn)
{
	printf("%5d",s);
	return s=nxtSts[s-1][sgn];// ����� ���� �������
};

