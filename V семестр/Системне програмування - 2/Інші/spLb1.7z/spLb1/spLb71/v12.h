int b[2][3]={{3,12},{7,3}}, a, *p;
unsigned n=1, c, d, e;
e=b[--n]*2*a;
