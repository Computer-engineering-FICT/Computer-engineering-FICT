float b, a[3,5];
unsigned n;
while(n--)b+=a[n,1];