float b, a[3][5];
static unsigned int n=2, i, *pi, ai[3];
while(n--)b+=a[n][1];