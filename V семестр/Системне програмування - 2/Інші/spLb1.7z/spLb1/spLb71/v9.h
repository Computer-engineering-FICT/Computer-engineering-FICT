int f(int b, long x)
{int c=0,d,n=1;
float a[10]={5,7};
b=c?d:2*a[n];  
return b;
}
