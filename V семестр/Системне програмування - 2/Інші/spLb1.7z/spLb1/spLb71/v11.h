struct col{int blue; unsigned green; char red;}n, *pn;
int a, b[2];
unsigned n=1, c, d, e;
e=b[--n]*2*a;
