b:=sin(2*a);    
b  :=	  a;