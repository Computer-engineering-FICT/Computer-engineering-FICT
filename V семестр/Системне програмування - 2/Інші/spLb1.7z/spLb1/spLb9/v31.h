unsigned b,a[2],n=3;
do{if(n)break;
}while(--n);
