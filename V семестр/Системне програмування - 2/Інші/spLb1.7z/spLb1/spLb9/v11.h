float a=3, b[3]={-9,7},*c=b+1,
c2=2;
int n=1, e=4, d=13, __1=-1;
b[n+1]=e;
if(c[n]){d%=e+n;}
else 
e=b[--n]*c2*a;
a=b[n]*a-d/e;
