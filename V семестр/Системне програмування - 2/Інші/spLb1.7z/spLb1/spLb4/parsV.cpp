#include "stdafx.h"
#include "automat.h"
#include "..\spLb3\parsV.cpp"
