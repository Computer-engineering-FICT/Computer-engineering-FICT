if c 
	then b:=sin(2*a)    
else b:=a;
