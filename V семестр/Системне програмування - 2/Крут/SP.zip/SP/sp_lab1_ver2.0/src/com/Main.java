package com;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by User on 30.09.2016.
 */
public class Main {
    public static void main(String[] args) {

        TableLab table = new TableLab(new ArrayList<Row>(Arrays.asList(
                new Row(new KeyStruct("First", 1), new FuncStruct(Weak.MONDAY)),
                new Row(new KeyStruct("Second", 2), new FuncStruct(Weak.TUESDAY)),
                new Row(new KeyStruct("Third", 3), new FuncStruct(Weak.WEDNESDAY)),
                new Row(new KeyStruct("Fourth", 4), new FuncStruct(Weak.THURTHDAY)),
                new Row(new KeyStruct("Fifth", 5), new FuncStruct(Weak.FRIDAY)),
                new Row(new KeyStruct("Sixth", 6), new FuncStruct(Weak.SATURDAY)),
                new Row(new KeyStruct("Seventh", 7), new FuncStruct(Weak.SUNDAY)))));

        table.print();

        Row testRow1 = new Row(new KeyStruct("Second", 2), new FuncStruct(Weak.TUESDAY));
        Row testRow2 = table.selectBin(new KeyStruct("Second", 2));

        testRow1.print();

        System.out.println("\nBinarySearch Testing:\n");
        if (testRow2 != null) {
            testRow2.print();
            System.out.println("\nSearch successfull ? - " + testRow1.equals(testRow2));
        } else {
            System.out.println("TestRow2 = null");
        }

        System.out.println("\nSimilarity Testing:\n");
        //���� ���������. ��������! ������� �� ������ � �������� ���������, �� �� ENUM'�
        ArrayList<Row> result = table.similarRows(new Row(new KeyStruct("F�khdhu4rst", 1), new FuncStruct(Weak.SATURDAY)));
        for (Row row : result) {
            row.print();
        }
    }
}

