package com;

/**
 * Created by User on 16.11.2016.
 */
public enum Weak {
    MONDAY, TUESDAY, WEDNESDAY, THURTHDAY, FRIDAY, SATURDAY, SUNDAY
}
