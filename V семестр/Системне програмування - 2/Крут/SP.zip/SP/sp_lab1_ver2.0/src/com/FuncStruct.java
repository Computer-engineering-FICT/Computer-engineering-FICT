package com;

public class FuncStruct {

    private Weak func;

    public FuncStruct(Weak func) {
        this.func = func;
    }

    public Weak getFunc() {
        return func;
    }
}
