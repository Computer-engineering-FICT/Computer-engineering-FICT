package com.task2;

/**
 * Created by User on 03.11.2016.
 */
public class GraphNode {
    int id;
    GraphNode dlm;
    GraphNode ctr;

    public GraphNode(int id) {
        this.id = id;
    }
}
