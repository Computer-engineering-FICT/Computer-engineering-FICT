package com.task1;

import java.util.ArrayList;

/**
 * Created by User on 03.11.2016.
 */
public class Tree {
    ArrayList<Node> nodes;
    StringBuilder result;
    char[] terminals;

    public Tree() {
        result = new StringBuilder();
        nodes = new ArrayList<>();
        terminals = new char[]{'=', '?', ']', '[', '*', ':'};
        Node node1 = new Node('k', null, null, false);
        Node node2 = new Node('l', null, null, false);
        Node node3 = new Node('=', node1, node2, true);
        Node node4 = new Node('d', null, null, false);
        Node node5 = new Node('?', node3, node4, true);
        Node node6 = new Node('p', null, null, false);
        Node node7 = new Node(']', node6, null, true);
        Node node8 = new Node('a', null, null, false);
        Node node9 = new Node('[', node8, node7, true);
        Node node10 = new Node('4', null, null, false);
        Node node11 = new Node('*', node10, node9, true);
        Node node12 = new Node(':', node5, node11, true);

        node1.parent = node3;
        node2.parent = node3;
        node3.parent = node5;
        node4.parent = node5;
        node5.parent = node12;
        node6.parent = node7;
        node7.parent = node9;
        node8.parent = node9;
        node9.parent = node11;
        node10.parent = node11;
        node11.parent = node12;

        nodes.add(node1);
        nodes.add(node2);
        nodes.add(node3);
        nodes.add(node4);
        nodes.add(node5);
        nodes.add(node6);
        nodes.add(node7);
        nodes.add(node8);
        nodes.add(node9);
        nodes.add(node10);
        nodes.add(node11);
        nodes.add(node12);
    }

    public void print() {
        Node root = root(nodes.get(0));
        search(root);
        System.out.println(result);
    }

    private void search(Node node) {
        if (node.left != null) {
            search(node.left);
        }
        result.append(node.value);
        if (node.right != null) {
            search(node.right);
        }
    }

    private Node root(Node node) {
        Node result = node;
        if (node.parent != null) {
            result = root(node.parent);
        }
        return result;
    }
}
