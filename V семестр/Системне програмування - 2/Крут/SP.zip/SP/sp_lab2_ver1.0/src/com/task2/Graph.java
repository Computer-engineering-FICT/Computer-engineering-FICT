package com.task2;

import java.util.ArrayList;

/**
 * Created by User on 03.11.2016.
 */
public class Graph {
    ArrayList<GraphNode> nodes;
    GraphNode current;
    GraphNode finish;

    public Graph() {
        nodes = new ArrayList<>();

        GraphNode node1 = new GraphNode(1);
        GraphNode node2 = new GraphNode(2);
        GraphNode node3 = new GraphNode(3);
        GraphNode node4 = new GraphNode(4);
        GraphNode node5 = new GraphNode(5);
        GraphNode node6 = new GraphNode(6);
        GraphNode node7 = new GraphNode(7);
        GraphNode node8 = new GraphNode(8);
        GraphNode node9 = new GraphNode(9);

        node1.dlm = node2;
        node1.ctr = node2;

        node2.dlm = node3;
        node2.ctr = node3;

        node3.dlm = node3;
        node3.ctr = node4;

        node4.dlm = node5;
        node4.ctr = node5;

        node5.dlm = node6;
        node5.ctr = node9;

        node6.dlm = node7;
        node6.ctr = node7;

        node7.dlm = node8;
        node7.ctr = node8;

        node8.dlm = node9;
        node8.ctr = node9;

        node9.dlm = node9;
        node9.ctr = node9;

        nodes.add(node1);
        nodes.add(node2);
        nodes.add(node3);
        nodes.add(node4);
        nodes.add(node5);
        nodes.add(node6);
        nodes.add(node7);
        nodes.add(node8);
        nodes.add(node9);

        current = node1;
        finish = node9;
    }

    public void dlm() {
        if (current != null) {
            System.out.print("dlm\t" + current.id + "\t" + ">\t");
            current = current.dlm;
            System.out.println(current.id);
        }
    }
    public void ctr() {
        if (current != null) {
            System.out.print("ctr\t" + current.id + "\t" + ">\t");
            current = current.ctr;
            System.out.println(current.id);
        }
    }
    public void command(String command) {
        if (current == null || current.equals(finish)) {
            return;
        }
        if (command.equals("ctr")) {
            ctr();
        } else if (command.equals("dlm")) {
            dlm();
        } else {
            System.out.println(command + "\t" + current.id + "\t->\tERROR");
            current = null;
        }
    }
}
