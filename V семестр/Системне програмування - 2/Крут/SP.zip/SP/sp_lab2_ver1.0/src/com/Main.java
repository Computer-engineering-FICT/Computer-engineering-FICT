package com;

import com.task1.Tree;
import com.task2.Graph;

/**
 * Created by User on 03.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("_____________________Part 1_______________________");
        Tree tree = new Tree();
        tree.print();
        System.out.println("_____________________Part 2_______________________");

        Graph graph = new Graph();

        graph.command("ctr");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("ctr");
        graph.command("ctr");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("dlm");


    }
}
