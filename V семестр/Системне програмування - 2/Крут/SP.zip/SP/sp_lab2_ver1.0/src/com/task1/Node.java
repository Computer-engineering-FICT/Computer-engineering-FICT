package com.task1;

/**
 * Created by User on 03.11.2016.
 */
public class Node {
    char value;
    Node left;
    Node right;
    boolean isTerminal;
    Node parent;

    public Node(char value, Node left, Node right, boolean isTerminal) {
        this.value = value;
        this.left = left;
        this.right = right;
        this.isTerminal = isTerminal;
    }
}
