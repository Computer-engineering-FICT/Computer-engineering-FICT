import nodes.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Main {
	public static void main(String[] args) {
        String text = "for i:=1 to n do begin if (a>b) then begin a:=b end; end;";

		Lexer lexer = new Lexer(text);
		Parser parser = new Parser(lexer);
		Stmt stmt = parser.stmt();
		System.out.println(stmt);
    }
}
