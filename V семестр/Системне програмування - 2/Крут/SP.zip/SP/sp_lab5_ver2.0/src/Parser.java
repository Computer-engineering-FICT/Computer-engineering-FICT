import tokens.*;
import nodes.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Parser {
	private Lexer lex;
	private Token look;
	
	public Parser(Lexer l) {
		lex = l;
		move();
	}
	
	private void move() {
		look = lex.scan();
	}
	
	private void error() {
		error("syntax error");
	}
	
	private void error(String message) {
		throw new Error(message);
	}
	
	private void match(Tag t) {
		if (look.tag != t) error();
		move();
	}
	
	public Stmt stmt() {
        Stmt stmt;
        Assign assign;
        Comp comp;
        Id id;

		switch (look.tag) {
			case IF:
				match(Tag.IF);
				match(Tag.LPAREN);
                comp = comp();
                match(Tag.RPAREN);
				match(Tag.THEN);
                stmt = stmt();
				return new If(comp, stmt);
            case FOR:
                match(Tag.FOR);
                assign = assign();
                match(Tag.TO);
                id = id();
                match(Tag.DO);
                stmt = stmt();
                return new For(assign, id, stmt);
            case BEGIN:
                match(Tag.BEGIN);
                stmt = stmt();
                match(Tag.END);
                match(Tag.SEMICOLON);
                return stmt;
			default:
				return assign();
		}
	}

	private Comp comp() {
        Id left = id();
        match(Tag.GREATER);
        Id right = id();

        return new Comp(Word.greater, left, right);
    }

	private Assign assign() {
		Id target1 = id();
		match(Tag.ASSIGN);
		Id target2 = id();
		
		return new Assign(target1, target2);
	}

	private Id id() {
		if (look.tag != Tag.ID && look.tag != Tag.NUM) {
			error();
		}
		Id id = new Id((Word)look);
        move();
		return id;
	}
}
