import java.util.*;
import tokens.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Lexer {
	private static final char EOF = '\0';
	
	private final HashMap<String, Word> words = new HashMap<>();
	private final String text;
	
	private char peek;
	private int idx;
	
	public Lexer(String t) {
		text = t;
		reserveWords();
	}
	
	private void reserveWords() {
		reserve("if", Tag.IF);
		reserve("then", Tag.THEN);
		reserve("for", Tag.FOR);
        reserve("to", Tag.TO);
        reserve("do", Tag.DO);
        reserve("begin", Tag.BEGIN);
        reserve("end", Tag.END);
	}
	
	private void reserve(String lexeme, Tag t) {
		words.put(lexeme, new Word(lexeme, t));
	}
	
	public Token scan() {
		while (Character.isWhitespace(nextch())) readch();
		switch (readch()) {
			case EOF:
				return Token.NULL;
			case '(':
				return Word.lparen;
			case ')':
				return Word.rparen;
            case ';':
                return Word.semicolon;
            case '>':
                return Word.greater;
			case ':':
				if (nextch('=')) {
					readch();
					return Word.assign;
				}
		}
		if (Character.isDigit(peek)) {
			int n = Character.digit(peek, 10);
			while (Character.isDigit(nextch())) {
				n = n*10 + Character.digit(readch(), 10);
			}
			return new Num(n);
		}
		if (Character.isLetter(peek)) {
			StringBuilder b = new StringBuilder();
			b.append(peek);
			while (Character.isLetter(nextch())) {
				b.append(readch());
			}
			String s = b.toString();
			Word w = words.get(s);
			if (w != null) return words.get(s);
			w = new Word(s, Tag.ID);
			words.put(s, w);
			return w;
		}
		return new Word(Character.toString(peek), Tag.ID);
	}
	
	private char readch() {
		peek = nextch(); idx++;
		return peek;
	}
	
	private char nextch() {
		if (idx < text.length()) {
			return text.charAt(idx);
		}
		return EOF;
	}
	
	private boolean nextch(char c) {
		return nextch() == c;
	}
}
