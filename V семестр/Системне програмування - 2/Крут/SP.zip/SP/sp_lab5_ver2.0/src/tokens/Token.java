package tokens;

/**
 * @author Alexander Tchaikovsky
 */
public class Token {
	public static final Token NULL = new Token(Tag.NULL);
	
	public final Tag tag;
	
	public Token(Tag t) {
		tag = t;
	}

	@Override
	public String toString() {
		return tag.toString();
	}
}
