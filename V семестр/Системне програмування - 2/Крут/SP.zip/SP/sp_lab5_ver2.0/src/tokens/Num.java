package tokens;

/**
 * @author Alexander Tchaikovsky
 */
public class Num extends Word {
	public final int value;
	
	public Num(int v) {
		super(Integer.toString(v), Tag.NUM);
		value = v;
	}

	@Override
	public String toString() {
		return Integer.toString(value);
	}
}
