package tokens;

/**
 * @author Alexander Tchaikovsky
 */
public enum Tag {
	NULL, ID,
    IF, THEN,
    FOR, TO, DO,
	LPAREN, RPAREN,
    BEGIN, END,
    SEMICOLON,
    GREATER,
	ASSIGN,
	NUM,
}
