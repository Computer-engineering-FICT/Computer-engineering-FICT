package tokens;

/**
 * @author Alexander Tchaikovsky
 */
public class Word extends Token {
	public static final Word
		lparen = new Word("(", Tag.LPAREN),
		rparen = new Word(")", Tag.RPAREN),
		assign = new Word(":=", Tag.ASSIGN),
        greater = new Word(">", Tag.GREATER),
        semicolon = new Word(";", Tag.SEMICOLON);
	
	public final String lexeme;
	
	public Word(String s, Tag tag) {
		super(tag);
		lexeme = s;
	}

	@Override
	public String toString() {
		return lexeme;
	}
}
