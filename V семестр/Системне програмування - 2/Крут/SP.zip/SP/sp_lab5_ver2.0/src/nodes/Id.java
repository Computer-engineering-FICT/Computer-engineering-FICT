package nodes;

import tokens.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Id extends Stmt {
	public final Word id;
	
	public Id(Word i) {
		super(i, null, null);
		id = i;
	}
}
