package nodes;

import tokens.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Stmt extends Node {
	public static final Stmt NULL = new Stmt(Token.NULL, null, null);
	
	public Stmt(Token t, Node l, Node r) {
		super(t, l, r);
	}
}
