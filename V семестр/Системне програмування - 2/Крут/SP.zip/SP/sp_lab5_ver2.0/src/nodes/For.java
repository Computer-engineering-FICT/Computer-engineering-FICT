package nodes;

/**
 * @author Alexander Tchaikovsky
 */
public class For extends Stmt {
    public final Assign assign;
    public final Id id;
    public final Stmt stmt;

    public For(Assign assign, Id id, Stmt stmt) {
        super(id.token, assign, stmt);
        this.assign = assign;
        this.id = id;
        this.stmt = stmt;
    }
}
