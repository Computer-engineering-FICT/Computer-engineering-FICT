package nodes;

import tokens.Tag;
import tokens.Word;

/**
 * @author Alexander Tchaikovsky
 */
public class If extends Stmt {
	public final Comp condition;
	public final Stmt then;
	
	public If(Comp c, Stmt t) {
		super(new Word("if", Tag.IF), c, t);
		condition = c;
		then = t;
	}
}
