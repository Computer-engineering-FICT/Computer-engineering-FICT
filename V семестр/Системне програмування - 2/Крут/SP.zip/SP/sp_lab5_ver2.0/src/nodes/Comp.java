package nodes;

import tokens.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Comp extends Stmt {
    public final Token operation;
    public final Id left;
    public final Id right;

    public Comp(Token op, Id l, Id r) {
        super(op, l, r);
        operation = op;
        left = l;
        right = r;
    }
}
