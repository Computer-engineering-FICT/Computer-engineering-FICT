package nodes;

import tokens.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Node {
	public final Token token;
	public final Node left;
	public final Node right;

	public Node(Token t, Node l, Node r) {
		token = t;
		left = l;
		right = r;
	}

	public StringBuilder toString(StringBuilder prefix, boolean isTail, StringBuilder sb) {
        if (right != null) {
            right.toString(new StringBuilder().append(prefix).append(isTail ? "│   " : "    "), false, sb);
        }
        sb.append(prefix).append(isTail ? "└── " : "┌── ").append(token).append("\n");
        if (left != null) {
            left.toString(new StringBuilder().append(prefix).append(isTail ? "    " : "│   "), true, sb);
        }
        return sb;
    }

    @Override
    public String toString() {
        return this.toString(new StringBuilder(), true, new StringBuilder()).toString();
    }
}
