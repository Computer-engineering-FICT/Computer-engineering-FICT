package nodes;

import tokens.*;

/**
 * @author Alexander Tchaikovsky
 */
public class Assign extends Stmt {
	public final Id target;
	public final Id id;
	
	public Assign(Id t, Id id) {
		super(Word.assign, t, id);
		target = t;
		this.id = id;
	}
}
