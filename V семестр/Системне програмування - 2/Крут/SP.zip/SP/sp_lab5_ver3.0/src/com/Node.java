package com;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by User on 22.11.2016.
 */
public class Node {

    private static int count = 0;

    private int id;
    private String value;
    private Node left;
    private Node rigth;


    public Node(String value) {
        this.value = value;
        this.id = count;
        count++;
    }
    public String getValue() {
        return value;
    }
    public void setLeft(Node left) {
        this.left = left;
    }
    public void setRigth(Node rigth) {
        this.rigth = rigth;
    }

    private List<Node> getChildren(){
        List<Node> result = new ArrayList<Node>();
        if (left != null)
            result.add(left);
        if (rigth != null)
            result.add(rigth);
        return result;
    }
    public void print() {
        System.out.printf("Node #%d; Value: \"%s\"; Left: \"%s\"; Right: \"%s\".\n", id, value,
                left == null ? "<none>" : left.getValue(),
                rigth == null ? "<none>" : rigth.getValue());
    }

    public void print(String prefix, boolean isTail) {
        System.out.println(prefix + (isTail ? "└── " : "├── ") + value);
        for (int i = 0; i < getChildren().size() - 1; i++) {
            getChildren().get(i).print(prefix + (isTail ? "    " : "│   "), false);
        }
        if (getChildren().size() > 0) {
            getChildren().get(getChildren().size() - 1)
                    .print(prefix + (isTail ?"    " : "│   "), true);
        }
    }
}
