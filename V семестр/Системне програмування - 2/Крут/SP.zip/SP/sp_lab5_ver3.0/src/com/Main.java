package com;

/**
 * Created by User on 22.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        Analyzer analyzer = new Analyzer();

        try {
            Tree tree = analyzer.parse("if a > b then begin a := b ; end else begin a := b ; end ;");
            tree.getRoot().print("", true);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }
}
