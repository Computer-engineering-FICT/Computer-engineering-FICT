package com;

import java.util.ArrayList;
import java.util.*;

/**
 * Created by User on 22.11.2016.
 */
public class Analyzer {

    private String[] tokens = new String[]{
            "begin", "end", "if", "else", "then", "!=", ":=", ">", "<", "=", "*", "(", ")", "[", "]", ";", "+", "-", "/"
    };
    private String[] operators = new String[]{
            "!=", ":=", ">", "<", "=", "*", "+", "-", "/"
    };
    private String[] keyWords = new String[]{
            "begin", "end", "if", "else", "then"
    };

    public Tree parse(String input) {

        System.out.println(input);

        checkErrorsInString(input);

        String[] array = stringToElementsArray(input);

        checkErrorsInArray(array);

        Tree tree = new Tree();
        tree.setRoot(tree.arrayToTree(array, 0, array.length - 1));
        return tree;
    }

    private String[] stringToElementsArray(String input) {
        return input.split(" ");
    }

    private void checkErrorsInString(String input) throws IllegalArgumentException{
        if (input.contains("( >") ||
                input.contains("( <") ||
                input.contains("> )") ||
                input.contains("< )") ||
                input.contains("( +") ||
                input.contains("+ )") ||
                input.contains("( -") ||
                input.contains("- )") ||
                input.contains("> ;") ||
                input.contains("< ;") ||
                input.contains("( ;") ||
                input.contains("!= >") ||
                input.contains("!= <") ||
                input.contains(":= >") ||
                input.contains(":= <") ||
                input.contains("< :=") ||
                input.contains("> :=") ||
                input.contains("< !=") ||
                input.contains("> !=") ||
                input.contains("> *") ||
                input.contains("< *") ||
                input.contains("* >") ||
                input.contains("* <") ||
                input.contains("else then") ||
                input.contains("if else") ||
                input.contains("if then") ||
                input.contains("end begin") ||
                input.contains("end end") ||
                input.contains("end if") ||
                input.contains("end then") ||
                input.contains("if end") ||
                input.contains("if begin") ||
                input.contains("begin then") ||
                input.contains("begin else")){
            throw new IllegalArgumentException("Incorrect Input");
        }
    }

    private void checkErrorsInArray(String[] array) throws IllegalArgumentException {

        ArrayList<String> tokensList = new ArrayList<String>(Arrays.asList(tokens));
        ArrayList<String> operatorssList = new ArrayList<String>(Arrays.asList(operators));
        ArrayList<String> keyWordsList = new ArrayList<String>(Arrays.asList(keyWords));

        for (int i = 0; i < array.length - 1; i++) {
            String first = array[i];
            String second = array[i + 1];

            if (first.equals("end") && !(second.equals(";") || second.equals("else"))) {
                throw new IllegalArgumentException("Error after \"end\" statement");
            }

            if (!tokensList.contains(first) && !tokensList.contains(second)) {
                throw new IllegalArgumentException("Error! Two or more variables contract");
            }

            if ((operatorssList.contains(first) && keyWordsList.contains(second) ||
            operatorssList.contains(second) && keyWordsList.contains(first))) {
                throw new IllegalArgumentException("Error! Unknown statement: " + first + " " + second);
            }
        }
    }
}
