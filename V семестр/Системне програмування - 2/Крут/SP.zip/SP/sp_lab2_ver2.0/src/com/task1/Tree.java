package com.task1;

import java.util.ArrayList;

/**
 * Created by User on 03.11.2016.
 */
public class Tree {
    ArrayList<Node> nodes;
    StringBuilder result;
    String[] terminals;

    public Tree() {
        result = new StringBuilder();
        nodes = new ArrayList<>();
        terminals = new String []{"if", "then","else", "!=", ":=", "(", ")", "[", "]", "*", ";"};
        Node node01 = new Node("c", null, null, false);
        Node node02 = new Node("0", null, null, false);
        Node node03 = new Node("b", null, null, false);
        Node node04 = new Node("d", null, null, false);
        Node node05 = new Node("b", null, null, false);
        Node node06 = new Node("2", null, null, false);
        Node node07 = new Node("a", null, null, false);
        Node node08 = new Node("n", null, null, false);
        Node node09 = new Node("(", null, node01, true);
        Node node10 = new Node(":=", node03, node04, true);
        Node node11 = new Node(":=", node05, node06, true);
        Node node12 = new Node("]", node08, null, true);
        Node node13 = new Node(";", node12, null, true);
        Node node14 = new Node("[", node07, node13, true);
        Node node15 = new Node("*", node11, node14, true);
        Node node16 = new Node(")", node02, null, true);
        Node node17 = new Node("if",null, node09, true);
        Node node18 = new Node("!=", node17, node16, true);
        Node node19 = new Node(" then ", node18, node10, true);
        Node node20 = new Node(" else ", node19, node15, true);

        node01.parent = node09;
        node02.parent = node16;
        node03.parent = node10;
        node04.parent = node10;
        node05.parent = node11;
        node06.parent = node11;
        node07.parent = node14;
        node08.parent = node12;
        node09.parent = node17;
        node10.parent = node19;
        node11.parent = node15;
        node12.parent = node13;
        node13.parent = node14;
        node14.parent = node15;
        node15.parent = node20;
        node16.parent = node18;
        node17.parent = node18;
        node18.parent = node19;
        node19.parent = node20;

        nodes.add(node01);
        nodes.add(node02);
        nodes.add(node03);
        nodes.add(node04);
        nodes.add(node05);
        nodes.add(node06);
        nodes.add(node07);
        nodes.add(node08);
        nodes.add(node09);
        nodes.add(node10);
        nodes.add(node11);
        nodes.add(node12);
        nodes.add(node13);
        nodes.add(node14);
        nodes.add(node15);
        nodes.add(node16);
        nodes.add(node17);
        nodes.add(node18);
        nodes.add(node19);
        nodes.add(node20);
    }

    public void print() {
        Node root = root(nodes.get(0));
        search(root);
        System.out.println(result);
    }

    private void search(Node node) {
        if (node.left != null) {
            search(node.left);
        }
        result.append(node.value);
        if (node.right != null) {
            search(node.right);
        }
    }

    private Node root(Node node) {
        Node result = node;
        if (node.parent != null) {
            result = root(node.parent);
        }
        return result;
    }
}
