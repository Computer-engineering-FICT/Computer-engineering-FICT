package com;

import com.task1.Tree;
import com.task2.Graph;

/**
 * Created by User on 03.11.2016.
 */

/*
if c!=0 then b:=d else b:=2*a[n];
	Стани 1..9; 7->7(dlm), 5->3(cfr), 3->1(ltr)
		Pascal

 */
public class Main {
    public static void main(String[] args) {
        System.out.println("_____________________Part 1_______________________");
        Tree tree = new Tree();
        tree.print();
        System.out.println("_____________________Part 2_______________________");

        Graph graph = new Graph();

        graph.command("dlm");
        graph.command("cfr");
        graph.command("ltr");
        graph.command("ltr");
        graph.command("ltr");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("ltr");
        graph.command("ltr");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("dlm");
        graph.command("cfr");
        graph.command("ltr");



    }
}
