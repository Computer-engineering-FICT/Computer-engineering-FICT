package com;

/**
 * Created by User on 03.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        Analyzer analyzer = new Analyzer();
        analyzer.analise("if(c!=0)then b:=d else b:=2*a[n];");
    }
}
