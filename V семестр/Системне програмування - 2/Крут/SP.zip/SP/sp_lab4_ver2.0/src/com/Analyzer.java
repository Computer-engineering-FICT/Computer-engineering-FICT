package com;

import java.util.ArrayList;

/**
 * Created by User on 22.11.2016.
 */
public class Analyzer {

    private String[] tokens = new String[]{
            "begin", "end", "if", "else", "then", "!=", ":=", ">", "<", "=", "*", "(", ")", "[", "]", ";", "+", "-", "/"
    };

    public Tree parse(String input) {
        String[] array = stringToElementsArray(input);
        Tree tree = new Tree();
        tree.setRoot(tree.arrayToTree(array, 0, array.length - 1));
        return tree;
    }

    private String[] stringToElementsArray(String input) {
        String[] elements = input.split(" ");
        ArrayList<String> elementsList = new ArrayList<String>();
        ArrayList<String> tokensList = new ArrayList<String>();

        for (String element : elements) {
            elementsList.add(element);
        }

        for (String token : tokens) {
            tokensList.add(token);
        }

        String[] result = new String[elementsList.size()];
        result = elementsList.toArray(result);
        return result;
    }

    private ArrayList<String> fillTokenList(String input) {
        ArrayList<String> tokensList = new ArrayList<>();
        String inputCopy = new String(input);

        for (int i = 0; i < tokens.length; ) {
            if (inputCopy.contains(tokens[i])) {
                try {
                    inputCopy = inputCopy.replaceFirst(tokens[i], "");
                } catch (Exception e) {
                    tokens[i] = String.format("\\%s", tokens[i]);
                    inputCopy = inputCopy.replaceFirst(tokens[i], "");
                    tokens[i] = tokens[i].substring(1);
                } finally {
                    tokensList.add(tokens[i]);
                }
            }
            else {
                i++;
            }
        }
        return tokensList;
    }
}
