package com;

import java.util.ArrayList;

/**
 * Created by User on 22.11.2016.
 */
public class Tree {
    private static Node root;
    private ArrayList<Node> nodes;

    public Tree() {
        this.nodes = new ArrayList<>();
    }

    Node arrayToTree(String[] array, int start, int end) {
        if (start > end) {
            return null;
        }
        int mid = (start + end)/2;
        Node node = new Node(array[mid]);
        node.setLeft(arrayToTree(array, start, mid - 1));
        node.setRigth(arrayToTree(array, mid + 1, end));
        nodes.add(node);
        return node;
    }
    public static void setRoot(Node root) {
        Tree.root = root;
    }
    public void print() {
        nodes.forEach(com.Node::print);
    }
}
