package com;

import java.util.ArrayList;

/**
 * Created by User on 22.11.2016.
 */
public class Analyzer {

    private static String[] tokens = new String[]{
            "==", "++", "+", "--", "-", "=", "?", ":", "*", "[", "]", ";", "{", "}", "-", "/", "(", ")", "<", ">"
    };

    public Tree parse(String input) {
        String[] array = stringToElementsArray(input);
        Tree tree = new Tree();
        tree.setRoot(tree.arrayToTree(array, 0, array.length - 1));
        return tree;
    }

    private String[] stringToElementsArray(String input) {
        System.out.println("Input string:  " + input);
        String tokensRegEx = "[(==)=?\\]\\[:*;\\{\\}\\+\\-\\\\(\\+\\+)(\\-\\-)\\(\\)<>]";

        String[] variables = input.split(tokensRegEx);

        ArrayList<String> variablesList = new ArrayList<>();
        for (String string : variables) {
            if (!string.equals("")) {
                variablesList.add(string);
            }
        }

        ArrayList<String> tokensList = fillTokenList(input);

        ArrayList<String> expressionList = new ArrayList<>();

        int resultLength = tokensList.size() + variablesList.size();
        for (int i = 0; i < resultLength; i++) {

            String newElement = null;
            for (String posibleToken : tokens) {
                String substring = input.length() < posibleToken.length() ? "" : input.substring(0, posibleToken.length());
                if (substring.equals(posibleToken)) {
                    newElement = posibleToken;
                    try {
                        input = input.replaceFirst(newElement, "");
                    } catch (Exception e) {
                        newElement = String.format("\\%s", newElement);
                        input = input.replaceFirst(newElement, "");
                        newElement = newElement.substring(1);
                    }
                    break;
                }
            }
            if (newElement == null) {
                newElement = variablesList.get(0);
                variablesList.remove(0);
                input = input.replaceFirst(newElement, "");
            }

            expressionList.add(newElement);
        }

        String[] result = new String[expressionList.size()];
        result = expressionList.toArray(result);
        return result;
    }

    private ArrayList<String> fillTokenList(String input) {
        ArrayList<String> tokensList = new ArrayList<>();
        String inputCopy = new String(input);

        for (int i = 0; i < tokens.length; ) {
            if (inputCopy.contains(tokens[i])) {
                try {
                    inputCopy = inputCopy.replaceFirst(tokens[i], "");
                } catch (Exception e) {
                    tokens[i] = String.format("\\%s", tokens[i]);
                    inputCopy = inputCopy.replaceFirst(tokens[i], "");
                    tokens[i] = tokens[i].substring(1);
                } finally {
                    tokensList.add(tokens[i]);
                }
            }
            else {
                i++;
            }
        }
        return tokensList;
    }
}
