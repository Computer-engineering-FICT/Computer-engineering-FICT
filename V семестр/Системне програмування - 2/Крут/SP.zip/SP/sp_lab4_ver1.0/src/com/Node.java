package com;

/**
 * Created by User on 22.11.2016.
 */
public class Node {

    private static int count = 0;

    private int id;
    private String value;
    private Node left;
    private Node rigth;

    public Node(String value) {
        this.value = value;
        this.id = count;
        count++;
    }
    public String getValue() {
        return value;
    }
    public void setLeft(Node left) {
        this.left = left;
    }
    public void setRigth(Node rigth) {
        this.rigth = rigth;
    }
    public void print() {
        System.out.printf("Node #%d; Value: \"%s\"; Left: \"%s\"; Right: \"%s\".\n", id, value,
                left == null ? "<none>" : left.getValue(),
                rigth == null ? "<none>" : rigth.getValue());
    }
}
