package com;

/**
 * Created by User on 22.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        Analyzer analyzer = new Analyzer();
        Tree tree = analyzer.parse("b=cd:b*a[n];");
        tree.print();
    }
}
