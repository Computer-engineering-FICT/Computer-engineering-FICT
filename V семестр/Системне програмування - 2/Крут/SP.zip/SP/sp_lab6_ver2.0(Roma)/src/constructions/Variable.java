package constructions;

import tokens.Word;

public class Variable implements Node {
    public final Word word;

    public Variable(Word word) {
        this.word = word;
    }
}
