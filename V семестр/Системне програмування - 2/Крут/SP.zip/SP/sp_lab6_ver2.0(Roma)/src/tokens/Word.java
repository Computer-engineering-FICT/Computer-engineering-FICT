package tokens;

public class Word extends Token {
	public static final Word
        add = new Word("+", Tag.ADD),
        sub = new Word("-", Tag.SUB),
		mul = new Word("*", Tag.MUL),
        lbrac = new Word("[", Tag.LBRAC),
        rbrac = new Word("]", Tag.RBRAC),
        comma = new Word(",", Tag.COMMA),
        semicolon = new Word(";", Tag.SEMICOLON),
        assign = new Word(":=", Tag.ASSIGN),
        notEqual = new Word("!=", Tag.NOTEQUAL),
		question = new Word("?", Tag.QUESTION),
		colon = new Word(":", Tag.COLON);
	
	public final String lexeme;
	
	public Word(String s, Tag tag) {
		super(tag);
		lexeme = s;
	}

	@Override
	public String toString() {
		return lexeme;
	}
}
