import constructions.Node;

import java.util.List;

/**
 * double b, a[4];  unsigned n,d; b:=d!=0; b:=2*a[n];
 */
public class Main {
	public static void main(String[] args) {
//        String text = "double b, d, a[5]; cardinal c, n; " +
//                "n := 0; a[n] := 1;" +
//                "n := 1; a[n] := 2;" +
//                "n := 2; a[n] := 3;" +
//                "n := 3; a[n] := 4;" +
//                "n := 4; a[n] := 5;" +
//                " d := 3; c := 0;";

        String text = "double b, c, a[4]; cardinal n,d; n := 0; a[n] := 1; b:=2*a[n]; d:=4; c:=d!=0;";
        Lexer lexer = new Lexer(text);
        Parser parser = new Parser(lexer);
        List<Node> nodes = parser.parse();

        Interpreter interpreter = new Interpreter(nodes);
        interpreter.run();
        interpreter.printVariablesValues();
    }
}
