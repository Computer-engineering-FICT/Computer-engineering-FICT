package com;

/**
 * Created by User on 30.09.2016.
 */
public class Row {

    private FuncStruct funcStruct;
    private KeyStruct keyStruct;
    private char charDel;

    public Row(KeyStruct keyStruct, FuncStruct funcStruct) {
        this.funcStruct = funcStruct;
        this.keyStruct = keyStruct;
    }

    public int compareTo(Row row) {
        return this.keyStruct.getKeySeq().compareTo(row.keyStruct.getKeySeq());
    }
    public boolean equals(Row row) {
        boolean result = false;

        if (this != null && row != null &&
                this.keyStruct.getKeySeq().equals(row.keyStruct.getKeySeq()) &&
                this.keyStruct.getnMod() == row.keyStruct.getnMod() &&
                this.funcStruct.getFunc().getInteger() == row.funcStruct.getFunc().getInteger() &&
                this.funcStruct.getFunc().getString().equals(row.funcStruct.getFunc().getString()) &&
                this.charDel == row.charDel) {
            result = true;
        }
        return result;
    }

    public void print() {
        if (this != null) {
            System.out.println("Key Struct : 1. keyStr:" + getKeyStruct().getKeySeq() + "; 2.nMod: " + getKeyStruct().getnMod());
            if (getFuncStruct().getFunc().getString() != null) {
                System.out.println("Func Struct : func: string: " + getFuncStruct().getFunc().getString());
            } else {
                System.out.println("Func Struct : func: integer: " + getFuncStruct().getFunc().getInteger());
            }
            System.out.println("Char : " + getCharDel());
        }
    }

    public FuncStruct getFuncStruct() {
        return funcStruct;
    }
    public KeyStruct getKeyStruct() {
        return keyStruct;
    }

    public char getCharDel() {
        return charDel;
    }
    public void setCharDel(char charDel) {
        this.charDel = charDel;
    }
}
