package com;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by User on 30.09.2016.
 */
public class Main {
    public static void main(String[] args) {

        TableLab table = new TableLab(new ArrayList<Row>(Arrays.asList(
                new Row(new KeyStruct("First", 1), new FuncStruct(new Union("Union1"))),
                new Row(new KeyStruct("Second", 2), new FuncStruct(new Union("Union2"))),
                new Row(new KeyStruct("Third", 3), new FuncStruct(new Union("Union3"))),
                new Row(new KeyStruct("Fourth", 4), new FuncStruct(new Union("Union4"))),
                new Row(new KeyStruct("Fifth", 5), new FuncStruct(new Union(5))),
                new Row(new KeyStruct("Sixth", 6), new FuncStruct(new Union(6))),
                new Row(new KeyStruct("Seventh", 7), new FuncStruct(new Union(7))))));
/*
        table.print();

        Row testRow1 = new Row(new KeyStruct("Second", 2), new FuncStruct(new Union("Union2")));
        Row testRow2 = table.selectBin(new KeyStruct("Second", 2));
        Row testRow3 = table.selectBin(new KeyStruct("Second", 2));

        testRow1.print();
        if (testRow2 != null) {
            testRow2.print();
            System.out.println(testRow1.equals(testRow2));
        } else {
            System.out.println("TestRow2 = null");
        }
        if (testRow3 != null) {
            testRow3.print();
            System.out.println(testRow1.equals(testRow3));
        } else {
            System.out.println("TestRow3 = null");
        }
        */
        ArrayList<Row> result = table.similarRows(new Row(new KeyStruct("F�khdhu4rst", 1), new FuncStruct(new Union("Union1"))));
        for (Row row : result) {
            row.print();
        }
    }
}

