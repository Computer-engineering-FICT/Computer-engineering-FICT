package com;

public class Union {
    private String string;
    private int integer;

    public Union(String string) {
        this.string = string;
    }
    public Union(int integer) {
        this.integer = integer;
    }

    public String getString() {
        return string;
    }
    public void setString(String string) {
        this.string = string;
        this.integer = 0;
    }

    public int getInteger() {
        return integer;
    }
    public void setInteger(int integer) {
        this.integer = integer;
        this.string = null;
    }
}
