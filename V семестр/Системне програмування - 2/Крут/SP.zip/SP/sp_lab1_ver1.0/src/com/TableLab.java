package com;

import java.util.*;

/**
 * Created by User on 30.09.2016.
 */
public class TableLab {

    private int pointer = 0;
    private List<Row> table = new ArrayList<Row>();

    public TableLab(ArrayList<Row> table) {
        this.table = table;
    }

    public Row selectNum(int nEl){
        Row result = null;
        if (nEl < table.size()) {
            result = table.get(nEl);
        }
        return result;
    }
    public void insertNum(Row row, int nEl) {
        if (nEl < 0 || nEl > table.size()) {
            throw new ArithmeticException("Invalid nEl");
        } else {
            table.add(nEl, row);
        }
    }
    public void updateNum(Row row, int nEl) {
        if (nEl < 0 || nEl > table.size()) {
            throw new ArithmeticException("Invalid nEl");
        } else {
            table.remove(nEl);
            table.add(nEl, row);
        }
    }
    public Row deleteNum(int nEl){
        Row result = null;
        if (nEl < 0 || nEl > table.size()) {
            throw new ArithmeticException("Invalid nEl");
        } else {
            result = table.get(nEl);
            table.remove(nEl);
        }
        return result;
    }

    private int compareStr (String s1 , String s2 ){
        int n = Math.min(s1.length(), s2.length());

        for (int i = 0; i < n; i++) {
            if (s1.charAt(i) != s2.charAt(i)){
                return s1.charAt(i) - s2.charAt(i);
            }
        }
        return 0;
    }
    public int compareKey(Row row, KeyStruct keyStruct){
        int result = 0;
        if (compareStr(row.getKeyStruct().getKeySeq(), keyStruct.getKeySeq()) > 0) {
            result = 1;
        } else if (compareStr(row.getKeyStruct().getKeySeq(), keyStruct.getKeySeq()) < 0) {
            result = -1;
        } else if (row.getKeyStruct().getnMod() - keyStruct.getnMod() > 0) {
            result = 1;
        } else if (row.getKeyStruct().getnMod() - keyStruct.getnMod() < 0) {
            result = -1;
        }
        return result;
    }

    public Row selectLin(KeyStruct keyStruct){ //��������
        Row result = null;
        for (int i = pointer; i < table.size(); i++){
            if (compareKey(table.get(i) , keyStruct) == 0 ){
                result = table.get(i);
                pointer = i++;
                break;
            }
        }
        if (result == null) {
            System.out.println("Once the element is not found");
            pointer = 0;
        }
        return result;
    }

    public Row selectBin(KeyStruct keyStruct) {
        Row result = null;
        ArrayList<Row> copy = sortedCopy();
        Row[] array = new Row[copy.size()];
        array = copy.toArray(array);

        int index = binarySearch(array, pointer, array.length - 1, keyStruct);
        if (index >= 0) {
            result = array[index];
            pointer = result.getKeyStruct().getnMod();
        } else {
            System.out.println("Once the element is not found");
            pointer = 0;
        }
        return result;
    }
    private int binarySearch(Row[] array, int left, int right, KeyStruct keyStruct) {
        while (true) {
            int middle = (left + right) / 2;
            if (compareKey(array[middle], keyStruct) > 0) {
                right = middle - 1;
            } else if (compareKey(array[middle], keyStruct) < 0) {
                left = middle + 1;
            } else {
                return middle;
            }

            if (left > right) {
                return -1;
            }
        }
    }
    private ArrayList<Row> sortedCopy() {
        ArrayList<Row> result = new ArrayList<>(table.subList(pointer, table.size() - 1));
        for (int i = 0; i < result.size() - 1; i++) {
            for (int j = 0; j < i; j++) {
                if (result.get(j).compareTo(result.get(j + 1)) > 0) {
                    Row temp = result.get(j);
                    result.set(j, result.get(j + 1));
                    result.set(j + 1, temp);
                }
            }
        }
        return result;
    }

    //��������� ��������� ���������� ����, ��������� ����� ����������� i ����'�������� �������,
    // �� ���������� �� ���������� ���������� �� ������� ����.
    public ArrayList<Row> similarRows(Row row) {
        String key = replaceToLatina(row.getKeyStruct().getKeySeq());

        ArrayList<Row> result = new ArrayList<>();
        String tempString;
        int maxSimilarity = 0;

        for (Row tempRow : table) {
            tempString = replaceToLatina(tempRow.getKeyStruct().getKeySeq());
            int minLength = Math.min(tempString.length(), key.length());
            int tempSimilarity = 0;

            for (int i = 0; i < minLength; ) {
                if (key.charAt(i) == tempString.charAt(i)) {
                    tempSimilarity++;
                    i++;
                } else {
                    if (tempSimilarity == maxSimilarity) {
                        result.add(tempRow);
                    } else if (tempSimilarity > maxSimilarity){
                        maxSimilarity = tempSimilarity;
                        result.clear();
                        result.add(tempRow);
                    }
                    break;
                }
            }
        }
        return result;
    }
    private String replaceToLatina(String string) {
        string = string.replaceAll("�", "i");
        string = string.replaceAll("�", "I");
        string = string.replaceAll("�", "e");
        string = string.replaceAll("�", "E");
        string = string.replaceAll("�", "M");
        string = string.replaceAll("�", "H");
        string = string.replaceAll("�", "o");
        string = string.replaceAll("�", "O");
        string = string.replaceAll("�", "P");
        string = string.replaceAll("�", "x");
        string = string.replaceAll("�", "X");
        string = string.replaceAll("�", "T");
        string = string.replaceAll("�", "y");
        string = string.replaceAll("�", "p");
        string = string.replaceAll("�", "a");
        string = string.replaceAll("�", "A");
        string = string.replaceAll("�", "k");
        string = string.replaceAll("�", "K");
        string = string.replaceAll("�", "c");
        string = string.replaceAll("�", "C");
        string = string.replaceAll("�", "B");
        string = string.toLowerCase();
        return string;
    }

    private void printRow(Row row){
        if (row != null){
            System.out.println("Key Struct : 1. keyStr:"+ row.getKeyStruct().getKeySeq() +"; 2.nMod: "+ row.getKeyStruct().getnMod());
            if (row.getFuncStruct().getFunc().getString() != null) {
                System.out.println("Func Struct : func: string: " + row.getFuncStruct().getFunc().getString());
            } else {
                System.out.println("Func Struct : func: integer: " + row.getFuncStruct().getFunc().getInteger());
            }
            System.out.println("Char : "+ row.getCharDel());
        }
    }
    public void print() {
        for (int i = 0; i < table.size(); i++) {
            System.out.println("Row #" + (i+1) + ":");
            printRow(table.get(i));
            System.out.println();
        }
    }

}
