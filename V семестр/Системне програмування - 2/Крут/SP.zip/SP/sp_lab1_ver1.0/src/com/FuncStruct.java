package com;

public class FuncStruct {

    private Union func;

    public FuncStruct(Union func) {
        this.func = func;
    }

    public Union getFunc() {
        return func;
    }
}
