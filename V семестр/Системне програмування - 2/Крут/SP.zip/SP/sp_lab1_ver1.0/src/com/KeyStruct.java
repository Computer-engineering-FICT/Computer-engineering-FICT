package com;

public class KeyStruct {

    private String keySeq;
    private int nMod;

    public KeyStruct(String keySeq, int nMod) {
        this.keySeq = keySeq;
        this.nMod = nMod;
    }

    public String getKeySeq() {
        return keySeq;
    }
    public int getnMod() {
        return nMod;
    }

}
