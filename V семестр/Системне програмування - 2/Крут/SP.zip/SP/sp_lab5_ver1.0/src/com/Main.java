package com;

/**
 * Created by User on 22.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        Analyzer analyzer = new Analyzer();
        Tree tree = analyzer.parse("if a > b then begin c := 5 end else begin begin end ; end ;");

        TreePrinter printer = new TreePrinter();
        printer.print(tree.getRoot());
    }
}
