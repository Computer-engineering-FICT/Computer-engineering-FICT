package com;

/**
 * Created by User on 03.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        Analyzer analyzer = new Analyzer();
        analyzer.analise("b=ca?d:2*a*[m];");
    }
}
