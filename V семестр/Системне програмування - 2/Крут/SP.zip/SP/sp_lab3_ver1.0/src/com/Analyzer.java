package com;

/**
 * Created by User on 03.11.2016.
 */
public class Analyzer {
    private static String[] tokens = new String[]{
           "==", "++", "--", "=", "?", ":", "*", "[", "]", ";", "{", "}", "+", "-", "/", "(", ")", "<", ">"
    };

    public void analise(String input) {
        System.out.println("Input string:  " + input);
        String tokensRegEx = "[(==)=?\\]\\[:*;\\{\\}\\+\\-\\\\(\\+\\+)(\\-\\-)\\(\\)<>]";
        String[] variables = input.split(tokensRegEx);
        for (String string : variables) {
            if (!string.equals("")) {
                try {
                    int value = Integer.parseInt(string);
                    System.out.println("\"" + value + "\" - number");
                } catch (Exception e) {
                    System.out.println("\"" + string + "\" - variable");
                }
            }
        }
        for (String token : tokens) {
            if (input.contains(token)) {
                input = input.replace(token, "");
                System.out.println("\"" + token + "\" - token");
            }
        }
    }
}