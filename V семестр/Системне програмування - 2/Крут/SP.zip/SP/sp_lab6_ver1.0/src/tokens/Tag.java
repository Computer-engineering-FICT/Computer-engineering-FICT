package tokens;

public enum Tag {
	NULL, ERROR,
	ASSIGN, TYPE,
    LBRAC, RBRAC,
	SEMICOLON, COMMA,
    ADD, SUB, MUL,
	QUESTION, COLON,
	VAR, NUM,
}
