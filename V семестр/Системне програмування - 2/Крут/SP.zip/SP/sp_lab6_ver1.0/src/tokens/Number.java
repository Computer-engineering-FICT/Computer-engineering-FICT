package tokens;

public class Number extends Word {
	public final int value;
	
	public Number(int v) {
		super(Integer.toString(v), Tag.NUM);
		value = v;
	}

	@Override
	public String toString() {
		return Integer.toString(value);
	}
}
