import constructions.*;
import tokens.Number;
import tokens.Word;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Interpreter {
    private final Map<String, Object> variables = new HashMap<>();
    private final List<Node> nodes;

    public Interpreter(List<Node> nodes) {
        this.nodes = nodes;
    }

    public void run() {
        for (Node node : nodes) {
            if (node.getClass().equals(Declaration.class)) {
                declaration((Declaration)node);
            } else if (node.getClass().equals(Assignment.class)) {
                assignment((Assignment)node);
            } else if (node.getClass().equals(Ternary.class)) {
                ternary((Ternary)node);
            }
        }
    }

    private void declaration(Declaration declaration) {
        for (Variable variable : declaration.variables) {
            if (variable.getClass().equals(Array.class)) {
                Array array = (Array)variable;
                int size = ((Number)array.size).value;
                if (declaration.type.lexeme.equals("double")) {
                    variables.put(array.word.lexeme, new double[size]);
                } else if (declaration.type.lexeme.equals("float")) {
                    variables.put(array.word.lexeme, new float[size]);
                } else if (declaration.type.lexeme.equals("int")) {
                    variables.put(array.word.lexeme, new int[size]);
                } else if (declaration.type.lexeme.equals("char")) {
                    variables.put(array.word.lexeme, new char[size]);
                } else {
                    error();
                }
            } else {
                if (declaration.type.lexeme.equals("double")) {
                    variables.put(variable.word.lexeme, 0.0);
                } else if (declaration.type.lexeme.equals("float")) {
                    variables.put(variable.word.lexeme, 0.0);
                } else if (declaration.type.lexeme.equals("int")) {
                    variables.put(variable.word.lexeme, 0);
                } else if (declaration.type.lexeme.equals("char")) {
                    variables.put(variable.word.lexeme, '0');
                } else {
                    error();
                }
            }
        }
    }

    private void assignment(Assignment assignment) {
        Object target = variables.get(assignment.variable.word.lexeme);
        if (target == null) {
            error("No such variable declared");
        }
        if (target.getClass().equals(Double.class)) {
            target = expression(assignment.expression);
        } else  if (target.getClass().equals(Float.class)) {
            target = (float)expression(assignment.expression);
        } else  if (target.getClass().equals(Integer.class)) {
            target = (int)expression(assignment.expression);
        } else if (target.getClass().equals(Character.class)) {
            target = (char)expression(assignment.expression);
        } else if (target.getClass().equals(new double[0].getClass())) {
            Array astArray = (Array)assignment.variable;
            int index = (int)variables.get(astArray.size.lexeme);
            ((double[])target)[index] = expression(assignment.expression);
        } else if (target.getClass().equals(new float[0].getClass())) {
            Array astArray = (Array)assignment.variable;
            int index = (int)variables.get(astArray.size.lexeme);
            ((float[])target)[index] = (float) expression(assignment.expression);
        } else if (target.getClass().equals(new int[0].getClass())) {
            Array astArray = (Array)assignment.variable;
            int index = (int)variables.get(astArray.size.lexeme);
            ((int[])target)[index] = (int)expression(assignment.expression);
        } else if (target.getClass().equals(new char[0].getClass())) {
            Array astArray = (Array)assignment.variable;
            int index = (int)variables.get(astArray.size.lexeme);
            ((char[])target)[index] = (char)expression(assignment.expression);
        }
        variables.put(assignment.variable.word.lexeme, target);
    }

    private void ternary(Ternary ternary) {
        Object target = variables.get(ternary.variable.word.lexeme);
        if (target == null) {
            error("No such variable declared");
        }
        Expression assignExpression = null;
        if (expression(ternary.expression) != 0) {
            assignExpression = ternary.leftExpr;
        } else {
            assignExpression = ternary.rightExpr;
        }
        Assignment assignment = new Assignment(ternary.variable, assignExpression);
        assignment(assignment);

    }

    private double expression(Expression expression) {
        double temp = 0.0;

        Word word = expression.variable.word;
        if (word.getClass().equals(Number.class)) {
            temp = ((Number)expression.variable.word).value;
        } else if (expression.variable.getClass().equals(Array.class)) {
            Array astArray = (Array)expression.variable;
            Object variable = variables.get(astArray.word.lexeme);
            if (variable != null) {
                if (variable.getClass().equals(new double[0].getClass())) {
                    if (astArray.size.getClass().equals(Number.class)) {
                        int index = ((Number)astArray.size).value;
                        double[] array = (double[])variable;
                        temp = array[index];
                    } else if (astArray.size.getClass().equals(Word.class)) {
                        int index = (char)(Integer.parseInt(String.valueOf(variables.get(astArray.size.lexeme))));
                        double[] array = (double[])variable;
                        temp = array[index];
                    } else {
                        error();
                    }
                } else if (variable.getClass().equals(new float[0].getClass())) {
                    if (astArray.size.getClass().equals(Number.class)) {
                        int index = ((Number)astArray.size).value;
                        float[] array = (float[])variable;
                        temp = array[index];
                    } else if (astArray.size.getClass().equals(Word.class)) {
                        int index = (int)variables.get(astArray.size.lexeme);
                        float[] array = (float[])variable;
                        temp = array[index];
                    } else {
                        error();
                    }
                } else if (variable.getClass().equals(new int[0].getClass())) {
                    if (astArray.size.getClass().equals(Number.class)) {
                        int index = ((Number)astArray.size).value;
                        int[] array = (int[])variable;
                        temp = array[index];
                    } else if (astArray.size.getClass().equals(Word.class)) {
                        int index = (int)variables.get(astArray.size.lexeme);
                        int[] array = (int[])variable;
                        temp = array[index];
                    } else {
                        error();
                    }
                } else if (variable.getClass().equals(new char[0].getClass())) {
                    if (astArray.size.getClass().equals(Number.class)) {
                        int index = ((Number) astArray.size).value;
                        char[] array = (char[]) variable;
                        temp = array[index];
                    } else if (astArray.size.getClass().equals(Word.class)) {
                        char index = (char)variables.get(astArray.size.lexeme);
                        char[] array = (char[])variable;
                        temp = array[index];
                    } else {
                        error();
                    }
                }
            } else {
                error("No such variable declared");
            }
        } else {
            Object variable = variables.get(expression.variable.word.lexeme);
            if (variable != null) {
                if (variable.getClass().equals(Double.class)) {
                    temp = (Double)variable;
                } else if (variable.getClass().equals(Float.class)) {
                    temp = (Float)variable;
                } else if (variable.getClass().equals(Integer.class)) {
                    temp = (Integer)variable;
                } else if (variable.getClass().equals(Character.class)) {
                    temp = (char)variable;
                }
            } else {
                error("No such variable declared");
            }
        }

        if (expression.operation != null) {
            switch (expression.operation.lexeme) {
                case "+":
                    temp += expression(expression.expression);
                    break;
                case "-":
                    temp -= expression(expression.expression);
                    break;
                case "*":
                    temp *= expression(expression.expression);
                    break;
            }
        }

        return temp;
    }

    public void printVariablesValues() {
        for (Map.Entry<String, Object> entry : variables.entrySet()) {
            if (entry.getValue().getClass().equals(new double[0].getClass())) {
                double[] array = (double[])entry.getValue();
                System.out.printf("%s -> [%s", entry.getKey(), array[0]);
                for (int i = 1; i < array.length; i++) {
                    System.out.printf(", %s", array[i]);
                }
                System.out.printf("]\n");
            } else if (entry.getValue().getClass().equals(new float[0].getClass())) {
                float[] array = (float[])entry.getValue();
                System.out.printf("%s -> [%s", entry.getKey(), array[0]);
                for (int i = 1; i < array.length; i++) {
                    System.out.printf(", %s", array[i]);
                }
                System.out.printf("]\n");
            } else if (entry.getValue().getClass().equals(new int[0].getClass())) {
                int[] array = (int[])entry.getValue();
                System.out.printf("%s -> [%s", entry.getKey(), array[0]);
                for (int i = 1; i < array.length; i++) {
                    System.out.printf(", %s", array[i]);
                }
                System.out.printf("]\n");
            } else if (entry.getValue().getClass().equals(new char[0].getClass())) {
                char[] array = (char[])entry.getValue();
                System.out.printf("%s -> [%s", entry.getKey(), array[0]);
                for (int i = 1; i < array.length; i++) {
                    System.out.printf(", %s", array[i]);
                }
                System.out.printf("]\n");
            } else {
                System.out.printf("%s -> %s\n", entry.getKey(), entry.getValue());
            }
        }
    }

    private void error(String message) {
        throw new Error(message);
    }

    private void error() {
        error("Interpreter error");
    }
}
