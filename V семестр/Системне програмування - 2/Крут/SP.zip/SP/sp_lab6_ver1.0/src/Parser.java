import constructions.*;
import tokens.*;
import java.util.ArrayList;
import java.util.List;

public class Parser {
	private Lexer lex;
	private Token look;
    private List<Node> statements;

	public Parser(Lexer l) {
		lex = l;
        statements = new ArrayList<>();
		move();
	}

	private void move() {
		look = lex.scan();
	}

	private void error() {
		error("syntax error");
	}

	private void error(String message) {
		throw new Error(message);
	}

	private void match(Tag t) {
		if (look.tag != t) {
            error();
        }
		move();
	}

    public List<Node> parse() {
        while (look != Token.NULL) {
            statements.add(stmt());
        }
        return statements;
    }

    private Node stmt() {
        switch (look.tag) {
            case TYPE: {
                Declaration declaration = declaration();
                match(Tag.SEMICOLON);
                return declaration;
            }

            default: {
                Assignment assignment = assignment();
                match(Tag.SEMICOLON);
                return assignment;
            }
        }
    }

    private Declaration declaration() {
        Declaration declaration = new Declaration((Word)look);
        declarationPart(declaration);
        return declaration;
    }

    private void declarationPart(Declaration declaration) {
        move();
        declaration.addVariable(variable());
        if (look.tag == Tag.COMMA) {
            declarationPart(declaration);
        }
    }

    private Assignment assignment() {
        Variable variable = variable();
        match(Tag.ASSIGN);
        Expression expression = expression();

        if (look.tag == Tag.QUESTION) {

            match(Tag.QUESTION);
            Expression left = expression();
            match(Tag.COLON);
            Expression right = expression();
            return new Ternary(variable, expression, left, right);

        } else {
            return new Assignment(variable, expression);
        }
    }

    private Expression expression() {
        Variable variable = variable();
        if (look.tag == Tag.ADD || look.tag == Tag.SUB || look.tag == Tag.MUL) {
            Word operation = (Word)look;
            move();
            return new Expression(variable, operation, expression());
        } else {
            return new Expression(variable);
        }
    }

    private Variable variable() {
		if (look.tag != Tag.VAR && look.tag != Tag.NUM) {
			error();
		}
		Variable variable = null;
		Word word = (Word)look;
        move();
        if (look.tag == Tag.LBRAC) {
            move();
            if (look.tag == Tag.VAR || look.tag == Tag.NUM) {
                Word size = (Word)look;
                variable = new Array(word, size);
                move();
                match(Tag.RBRAC);
            } else {
                error();
            }
        } else {
            variable = new Variable(word);
        }
		return variable;
	}
}
