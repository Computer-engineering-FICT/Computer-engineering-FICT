import tokens.Number;
import tokens.Tag;
import tokens.Token;
import tokens.Word;

import java.util.HashMap;

public class Lexer {
    private static final char EOF = '\0';

    private final HashMap<String, Word> words = new HashMap<>();
    private final String text;

    private char peek;
    private int idx;

    public Lexer(String t) {
        text = t;
        reserveWords();
    }

    private void reserveWords() {
        reserve("double", Tag.TYPE);
        reserve("char", Tag.TYPE);
        reserve("float", Tag.TYPE);
        reserve("int", Tag.TYPE);
    }

    private void reserve(String lexeme, Tag t) {
        words.put(lexeme, new Word(lexeme, t));
    }

    public Token scan() {
        while (Character.isWhitespace(nextch())) readch();
        switch (readch()) {
            case EOF:
                return Token.NULL;
            case '+':
                return Word.add;
            case '-':
                return Word.sub;
            case '*':
                return Word.mul;
            case '[':
                return Word.lbrac;
            case ']':
                return Word.rbrac;
            case ',':
                return Word.comma;
            case ';':
                return Word.semicolon;
            case '=':
                return Word.assign;

            case '?':
                return Word.question;
            case ':':
                return Word.colon;

        }
        if (Character.isDigit(peek)) {
            int n = Character.digit(peek, 10);
            while (Character.isDigit(nextch())) {
                n = n * 10 + Character.digit(readch(), 10);
            }
            return new Number(n);
        }

        if (Character.isLetter(peek)) {
            StringBuilder b = new StringBuilder();
            b.append(peek);
            while (Character.isLetter(nextch())) {
                b.append(readch());
            }
            String s = b.toString();
            Word w = words.get(s);
            if (w != null) {
                return words.get(s);
            }
            w = new Word(s, Tag.VAR);
            words.put(s, w);
            return w;
        }
        return new Word(Character.toString(peek), Tag.ERROR);
    }

    private char readch() {
        peek = nextch();
        idx++;
        return peek;
    }

    private char nextch() {
        if (idx < text.length()) {
            return text.charAt(idx);
        }
        return EOF;
    }
}
