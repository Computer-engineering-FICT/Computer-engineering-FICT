import constructions.Node;

import java.util.List;

/**
 * float b, d, a[5]; int c; b=c?d:2*a[n];
 */
public class Main {
	public static void main(String[] args) {
        String text = "float b, d, a[5]; int c, n; " +
                "n = 0; a[n] = 1;" +
                "n = 1; a[n] = 2;" +
                "n = 2; a[n] = 3;" +
                "n = 3; a[n] = 4;" +
                "n = 4; a[n] = 5;" +
                " d = 3; c = 0; b = c ? b+d:2*a[n];";

        Lexer lexer = new Lexer(text);
        Parser parser = new Parser(lexer);
        List<Node> nodes = parser.parse();

        Interpreter interpreter = new Interpreter(nodes);
        interpreter.run();
        interpreter.printVariablesValues();
    }
}
