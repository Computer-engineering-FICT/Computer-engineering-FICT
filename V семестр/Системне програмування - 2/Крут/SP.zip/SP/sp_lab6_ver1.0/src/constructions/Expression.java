package constructions;

import tokens.Word;

public class Expression implements Node {
    public final Variable variable;
    public final Word operation;
    public final Expression expression;

    public Expression(Variable variable, Word operation, Expression expression) {
        this.variable = variable;
        this.operation = operation;
        this.expression = expression;
    }

    public Expression(Variable variable) {
        this(variable, null, null);
    }
}
