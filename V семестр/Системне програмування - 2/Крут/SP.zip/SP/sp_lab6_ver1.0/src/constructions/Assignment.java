package constructions;

public class Assignment implements Node {
    public final Variable variable;
    public final Expression expression;

    public Assignment(Variable variable, Expression expression) {
        this.variable = variable;
        this.expression = expression;
    }
}
