package constructions;

import tokens.Word;

/**
 * @author Alexander Tchaikovsky
 */
public class Variable implements Node {
    public final Word word;

    public Variable(Word word) {
        this.word = word;
    }
}
