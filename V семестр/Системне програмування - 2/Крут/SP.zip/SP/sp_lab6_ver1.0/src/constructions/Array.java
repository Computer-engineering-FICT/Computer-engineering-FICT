package constructions;

import tokens.Word;

public class Array extends Variable {
    public final Word size;

    public Array(Word word, Word size) {
        super(word);
        this.size = size;
    }
}
