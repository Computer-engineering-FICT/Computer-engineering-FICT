package constructions;

public class Ternary extends Assignment {
    public final Expression leftExpr;
    public final Expression rightExpr;

    public Ternary(Variable variable, Expression check, Expression left, Expression right) {
        super(variable, check);
        this.leftExpr = left;
        this.rightExpr = right;
    }
}
