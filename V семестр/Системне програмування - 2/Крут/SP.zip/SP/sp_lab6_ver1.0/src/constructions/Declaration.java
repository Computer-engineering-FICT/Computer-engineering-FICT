package constructions;

import tokens.Word;

import java.util.ArrayList;
import java.util.List;

public class Declaration implements Node {
    public final Word type;
    public final List<Variable> variables;

    public Declaration(Word type) {
        this.type = type;
        variables = new ArrayList<>();
    }

    public void addVariable(Variable variable) {
        variables.add(variable);
    }
}
