package constructions;

public interface Node {}
