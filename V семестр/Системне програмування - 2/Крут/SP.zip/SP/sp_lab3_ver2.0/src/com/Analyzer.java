package com;

import java.util.ArrayList;

/**
 * Created by User on 17.11.2016.
 */
public class Analyzer {

    private String[] tokens = new String[]{
         "switch", "case", "break", "default", "{", "}", "[", "]", "(", ")", ";", ":", "==", "=", "*",
    };

    public void analyze(String input) {
        String[] elements = input.split(" ");
        ArrayList<String> elementsList = new ArrayList<String>();
        ArrayList<String> tokensList = new ArrayList<String>();

        for (String element : elements) {
            elementsList.add(element);
        }

        for (String token : tokens) {
            tokensList.add(token);
        }

        for (String element : elementsList) {
            if (tokensList.contains(element)) {
                System.out.println(element + " - token");
            } else {
                try {
                    int number = Integer.parseInt(element);
                    System.out.println(number + " - number");
                } catch (Exception e) {
                    System.out.println(element + " - variable");
                }
            }
        }
    }
}
