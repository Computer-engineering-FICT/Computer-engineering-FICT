package com;

/**
 * Created by User on 17.11.2016.
 */
public class Main {
    public static void main(String[] args) {
        Analyzer analyzer = new Analyzer();
        analyzer.analyze("switch ( c ) { case 0 : b = 2 * a [ n ] ; break ; default : b = d ; }");
    }
}
