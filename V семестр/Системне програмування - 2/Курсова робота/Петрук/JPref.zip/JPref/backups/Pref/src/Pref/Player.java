package Pref;

import java.util.ArrayList;

public class Player {

	private ArrayList<Card> cards;
	private String name;
	private int points;
	private String host;

	Player(){
		this.host = host;
	}

	public ArrayList<Card> getCards() {
		return cards;
	}

	public void setCards(ArrayList<Card> cards) {
		this.cards = cards;
	}
}