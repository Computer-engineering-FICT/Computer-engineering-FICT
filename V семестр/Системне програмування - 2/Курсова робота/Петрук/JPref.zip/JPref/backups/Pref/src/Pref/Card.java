package Pref;

import java.awt.Image;

public class Card {
	private int value;
	private int mast;
	private Image image;
	
	Card(int value, int mast, Image image){
		this.value=value;
		this.mast=mast;
		this.image=image;
	}

	public int getValue() {
		return value;
	}

	public int getMast() {
		return mast;
	}

	public Image getImage() {
		return image;
	}

}
