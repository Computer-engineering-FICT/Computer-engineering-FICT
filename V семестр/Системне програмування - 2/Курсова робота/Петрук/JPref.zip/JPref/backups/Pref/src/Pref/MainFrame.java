package Pref;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MainFrame extends JFrame {
	private DrawPanel pan;
	private WorkCard work;
	private final int minheight=400;
	private final int minwidth=800;
	

	MainFrame() {
		setTitle("NetPetri");
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(screenSize.width - 100, (int) (screenSize.height / 1.3));
		setLocation((int) screenSize.width / 12, (int) (screenSize.height / 8));
		Dimension din = new Dimension(minwidth,minheight);
        setMinimumSize(din);
		setLayout(new BorderLayout());

		pan = new DrawPanel();
		add(pan);
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("Menu");
		bar.add(menu);
		JMenuItem item = new JMenuItem("NewGame");
		item.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
                Player player1= new Player();
                Player player2= new Player();
                Player player3= new Player();
                work = new WorkCard(player1,player2,player3,pan);
                pan.setWork(work);
                pan.repaint();
			}
		});
		
		JMenuItem item2 = new JMenuItem("GiveCards");
		item2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				pan.giveCards();
				pan.repaint();	
			}
		});
		
		menu.add(item);
		menu.add(item2);
		setJMenuBar(bar);
	}
}
