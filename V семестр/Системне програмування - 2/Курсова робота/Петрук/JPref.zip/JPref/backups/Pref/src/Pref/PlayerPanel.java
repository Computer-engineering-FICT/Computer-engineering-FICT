package Pref;

import javax.swing.JPanel;

public class PlayerPanel extends JPanel {

}
