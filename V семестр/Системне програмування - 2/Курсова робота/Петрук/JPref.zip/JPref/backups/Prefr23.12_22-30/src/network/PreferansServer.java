package network;

import game.Game;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class PreferansServer {
	private static String serverName = "PreferansServer";

	public static void runPreferansServer(Game newGame) throws RemoteException {
		boolean isPortOccupied = true;
		int currentPort = 2000;
		while (isPortOccupied) {

			Registry registry;
			try {
				registry = LocateRegistry.createRegistry(currentPort);
				isPortOccupied = false;
				registry.rebind(serverName, newGame);
			} catch (RemoteException e) {
				if (currentPort != 2005) {
					currentPort++;
				} else {
					System.out
							.println("The server is overloaded! Please, try again later!");
				}
			}
		}
		System.out.println("Server started on port " + currentPort);
	}
}
