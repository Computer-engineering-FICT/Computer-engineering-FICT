package game;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import network.GameServerInterface;

public class Game extends UnicastRemoteObject implements GameServerInterface {
	private int gameStatus = 0;
	private boolean isOperation = false;
	private int whoGo = 0;
	private WorkCard work;

	/**
	 * Code of operation:_______________________________________________________
	 * 0 - no operation_________________________________________________________
	 * 1 - cards were distributed_______________________________________________
	 * 2 - ������ ��� ����(����� �1)____________________________________________
	 * 3 - ����� �����2_________________________________________________________
	 * 4 - ������� ��������_____________________________________________________
	 * 5 - �������� ���_________________________________________________________
	 * 6 - ����������___________________________________________________________
	 * 7 - ����� ������_________________________________________________________
	 * 8 -
	 */
	private int codeOfOperation = 0;
	private static int id = 0;
	private ArrayList<Player> players = new ArrayList<Player>();
	private int numbOfGamers = 0;

	public Game() throws RemoteException {
	}

	public Game(int stGame) throws RemoteException {
		this.gameStatus = stGame;
	}

	// used
	public void setCodeOfOperation(int codeOfOperation) {
		this.codeOfOperation = codeOfOperation;
	}

	// used
	public int statusGame() {
		return gameStatus;
	}

	// used
	public int registerNewGamer(String nick) throws RemoteException {
		id++;
		Player newPlayer = new Player(id, nick);
		players.add(newPlayer);
		this.numbOfGamers++;
		return id;
	}

	// used
	public void printPlayers() {
		for (int i = 0; i < players.size(); i++) {
			System.out.println((i + 1) + ") ID = " + players.get(i).getId()
					+ " ; nick : " + players.get(i).getNick());
		}
	}

	// used
	public int getNumbOfGamers() {
		return this.numbOfGamers;
	}

	// used
	public void setGameStatus(int gameStatus) {
		this.gameStatus = gameStatus;
	}

	public ArrayList<Player> getPlayers(){
		return players;
	}

	public boolean isOperation() throws RemoteException {
		if (isOperation) {
			return true;
		}
		return false;
	}

	public void setOperation(boolean isOperation) {
		this.isOperation = isOperation;
	}

	// used
	/**
	 * 
	 */
	public int getCode() throws RemoteException {
		return codeOfOperation;
	}

	// ������������, �� �볺�� � ID ������� ��.
	public void setReady(int ID) throws RemoteException {
		for (int i = 0; i < players.size(); i++) {
			if (players.get(i).getId() == ID) {
				players.get(i).setReady(true);
			}
		}
	}

	public WorkCard getWork() throws RemoteException {
		return work;
	}

	public void setWork(WorkCard work) {
		this.work = work;
	}

	public void setWhoGo(int whoGo) {
		System.out.println("������ ������ ������� � ID = "+whoGo);
		this.whoGo = whoGo;
	}

	public int getWhoGo() {
		return whoGo;
	}
	
	public void whoGoNext(){
		this.whoGo++;
		if (whoGo == 2){
			this.whoGo = 0;
		}
	}
}
