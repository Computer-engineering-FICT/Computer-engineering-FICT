package network;

import game.Player;
import game.WorkCard;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface GameServerInterface extends Remote {
	public int statusGame() throws RemoteException;

	public WorkCard getWork() throws RemoteException;

	public int registerNewGamer(String nick) throws RemoteException;

	public boolean isOperation() throws RemoteException;

	public int getCode() throws RemoteException;

	public void setReady(int ID) throws RemoteException;
	
	public int getWhoGo() throws RemoteException;
	
	public void whoGoNext() throws RemoteException;
}
