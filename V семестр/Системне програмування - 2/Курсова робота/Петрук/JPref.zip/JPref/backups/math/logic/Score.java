package logic;

import java.util.ArrayList;

public class Score {
	private int score;
	private int mount;
	private int bull;
	private int lwhists;
	private int rWhists;
	public int getScore() {
		return score;
	}
	public int getMount() {
		return mount;
	}
	public int getBull() {
		return bull;
	}
	public int getLwhists() {
		return lwhists;
	}
	public int getrWhists() {
		return rWhists;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public void setMount(int mount) {
		this.mount = mount;
	}
	public void setBull(int bull) {
		this.bull = bull;
	}
	public void setLwhists(int lwhists) {
		this.lwhists = lwhists;
	}
	public void setrWhists(int rWhists) {
		this.rWhists = rWhists;
	}
	public static double[] getScore(int[]mounts,
					int [] bulls,
					int []leftWhists,
					int[]rightWhists
					){		
		double scores[]=new double [3];
		//int sum =bulls[0]-mounts[0]+bulls[1]-mounts[1]+bulls[2]-mounts[2];
	

int sum=(int)Math.ceil((double)((bulls[0]-mounts[0]+bulls[1]-mounts[1]+bulls[2]-mounts[2])*10)/3);

			scores[0]=  (int)Math.ceil((double)((-sum+10*(bulls[0]-mounts[0])+(leftWhists[0]-rightWhists[1]+rightWhists[0]-leftWhists[2]))));
			scores[1]=  (int)Math.ceil((double)(-sum+10*(bulls[1]-mounts[1])+(leftWhists[1]-rightWhists[2]+rightWhists[1]-leftWhists[0])));	
			scores[2]=  (int)Math.ceil((double)(-sum+10*(bulls[2]-mounts[2])+(leftWhists[2]-rightWhists[0]+rightWhists[2]-leftWhists[1])));
			
		return scores; 
	}
	
	public recordScore (eGameBid aGamerType, eGameBid aMyType,int nGamerVz, int nMyVz, int nGamer,int myNumber,int nqVist)
			{
			  int nGamePrice = gamePoolPrice(aGamerType); 
			  int nGameCard = gameTricks(aGamerType); 
			  int nVistCard = gameWhists(aGamerType); 
			  int score = 0, pnCurrent = 0;
			  

			  if (gameType >= g61 && gameMyType != g86) {
			   
			    if (nGamerVz >= nGameCard) {
			      
			      return poolAdd(nGamePrice);
			    } else {
			     
			      pnCurrent = mMountain[mMountain.size()-1];
			      score = nGamePrice*(nGameCard-nMyVz)+pnCurrent;
			      if (score) mMountain << score;
			    }
			    return 0;
			  }

			  //-------------------------------------------------------------------------
			  if (aMyType == g86) {
			    if (nMyVz) {
			      mountainUp(nGamePrice*nMyVz);
			      return 0;
			    }
			    return poolAdd(10);
			  }

			  //-------------------------------------------------------------------------
			  if (aMyType == raspass)  {
			    pnCurrent = mMountain[mMountain.size()-1];
			    score = nGamePrice*(nMyVz)+pnCurrent;
			    if (nMyVz && score) {
			      mMountain << score;
			      return 0;
			    }
			    if (!nMyVz) return poolAdd(1);
			  }

			  dList = ((myNumber%3)+1 == nGamer) ? &mLeftWhists : &mRightWhists;
			  pnCurrent = dList->at(dList->size()-1);

			  //-------------------------------------------------------------------------
			  if (aMyType == gtPass && aGamerType != g86) {
			    if (!optWhistGreedy && nGameCard-nGamerVz > 0) {
			      // ������������� ��� ���(�)
			      score = nGamePrice*((nGameCard-nGamerVz)+nMyVz)+pnCurrent;
			    }
			    if (score) dList->append(score);
			  }

			  if (aMyType == halfwhist && aGamerType != g86) {
				  score = nGamePrice*nMyVz+pnCurrent;
				  if (score) dList->append(score);
			  }

			  //-------------------------------------------------------------------------
			  if (aMyType == whist && aGamerType != g86)  {
			    if (nGameCard-nGamerVz > 0) {
			      
			      if (nqVist == 2) {
			       
			        score = nGamePrice*((nGameCard-nGamerVz)+nMyVz)+pnCurrent;
			      } else {
			      
			        score = nGamePrice*((nGameCard-nGamerVz)+nMyVz)+pnCurrent;
			      }
			    } else {
			      
			      if (nqVist == 2) {
			        score = nGamePrice*(nMyVz)+pnCurrent;
			      } else {
			        score = nGamePrice*(10-nGamerVz)+pnCurrent;
			      }
			    
			      if (nVistCard > 10-nGamerVz) {
			        if (nqVist == 2) {
			         
			          double d = nVistCard;
			          d = (d/2-nMyVz)*nGamePrice;
			          mountainUp((int)d);
			        } else {
			         
			          if (nVistCard-nMyVz > 0) mountainUp(nGamePrice*(nVistCard-(10-nGamerVz)));
			        }
			      }
			    }
			    if (score) dList->append(score);
			  }
			  return 0;
			}
	
}
