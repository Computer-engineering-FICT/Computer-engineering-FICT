package logic;

public class Bullet {

}
