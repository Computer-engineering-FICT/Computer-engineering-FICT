package logic;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] mounts={0,0,0};
		int bulls[]={10,0,0};
		int leftWhists[]={0,0,0};
		int rightWhists[]={0,0,0};
		for (int i=0; i<mounts.length;i++){
		System.out.println(Score.getScore(mounts, bulls, leftWhists, rightWhists)[i]);
		System.out.println();
	}
	}	

}
