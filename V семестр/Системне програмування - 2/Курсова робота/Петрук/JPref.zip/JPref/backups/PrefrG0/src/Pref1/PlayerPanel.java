package Pref1;

import javax.swing.JPanel;

public class PlayerPanel extends JPanel {

}
