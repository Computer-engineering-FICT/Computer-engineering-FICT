package Pref1;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class TrickDialog extends JDialog {

	private final int HORIZONTAL = 5;
	private final int VERTICAL = 5;
	private JPanel centerPanel;
	private JPanel southPanel;
	private int rule;

	TrickDialog(final MainFrame owner) {
		super(owner, "Trick", true);
		centerPanel = new JPanel();
		setLayout(new BorderLayout());
		add(centerPanel, BorderLayout.NORTH);
		centerPanel.setLayout(new GridLayout(HORIZONTAL, VERTICAL));
		for (int i = 0; i < HORIZONTAL; i++) {
			for (int j = 0; j < VERTICAL; j++) {
				TButton but = new TButton(new ImageIcon("smallcards//"+i+j+".png"));
				but.setTrick(i * 10 + j);
				centerPanel.add(but);
				but.addActionListener(new ButtonAction(i*10+j));
			}
		}
	
		southPanel = new JPanel();
		southPanel.setLayout(new GridLayout(1, 2));
		JButton button1 = new JButton("PASS");
		southPanel.add(button1);
		JButton button2 = new JButton("XZXZXZ");
		southPanel.add(button2);
		add(southPanel);
		pack();
	}

	public int Getrule() {
		return rule;
	}

	public class ButtonAction extends AbstractAction {
		private int trick;

		ButtonAction(int trick) {
			this.trick = trick;
		}

		public void actionPerformed(ActionEvent arg0) {
			rule=trick;
			setVisible(false);
		}
	}
}