package Pref1;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import Pref1.GameServerInterface;

public class PreferansClient {
	private static String serverName = "PreferansServer";

	public static GameServerInterface connectToServer(String nick,
			String serverHost) throws MalformedURLException, NotBoundException {
		GameServerInterface prefServer = null;
		int currentPort = 2000;
		System.out.print("Waiting connection...");
		for (int i = currentPort; i <= 2005; i++) {
			String port = Integer.toString(currentPort);
			String lookupString = "//" + serverHost + ":" + port + "/"
					+ serverName;
			try {
				prefServer = (GameServerInterface) Naming.lookup(lookupString);
				System.out.println("connection established");
				break;
			} catch (RemoteException e) {
				currentPort++;
			}
		}
		if (currentPort == 2006) {
			System.out
					.println("No game servers! Please, create your one server!");
		}
		return prefServer;
	}

}
