package Pref1;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class WorkCard {
	private final int value = 9;
	private final int mast = 5;
	private final int cardsNum = 10;
	private ArrayList<Card> cards;
	private Player player1;
	private Player player2;
	private Player player3;
	private DrawPanel panel;

	WorkCard(Player player1,Player player2,Player player3,DrawPanel panel){
		this.player1=player1;
		this.player2=player2;
		this.player3=player3;
		this.panel=panel;
	}
	
	public ArrayList<Card> generatecards() throws IOException {
		cards = new ArrayList<Card>();
		for (int i = 1; i < mast; i++) {
			for (int j = 1; j < value; j++) {
				cards.add(new Card(j, i, ImageIO.read(new File("cards//" + i
						+ j + ".png"))));
			}
		}
		return cards;
	}

	public void razdacha() {
		ArrayList<Card> cards2= (ArrayList<Card>) cards.clone();
		int numcard=0;
		ArrayList<Card> playercards1 = new ArrayList<Card>();
		ArrayList<Card> playercards2 = new ArrayList<Card>();
		ArrayList<Card> playercards3 = new ArrayList<Card>();
		int cardsnumber = cards.size();
		for (int i = 0; i < cardsNum; i++) {
			numcard=(int) (Math.random() * cardsnumber);
			playercards1.add(cards2.get(numcard));
			cards2.remove(numcard);
			cardsnumber--;
			numcard=(int) (Math.random() * cardsnumber);
			playercards2.add(cards2.get(numcard));
			cards2.remove(numcard);
			cardsnumber--;
			numcard=(int) (Math.random() * cardsnumber);
			playercards3.add(cards2.get((int) numcard));
			cards2.remove(numcard);
			cardsnumber--;
		}
		player1.setCards(playercards1);
		player2.setCards(playercards2);
		player3.setCards(playercards3);
		panel.repaint();
	}

	public Player getPlayer1() {
		return player1;
	}

	public Player getPlayer2() {
		return player2;
	}

	public Player getPlayer3() {
		return player3;
	}
	
}
