package view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class DialogClient extends JDialog {
	public DialogClient(final MainFrame owner) {

		super(owner, "Client", true);
		setBounds(400, 400, 350, 120);
		JLabel lab1 = new JLabel("ClientIp        ");
		JLabel lab2 = new JLabel("ClientName");
		textIp = new JTextField(20);
		textIp.setText("192.168.1.120");
		textName = new JTextField(20);
		JButton ok = new JButton("OK");
		setResizable(false);

		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				setVisible(false);
				ok1 = true;
				nameIp = textIp.getText();
				playerName = textName.getText();
			}
		});
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				setVisible(false);
			}
		});
		JPanel panel = new JPanel();
		JPanel tool = new JPanel();
		panel.add(lab1);
		panel.add(textIp);
		panel.add(lab2);
		panel.add(textName);
		tool.add(ok);
		tool.add(cancel);
		add(panel, BorderLayout.CENTER);
		add(tool, BorderLayout.SOUTH);
	}

	private JTextField textIp;
	private JTextField textName;
	private boolean ok1;
	private String nameIp;
	private String playerName;

	public boolean getOk() {
		return ok1;
	}

	public String getPlayerName() {
		return playerName;
	}

	public String getNameIp() {
		return nameIp;
	}

	public void setOK() {
		ok1 = false;
	}
}
