package Pref1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class DrawPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private Image image;
	private ArrayList<Card> cards = new ArrayList<Card>();
	private WorkCard work;
	private Player player1;
	private Player player2;
	private Player player3;
	private int cardswidth = 0;
	private int cardsheight = 0;
	private boolean showcards = false;
	private int panelwidth;
	private int panelheight;

	DrawPanel() {
		setLayout(null);
		setBackground(Color.green);
		try {
			image = ImageIO.read(new File("cards//b1fv.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		cardswidth = image.getWidth(this);
		cardsheight = image.getHeight(this);
	}

	protected void paintComponent(Graphics g) {
		panelwidth = getWidth();
		panelheight = getHeight();
		super.paintComponent(g);
		if (work != null) {

			drawPlayer1(g);
			drawPlayer2(g);
			drawPlayer3(g);
		}
	}

	private void drawPlayer1(Graphics g) {
		for (int i = 0; i < player1.getCards().size(); i++) {
			g.drawImage(player1.getCards().get(i).chooseImage(true),
					(int) (panelwidth / 3 + (cardswidth * i) / 3),
					(int) (panelheight * 3 / 4), null);
		}
	}

	private void drawPlayer2(Graphics g) {
		for (int i = 0; i < player2.getCards().size(); i++) {
			g.drawImage(player2.getCards().get(i).chooseImage(false),
					(int) (panelwidth / 20 + (cardswidth * i) / 3),
					(int) (panelheight * 1 / 12), null);
		}
	}

	private void drawPlayer3(Graphics g) {
		for (int i = 0; i < player3.getCards().size(); i++) {
			g.drawImage(player3.getCards().get(i).chooseImage(false),
					(int) (panelwidth / 1.5 + (cardswidth * i) / 3),
					(int) (panelheight * 1 / 12), null);
		}
	}

	public void setWork(WorkCard work) {
		this.work = work;
		try {
			cards = work.generatecards();
		} catch (IOException e) {
			e.printStackTrace();
		}
		player1 = work.getPlayer1();
		player2 = work.getPlayer2();
		player3 = work.getPlayer3();
	}

	public void setPlayers(WorkCard work) {
		this.work = work;
		player1 = work.getPlayer1();
		player2 = work.getPlayer2();
		player3 = work.getPlayer3();
	}

	public void giveCards() {
		work.razdacha();
		repaint();
		showcards = true;
	}

}
