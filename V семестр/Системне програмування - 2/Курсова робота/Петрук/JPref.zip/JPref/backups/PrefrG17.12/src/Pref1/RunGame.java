package Pref1;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;

public class RunGame {
	private static Game newGame;
	GameServerInterface gameInterface;
	private String serverNick = "AdminKo";
	private DrawPanel pan;
	private static int myId;

	public void startServerGame(DrawPanel pan) {
		this.pan = pan;
		System.out.println("startServerGame");
		try {
			newGame = new Game(0);
			PreferansServer.runPreferansServer(newGame);
			myId = newGame.registerNewGamer(serverNick);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		int nubmOfGamers0 = 0;
		while (nubmOfGamers0 < 3) {
			if (nubmOfGamers0 != newGame.getNumbOfGamers()) {
				nubmOfGamers0 = newGame.getNumbOfGamers();
				newGame.printPlayers();
			}
		}
		newGame.setGameStatus(1);
		runServerGame();
	}

	public void startClientGame(String nick, String host, DrawPanel pan) {
		this.pan = pan;
		try {
			gameInterface = PreferansClient.connectToServer(nick, host);
			try {
				int gameStatus = gameInterface.statusGame();
				if (gameStatus == 1) {
					System.out
							.println("Game started!Please, choose another server.");
				}
				if (gameStatus == 0) {
					System.out.println("Waiting start...");
					myId = gameInterface.registerNewGamer(nick);
					while (gameStatus != 1) {
						gameStatus = gameInterface.statusGame();
					}
					// while (gameInterface.isOperation()){
					// System.out.println("h4wstttttTTT");
					// }
					// System.out.println("Game status" + gameStatus);
					runClientGame();
				}

			} catch (RemoteException e) {
				e.printStackTrace();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			e.printStackTrace();
		}

	}

	private void runClientGame() {
		System.out.println("startGameClient");

		try {
			boolean flag = gameInterface.isGiven();
			while(!flag){
				flag = gameInterface.isGiven();
			}
//			while (!gameInterface.isOperation()) {
//				System.out.println("h4wstttttTTT");
//			}
			// if (gameInterface.isOperation()) {
//			int code = gameInterface.getCode();
//			System.out.println("code = " + code);
//			switch (code) {
//			case 1:
				// �볺��.��� �������� ������ ������� � ������� �� �����
				ArrayList<Player> players = gameInterface.getPlayers();
				System.out.println("Players on this game:");
				for (int i = 0; i < players.size(); i++) {
					System.out.print("player[ " + i + " ].nick = "
							+ players.get(i).getNick()+" ; kkk = "+ players.get(i).getCards().get(5).getValue());
					if (players.get(i).getId() == myId) {
						System.out.println(" (YOU)");
					} else {
						System.out.println();
					}
				}
				// //////
				System.out.println("I....");
				WorkCard work = gameInterface.getWork();
				System.out.println("WC = " + work);
				System.out.println("I am here!");
				pan.setPlayers(work);
				pan.repaint();
				// pan.giveCards();
				// pan.repaint();
				// //////
				// ����������, �� � ������� �����.
				gameInterface.setReady(myId);
//				break;
//			case 2:
//			}

			// }
		} catch (RemoteException e) {
			System.out.println("startGameClient. exception");
			e.printStackTrace();
		}
	}

	private void runServerGame() {
		System.out.println("Game started!");

		System.out.println("��� ��������� ����� :p ");
		newGame.setCodeOfOperation(1);
		newGame.setOperation(true);
		giveCards();
		// newGame.setCodeOfOperation(1);
		// newGame.setOperation(true);
	}

	public void giveCards() {
		try {
			// ������ ����� �����
			WorkCard work = new WorkCard(newGame.getPlayers().get(0), newGame
					.getPlayers().get(1), newGame.getPlayers().get(2));
			pan.setWork(work);
			pan.repaint();
			pan.giveCards();
			pan.repaint();
			// ������������ �� ������� ����� �������
			newGame.setReady(myId);
			// newGame.setCodeOfOperation(1);
			// newGame.setOperation(true);
			isClientsReady();
			System.out.println("All clients ready. Next operation");
			// �� �볺��� �������� ��. ��������� �� ���� ��������� 䳿
			resetPlayersIsReady();
			System.out.println("All clients reseted.Next operation");

		} catch (RemoteException e) {
			e.printStackTrace();

		}

	}

	private void isClientsReady() throws RemoteException {
		boolean isClientReady = true;
		while (!isClientReady) {
			for (int i = 0; i < newGame.getPlayers().size(); i++) {
				if (!newGame.getPlayers().get(i).isReady()) {
					isClientReady = false;
				}
			}
		}
	}

	private void resetPlayersIsReady() throws RemoteException {
		for (int i = 0; i < newGame.getPlayers().size(); i++) {
			newGame.getPlayers().get(i).setReady(false);
		}
	}
}
