package Pref1;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

public class Card implements Serializable{
	private int value;
	private int mast;
//	private Image image;
//	private Image scirt;
	
	Card(int value, int mast){
		this.value=value;
		this.mast=mast;
//		this.image=image;
//		try {
//			scirt = ImageIO.read(new File("cards//b1fv.png"));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}

	public int getValue() {
		return value;
	}

	public int getMast() {
		return mast;
	}

//	public Image getImage() {
//		return image;
//	}
//	
//	public Image chooseImage(boolean flag){
//		if(flag){
//			return image;
//		}
//		else{
//			return scirt;
//		}
//	}

}
