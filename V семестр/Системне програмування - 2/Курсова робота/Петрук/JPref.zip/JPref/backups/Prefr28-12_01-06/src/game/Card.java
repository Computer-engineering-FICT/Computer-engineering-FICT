package game;

import java.io.Serializable;


public class Card implements Serializable {
	private int value;
	private int mast;
	private int ownerId;
	/**
	 * �������� �����
	 */
	private boolean trump;

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	private String nameFile;

	Card(int value, int mast, String nameFile) {
		this.value = value;
		this.mast = mast;
		this.nameFile = nameFile;
	}

	public int getValue() {
		return value;
	}

	public int getMast() {
		return mast;
	}

	public String getNameFile() {
		return nameFile;
	}

	public void setNameFile(String nameFile) {
		this.nameFile = nameFile;
	}

	public boolean isTrump() {
		return trump;
	}

	public void setTrump(boolean trump) {
		this.trump = trump;
	}

}
