package view;

import game.Game;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Threads.WaitThread;

public class WaitingDialog extends JDialog {
	private JLabel label;
	private Game newGame;
	private JButton but;
	private JPanel pan;
	private JButton cancel;
	private JPanel buttonPanel;
	private JPanel labelPanel;
	private JDialog dialog;
	private boolean flag=true;
	private final int BUTTTONWIDTH = 60;
	private final int BUTTONHEIGHT = 40;

	public WaitingDialog(final MainFrame frame, Game game) {
		super(frame, "Client", true);
		dialog = this;
		newGame = game;
		setLocation(frame.getX() + frame.getWidth() / 2,
				frame.getY() + frame.getHeight() / 2);
		pan = new JPanel();
		pan.setLayout(new BorderLayout());
		label = new JLabel("Do you want to create a new game?");
		but = new JButton("StartGame");
		cancel = new JButton("Cancel");
		but.setSize(BUTTTONWIDTH, BUTTONHEIGHT);
		cancel.setSize(BUTTTONWIDTH, BUTTONHEIGHT);
		buttonPanel = new JPanel();
		labelPanel = new JPanel();
		buttonPanel.add(but);
		buttonPanel.add(cancel);
		labelPanel.add(label);
		but.addActionListener(new ButtonAction());
		cancel.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				setFlag(false);
				setVisible(false);
			}
		});

		pan.add(labelPanel, BorderLayout.SOUTH);
		pan.add(buttonPanel, BorderLayout.NORTH);
		add(pan);
		pack();
	}

	public class ButtonAction extends AbstractAction {
		public void actionPerformed(ActionEvent arg0) {
			Runnable waitT = new WaitThread(newGame, dialog);
			Thread thread = new Thread(waitT);
			thread.start();
			label.setText("Waiting for Clients ");
			but.setEnabled(false);
		}
	}

	public Game getnewGame() {
		return newGame;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public boolean isFlag() {
		return flag;
	}
}