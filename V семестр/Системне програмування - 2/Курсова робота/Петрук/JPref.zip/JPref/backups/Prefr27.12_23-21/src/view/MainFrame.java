package view;

import game.RunGame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MainFrame extends JFrame {
	private static DrawPanel pan;
	private final int MINHEIGHT = 400;
	private final int MINWIDTH = 800;
	private DialogClient dialog;
	private TrickDialog trickdialog;
	private RunGame runGame = new RunGame();
	private MainFrame frame;

	public MainFrame() {
		setTitle("Pref");
		this.frame = this;
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(screenSize.width - 100, (int) (screenSize.height / 1.3));
		setLocation((int) screenSize.width / 12, (int) (screenSize.height / 8));
		Dimension din = new Dimension(MINWIDTH, MINHEIGHT);
		setMinimumSize(din);
		setLayout(new BorderLayout());

		pan = new DrawPanel();
		add(pan);
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("Menu");
		bar.add(menu);

		JMenuItem item6 = new JMenuItem("Test");
		item6.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				trickdialog = new TrickDialog(MainFrame.this);
				trickdialog.setVisible(true);
				System.out.println(trickdialog.Getrule());
			}
		});
		JMenuItem item3 = new JMenuItem("Create Server");
		item3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				runGame.startServerGame(pan, frame);
			}
		});

		JMenuItem item4 = new JMenuItem("Connect");
		item4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dialog = new DialogClient(MainFrame.this);
				dialog.setVisible(true);
				if(dialog.getOk())
				runGame.startClientGame(dialog.getPlayerName(),
						dialog.getNameIp(), pan);
			}
		});
		menu.add(item3);
		menu.add(item4);
		menu.add(item6);
		setJMenuBar(bar);
	}

}
