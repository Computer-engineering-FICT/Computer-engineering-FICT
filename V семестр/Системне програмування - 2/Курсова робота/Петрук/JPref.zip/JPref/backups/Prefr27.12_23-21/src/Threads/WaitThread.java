package Threads;

import javax.swing.JDialog;

import game.Game;

public class WaitThread implements Runnable {
	private Game newGame;
	private JDialog dialog;

	public WaitThread(Game newGame, JDialog dialog) {
		this.newGame = newGame;
		this.dialog = dialog;
	}

	public void run() {
//		dialog.setVisible(false);
		int nubmOfGamers0 = 0;
		while (nubmOfGamers0 < 3) {
//			System.out.println("dddd");
			if (nubmOfGamers0 != newGame.getNumbOfGamers()) {
//				System.out.println("dfdf");
				nubmOfGamers0 = newGame.getNumbOfGamers();
				newGame.printPlayers();
			}
		}
		 dialog.setVisible(false);
	}
}
