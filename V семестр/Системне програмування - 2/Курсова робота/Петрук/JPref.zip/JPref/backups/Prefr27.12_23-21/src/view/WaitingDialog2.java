package view;

import game.Game;

import javax.swing.JDialog;

public class WaitingDialog2 extends JDialog {



	public WaitingDialog2(MainFrame dialog, Game newGame) {
		setBounds(50,50,50,50);
	}

}