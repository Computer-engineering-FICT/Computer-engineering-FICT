package view;

import game.Card;
import game.Player;
import game.WorkCard;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DrawPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private Image image;
	private int index;
	private ArrayList<Card> cards = new ArrayList<Card>();
	private WorkCard work;
	private Player[] player = new Player[3];
	private int cardswidth = 0;
	private int cardsheight = 0;
	private boolean showcards = false;
	private int panelwidth;
	private int panelheight;
	private int id = 0;
	private Player currentPlayer;
	private ArrayList<Rectangle2D> cardRect;
	private ArrayList<Card> centerCards = new ArrayList<Card>();;
	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private Card current;
	private Point2D point;
	private Graphics g;

	DrawPanel() {
		setLayout(null);
		setBackground(Color.green);
		try {
			image = ImageIO.read(new File("cards//b1fv.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		cardswidth = image.getWidth(this);
		cardsheight = image.getHeight(this);
		addMouseListener(new MouseHandler());
		cardRect = new ArrayList<Rectangle2D>();
	}

	protected void paintComponent(Graphics g) {

		this.g = g;
		cardRect.removeAll(cardRect);
		panelwidth = getWidth();
		panelheight = getHeight();
		super.paintComponent(g);
		// drawher();
		if (work != null) {
			switch (id) {
			case 0:
				drawPlayer(g, player[0], player[1], player[2]);
				break;
			case 1:
				drawPlayer(g, player[1], player[2], player[0]);
				break;
			case 2:
				drawPlayer(g, player[2], player[0], player[1]);
				break;
			}
		}
	}

	private void drawPlayer(Graphics g, Player drawPlayer0, Player drawPlayer1,
			Player drawPlayer2) {

		for (int i = 0; i < centerCards.size(); i++) {
			try {
				g.drawImage(ImageIO.read(new File(centerCards.get(i)
						.getNameFile())), (int) (panelwidth / 2),
						(int) (panelheight / 2), null);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		for (int i = 0; i < drawPlayer0.getCards().size(); i++) {
			g.setColor(Color.RED);
			try {
				g.drawImage(
						ImageIO.read(new File(drawPlayer0.getCards().get(i)
								.getNameFile())),
						(int) (panelwidth / 3 + (cardswidth * i) / 3),
						(int) (panelheight * 3 / 4), null);
			} catch (IOException e) {
				e.printStackTrace();
			}
			Rectangle2D rect = new Rectangle2D.Double(
					(int) (panelwidth / 3 + (cardswidth * i) / 3),
					(int) (panelheight * 3 / 4), cardswidth, cardsheight);
			cardRect.add(rect);
			g.setColor(Color.BLACK);
			g.drawString(drawPlayer0.getNick(), panelwidth / 2,
					panelheight * 3 / 4 - 50);
		}
		for (int i = 0; i < drawPlayer1.getCards().size(); i++) {
			g.drawImage(image, (int) (panelwidth / 20 + (cardswidth * i) / 3),
					(int) (panelheight * 1 / 12), null);
			g.drawString(drawPlayer1.getNick(), panelwidth / 15, panelheight
					* 1 / 12 + cardsheight + 20);
		}

		for (int i = 0; i < drawPlayer2.getCards().size(); i++) {

			g.drawImage(image, (int) (panelwidth / 1.5 + (cardswidth * i) / 3),
					(int) (panelheight * 1 / 12), null);
			g.drawString(drawPlayer2.getNick(), (int) (panelwidth / 1.5 + 50),
					panelheight * 1 / 12 + cardsheight + 20);
		}
	}

	public void setWork(WorkCard work) {
		this.work = work;
		cards = work.generatecards();
		player[0] = work.getPlayer(0);
		player[1] = work.getPlayer(1);
		player[2] = work.getPlayer(2);
		setCurrentPlayer(id);
	}

	private void setCurrentPlayer(int id) {
		switch (id) {
		case 1:
			currentPlayer = player[0];
			break;
		case 2:
			currentPlayer = player[1];
			break;
		case 3:
			currentPlayer = player[2];
			break;
		}
	}

	// private void drawher() {
	// g.draw3DRect(panelwidth / 2 - cardsheight / 2, panelheight / 2
	// - cardsheight / 3, cardswidth, cardsheight, true);
	//
	// g.draw3DRect(panelwidth / 2 - cardsheight * 4 / 3, panelheight / 2
	// - cardsheight * 5 / 6, cardswidth, cardsheight, true);// left
	//
	// g.draw3DRect(panelwidth / 2 + cardsheight / 3, panelheight / 2
	// - cardsheight * 5 / 6, cardswidth, cardsheight, true);// right
	// }

	public void centerCards(Card[] cards) {
		int size = cards.length;
		try {
			switch (id) {
			case 0:
				for (int i = 0; i < size; i++) {
					switch (cards[i].getOwnerId()) {
					case 0:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 - cardsheight / 2, panelheight
										/ 2 - cardsheight / 3, null);// center
					case 1:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 - cardsheight * 4 / 3,
								panelheight / 2 - cardsheight * 5 / 6, null);// left
					case 2:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 + cardsheight / 3, panelheight
										/ 2 - cardsheight * 5 / 6, null);// right
					}
				}
				break;
			case 1:
				for (int i = 0; i < size; i++) {
					switch (cards[i].getOwnerId()) {
					case 0:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 + cardsheight / 3, panelheight
										/ 2 - cardsheight * 5 / 6, null);// right
					case 1:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 - cardsheight / 2, panelheight
										/ 2 - cardsheight / 3, null);// centr
					case 2:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 - cardsheight * 4 / 3,
								panelheight / 2 - cardsheight * 5 / 6, null);// left
					}
				}
				break;
			case 2:
				for (int i = 0; i < size; i++) {
					switch (cards[i].getOwnerId()) {
					case 0:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 - cardsheight * 4 / 3,
								panelheight / 2 - cardsheight * 5 / 6, null);// left
					case 1:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 + cardsheight / 3, panelheight
										/ 2 - cardsheight * 5 / 6, null);// right
					case 2:
						g.drawImage(
								ImageIO.read(new File(cards[i].getNameFile())),
								panelwidth / 2 - cardsheight / 2, panelheight
										/ 2 - cardsheight / 3, null);// centr
					}
				}
				break;
			}
		} catch (IOException exp) {
			exp.printStackTrace();
		}
	}

	private void withoutname() {

	}

	public void setPlayers(WorkCard work) {
		this.work = work;
		player[0] = work.getPlayer(0);
		player[1] = work.getPlayer(1);
		player[2] = work.getPlayer(2);
		setCurrentPlayer(id);
		repaint();
	}

	public void giveCards() {
		work.razdacha();
		repaint();
		showcards = true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private class MouseHandler extends MouseAdapter {

		public void mouseReleased(MouseEvent event) {

		}

		public void mousePressed(MouseEvent event) {
			point = event.getPoint();
			for (int i = 0; i < cardRect.size(); i++) {
				if (cardRect.get(i).contains(point)) {
					switch (id) {
					case 0:
						current = player[0].getCards().get(i);
						break;
					case 1:
						current = player[1].getCards().get(i);
						break;
					case 2:
						current = player[2].getCards().get(i);
						break;
					}
					index = i;
				}
			}
		}

		public void mouseClicked(MouseEvent event) {
			int click = event.getClickCount();
			if (current != null && click >= 2) {
				centerCards.add(current);
				switch (id) {
				case 0:
					player[0].getCards().remove(index);
					break;
				case 1:
					player[1].getCards().remove(index);
					break;
				case 2:
					player[2].getCards().remove(index);
					break;
				}

				current = null;
				repaint();
			}
		}
	}
}