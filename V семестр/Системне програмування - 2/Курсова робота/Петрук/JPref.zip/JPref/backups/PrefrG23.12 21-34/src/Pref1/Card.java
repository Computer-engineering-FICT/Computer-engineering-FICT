package Pref1;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

public class Card implements Serializable{
	private int value;
	private int mast;
	private String nameFile;
	
	Card(int value, int mast,String nameFile){
		this.value=value;
		this.mast=mast;
		this.nameFile=nameFile;
	}

	public int getValue() {
		return value;
	}

	public int getMast() {
		return mast;
	}

	public String getNameFile() {
		return nameFile;
	}

	public void setNameFile(String nameFile) {
		this.nameFile = nameFile;
	}
}
