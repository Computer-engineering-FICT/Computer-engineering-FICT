package Pref1;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Game extends UnicastRemoteObject implements GameServerInterface {
	private int gameStatus = 0;
	private boolean isOperation = false;
	private int whoGo;
	private WorkCard work;
	
	/**
	 * Code of operation:
	 * 0 - no operation
	 * 1 - cards were distributed 
	 * 		(����� ���� �������)
	 * 2 - 
	 */
	private int codeOfOperation = 0;
	private static int id = 0;
	private ArrayList<Player> players = new ArrayList<Player>();
	private int numbOfGamers = 0;

	public Game() throws RemoteException {
	}

	public Game(int stGame) throws RemoteException {
		this.gameStatus = stGame;
	}
	//used
	public void setCodeOfOperation(int codeOfOperation) {
		this.codeOfOperation = codeOfOperation;
	}
	//used
	public int statusGame() {
		return gameStatus;
	}
	//used
	public int registerNewGamer(String nick) throws RemoteException {
		id++;
		Player newPlayer = new Player(id, nick);
		players.add(newPlayer);
		this.numbOfGamers++;
		return id;// /////++++++++++++++
	}
	//used
	public void printPlayers() {
		for (int i = 0; i < players.size(); i++) {
			System.out.println((i + 1) + ") ID = " + players.get(i).getId()
					+ " ; nick : " + players.get(i).getNick());
		}
	}
	//used
	public int getNumbOfGamers() {
		return this.numbOfGamers;
	}
	//used
	public void setGameStatus(int gameStatus) {
		this.gameStatus = gameStatus;
	}

	public ArrayList<Player> getPlayers() throws RemoteException {
		return players;
	}


	public boolean isOperation() throws RemoteException {
		if (isOperation) {
			return true;
		}
		return false;
	}
	
	public void setOperation(boolean isOperation) {
		this.isOperation = isOperation;
	}

	//used
	/**
	 * 
	 */
	public int getCode() throws RemoteException {
		return codeOfOperation;
	}

	// ������������, �� �볺�� � ID ������� ��.
	public void setReady(int ID) throws RemoteException {
		for (int i=0; i<players.size(); i++){
			if (players.get(i).getId() == ID){
				players.get(i).setReady(true);
			}
		}
		
	}

	public WorkCard getWork() throws RemoteException {
		return work;
	}

	public void setWork(WorkCard work) {
		this.work = work;
	}

	
}
