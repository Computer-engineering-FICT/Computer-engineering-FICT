package Pref1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class DrawPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private Image image;
	private ArrayList<Card> cards = new ArrayList<Card>();
	private WorkCard work;
	private Player player1;
	private Player player2;
	private Player player3;
	private int cardswidth = 0;
	private int cardsheight = 0;
	private boolean showcards = false;
	private int panelwidth;
	private int panelheight;
	private int id = 0;

	DrawPanel() {
		setLayout(null);
		setBackground(Color.green);
		try {
			image = ImageIO.read(new File("cards//b1fv.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		cardswidth = image.getWidth(this);
		cardsheight = image.getHeight(this);
	}

	protected void paintComponent(Graphics g) {
		panelwidth = getWidth();
		panelheight = getHeight();
		super.paintComponent(g);
		if (work != null) {
			switch (id) {
			case 1:
				drawPlayer(g, player1, player2, player3);
				break;
			case 2:
				drawPlayer(g, player2, player3, player1);
				break;
			case 3:
				drawPlayer(g, player3, player1, player2);
				break;
			}
		}
	}

	private void drawPlayer(Graphics g, Player player1, Player player2,
			Player player3) {
		for (int i = 0; i < player1.getCards().size(); i++) {
			Rectangle2D rect = new Rectangle2D.Double(
					(int) (panelwidth / 3 + (cardswidth * i) / 3),
					(int) (panelheight * 3 / 4), cardswidth, cardsheight);
			try {
				g.drawImage(
						ImageIO.read(new File(player1.getCards().get(i)
								.getNameFile())),
						(int) (panelwidth / 3 + (cardswidth * i) / 3),
						(int) (panelheight * 3 / 4), null);
			} catch (IOException e) {
				e.printStackTrace();
			}
			g.drawString(player1.getNick(), panelwidth/2,panelheight * 3 / 4-50);
		}
		for (int i = 0; i < player2.getCards().size(); i++) {
			try {
				g.drawImage(ImageIO.read(new File(player2.getCards().get(i)
						.getNameFile())), (int) (panelwidth / 20 + (cardswidth * i) / 3),
						(int) (panelheight * 1 / 12), null);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			g.drawString(player2.getNick(), panelwidth / 15,panelheight * 1 / 12+cardsheight+20);
			
		}
		for (int i = 0; i < player3.getCards().size(); i++) {
			try {
				g.drawImage(ImageIO.read(new File(player3.getCards().get(i)
						.getNameFile())), (int) (panelwidth / 1.5 + (cardswidth * i) / 3),
						(int) (panelheight * 1 / 12), null);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			g.drawString(player3.getNick(), (int) (panelwidth / 1.5+50),panelheight * 1 / 12+cardsheight+20);
		}
	}

	public void setWork(WorkCard work) {
		this.work = work;
		try {
			cards = work.generatecards();
		} catch (IOException e) {
			e.printStackTrace();
		}
		player1 = work.getPlayer1();
		player2 = work.getPlayer2();
		player3 = work.getPlayer3();
	}

	public void setPlayers(WorkCard work) {
		this.work = work;
		player1 = work.getPlayer1();
		player2 = work.getPlayer2();
		player3 = work.getPlayer3();
		repaint();
	}

	public void giveCards() {
		work.razdacha();
		repaint();
		showcards = true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
