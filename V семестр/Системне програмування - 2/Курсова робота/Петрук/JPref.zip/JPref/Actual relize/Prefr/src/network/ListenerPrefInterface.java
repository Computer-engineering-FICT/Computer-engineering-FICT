package network;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ListenerPrefInterface extends Remote {
	public String isSomeOperation() throws RemoteException;
	public void waitOper(int code) throws RemoteException;

}
