package comparators;

import game.Card;

import java.util.Comparator;

public class MastValueCardComparator implements Comparator<Card> {

	@Override
	public int compare(Card card1, Card card2) {
		
		
		// TODO Auto-generated method stub
		return 0;
	}

	
}
