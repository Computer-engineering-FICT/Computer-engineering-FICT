package view;

import javax.swing.JPanel;

public class PlayerPanel extends JPanel {

}
