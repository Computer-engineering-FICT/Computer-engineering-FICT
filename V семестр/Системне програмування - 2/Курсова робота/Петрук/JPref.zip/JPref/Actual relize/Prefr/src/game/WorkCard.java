package game;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import comparators.MastValueComparator;

public class WorkCard implements Serializable{
	private final int value = 9;
	private final int mast = 5;
	private final int cardsNum = 10;
	private ArrayList<Card> cards;
	//
	private Player[] player = new Player[3];
	//

	WorkCard(Player[] players){
		this.player=players;
	}
	
	public ArrayList<Card> generatecards() {
		cards = new ArrayList<Card>();
		for (int i = 1; i < mast; i++) {
			for (int j = 1; j < value; j++) {
				cards.add(new Card(j, i, "cards//" + i
						+ j + ".png"));
			}
		}
		return cards;
	}

	public void razdacha() {
		ArrayList<Card> cards2= (ArrayList<Card>) cards.clone();
		int numcard=0;
		ArrayList<Card> playercards1 = new ArrayList<Card>();
		ArrayList<Card> playercards2 = new ArrayList<Card>();
		ArrayList<Card> playercards3 = new ArrayList<Card>();
		int cardsnumber = cards.size();
		for (int i = 0; i < cardsNum; i++) {
			numcard=(int) (Math.random() * cardsnumber);
			playercards1.add(cards2.get(numcard));
			cards2.remove(numcard);
			cardsnumber--;
			numcard=(int) (Math.random() * cardsnumber);
			playercards2.add(cards2.get(numcard));
			cards2.remove(numcard);
			cardsnumber--;
			numcard=(int) (Math.random() * cardsnumber);
			playercards3.add(cards2.get((int) numcard));
			cards2.remove(numcard);
			cardsnumber--;
		}
		MastValueComparator c = new MastValueComparator();
		Collections.sort(playercards1, c);
		Collections.sort(playercards2, c);
		Collections.sort(playercards3, c);
		player[0].setCards(playercards1);
		player[1].setCards(playercards2);
		player[2].setCards(playercards3);
	}

	public Player getPlayer(int index) {
		return player[index];
	}
}
