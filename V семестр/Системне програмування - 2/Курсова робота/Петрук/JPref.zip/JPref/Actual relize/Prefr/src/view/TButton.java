package view;

import javax.swing.Icon;
import javax.swing.JButton;

public class TButton extends JButton {
	private int trick;

	TButton(String name){
		super(name);
	}
	
	TButton(Icon icon){
		super(icon);
	}
	public int getTrick() {
		return trick;
	}

	public void setTrick(int trick) {
		this.trick = trick;
	}

}
