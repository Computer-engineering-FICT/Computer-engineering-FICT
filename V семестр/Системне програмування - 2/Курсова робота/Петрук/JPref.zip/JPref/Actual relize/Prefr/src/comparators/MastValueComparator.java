package comparators;

import game.Card;

import java.util.Comparator;

public class MastValueComparator implements Comparator<Card> {

	@Override
	public int compare(Card card1, Card card2) {
		if (card1.getMast() > card2.getMast())
			return 1;
		else if (card1.getMast() < card2.getMast())
			return -1;
		else
			if (card1.getValue()>card2.getValue())
				return 1;
			else return -1;

	}

}
