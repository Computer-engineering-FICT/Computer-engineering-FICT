package network;

import game.Game;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class PreferansServer {
	private static String serverName = "PreferansServer";
	private static String listenerServer = "ListenerServer";

	public static void runPreferansServer(Game newGame) throws RemoteException {
		boolean isPortOccupied = true;
		int currentPort = 2000;
		while (isPortOccupied) {

			Registry registry;
			try {
				registry = LocateRegistry.createRegistry(currentPort);
				isPortOccupied = false;
				registry.rebind(serverName, newGame);
			} catch (RemoteException e) {
				if (currentPort != 2005) {
					currentPort++;
				} else {
					System.out
							.println("The server is overloaded! Please, try again later!");
				}
			}
		}
		System.out.println("Server started on port " + currentPort);
	}

	public static ListenerPrefInterface getListenerInterface(String clientHost,
			int startPort) {
		ListenerPrefInterface prefClientListener = null;
		int currentPort = startPort;
		System.out.print("Waiting listener connection...");
		for (int i = currentPort; i <= startPort + 5; i++) {
			String port = Integer.toString(currentPort);
			System.out.println("//" + clientHost + ":" + port + "/"
					+ listenerServer);
			String lookupString = "//" + clientHost + ":" + port + "/"
					+ listenerServer;

			try {
				try {
					prefClientListener = (ListenerPrefInterface) Naming
							.lookup(lookupString);
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NotBoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("connection established");
				break;
			} catch (RemoteException e) {
				currentPort++;
			}
		}
		if (currentPort == startPort + 6) {
			System.out
					.println("No game servers! Please, create your one server!");
		}
		return prefClientListener;
	}
}
