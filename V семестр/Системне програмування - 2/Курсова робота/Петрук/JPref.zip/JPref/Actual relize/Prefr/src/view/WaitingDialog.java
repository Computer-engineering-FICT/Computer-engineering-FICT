package view;

import game.Game;
import game.RunGame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WaitingDialog extends JDialog {
	private JLabel label;
	private String info = "Waiting for players";
	private Game newGame;
	private JButton but;
	private JPanel pan;

	public WaitingDialog(final MainFrame frame, Game game) {
		super(frame, "Client", true);
		newGame = game;
		setBounds(400, 400, 350, 120);
		pan = new JPanel();
		pan.setLayout(new BorderLayout());
		label = new JLabel(info);
		label.setBounds(400, 400, 350, 120);
		pan.add(label, BorderLayout.SOUTH);
		JButton but = new JButton("StartGame");
		but.addActionListener(new ButtonAction());
		pan.add(but, BorderLayout.NORTH);
		add(pan);
	}

	public void addPlayer(String playerInfo) {
		playerInfo = "\n" + playerInfo;
		info = info + playerInfo;
		label.setText(info);
		System.out.println("here");
	}

	public void addsome() {
		label.setText("gavno");
		repaint();
	}

	public class ButtonAction extends AbstractAction {

		public void actionPerformed(ActionEvent arg0) {
			int nubmOfGamers0 = 0;
			while (nubmOfGamers0 < 3) {
				if (nubmOfGamers0 != newGame.getNumbOfGamers()) {
					System.out.println("dfdf");
					nubmOfGamers0 = newGame.getNumbOfGamers();
					info += newGame.getPlayers().get(nubmOfGamers0 - 1)
							.getNick();
					label.setText(info);
					pan.repaint();
					System.out.println(info);
					newGame.printPlayers();
				}
			}
			setVisible(false);
		}
	}

	public Game getnewGame() {
		return newGame;
	}
}