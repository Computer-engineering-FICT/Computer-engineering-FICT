package game;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Trick extends JFrame {

	private final int HORIZONTAL = 5;
	private final int VERTICAL = 5;
	private JPanel centerPanel;
	private JPanel southPanel;
	

	Trick() {
		centerPanel = new JPanel();
		setLayout(new BorderLayout());
		add(centerPanel,BorderLayout.NORTH);
		centerPanel.setLayout(new GridLayout(HORIZONTAL, VERTICAL));
		for (int i = 0; i < HORIZONTAL; i++) {
			for (int j = 0; j < VERTICAL; j++) {
				JButton but = new JButton("" + i + j);
				centerPanel.add(but);
			}
		}
		southPanel=new JPanel();
		southPanel.setLayout(new GridLayout(1,2));
		JButton button1 = new JButton("PASS");
		southPanel.add(button1);
		JButton button2 = new JButton("XZXZXZ");
		southPanel.add(button2);
		add(southPanel);
		pack();
	}
}
