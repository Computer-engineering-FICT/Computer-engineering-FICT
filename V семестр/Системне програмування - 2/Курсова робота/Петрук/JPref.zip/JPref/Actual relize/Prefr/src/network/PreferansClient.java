package network;

import game.RunGame;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import network.GameServerInterface;

public class PreferansClient {
	private static String serverName = "PreferansServer";
	private static String listenerServer = "ListenerServer";
	//
	private static File sFile = new File("listener_client_LOG.txt");;
	private static FileWriter fosS;

	//

	public static GameServerInterface connectToServer(String serverHost)
			throws MalformedURLException, NotBoundException {

		GameServerInterface prefServer = null;
		try {
			sFile.createNewFile();
			fosS = new FileWriter(sFile);

			int currentPort = 2000;
			System.out.print("Waiting connection...");
			for (int i = currentPort; i <= 2005; i++) {
				String port = Integer.toString(currentPort);
				fosS.write("stP = " + "//" + serverHost + ":" + port + "/"
						+ serverName + "\n");
				String lookupString = "//" + serverHost + ":" + port + "/"
						+ serverName;
				try {
					prefServer = (GameServerInterface) Naming
							.lookup(lookupString);
					System.out.println("connection established");
					break;
				} catch (RemoteException e) {
					currentPort++;
				}
			}
			if (currentPort == 2006) {
				fosS.write("No game servers! Please, create your one server!\n");
			}
			fosS.write("client connect to curPort = " + currentPort+"\n");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return prefServer;
	}

	public static void transmitListenerInterface(int startPort, RunGame currentGame)
			throws RemoteException {
		ClientListener clientListener = new ClientListener(currentGame);
		boolean isPortOccupied = true;
		try {
			fosS.write("Start port = " + startPort+"\n");

			int currentPort = startPort;
			clientListener = new ClientListener();
			while (isPortOccupied) {

				Registry registry;
				try {
					registry = LocateRegistry.createRegistry(currentPort);
					isPortOccupied = false;
					registry.rebind(listenerServer, clientListener);
				} catch (RemoteException e) {
					if (currentPort != startPort + 5) {
						currentPort++;
					} else {
						System.out
								.println("The server is overloaded! Please, try again later!");
					}
				}
				System.out.println("list port start on port = " + currentPort);
			}
			fosS.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
