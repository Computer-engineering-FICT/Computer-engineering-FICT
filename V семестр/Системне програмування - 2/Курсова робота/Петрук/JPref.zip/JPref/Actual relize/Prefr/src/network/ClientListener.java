package network;

import game.RunGame;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ClientListener extends UnicastRemoteObject implements
		ListenerPrefInterface, Serializable {
	private RunGame currentGame;

	protected ClientListener() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClientListener(RunGame currentGame) throws RemoteException {
		this.currentGame = currentGame;
	}

	public String isSomeOperation() {
		return "smth ddddd";
	}
	public void waitOper(int code) throws RemoteException{
		
	}

}
