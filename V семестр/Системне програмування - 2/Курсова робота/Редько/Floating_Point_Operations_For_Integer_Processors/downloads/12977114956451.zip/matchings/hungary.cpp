

#include <stdio.h>
#define N 155

int v[N][N],u[N][N], cross0[N][N];
int str0[N],col0[N];
int strround[N],colround[N];
int usestr[N];
int n;
int vmax=0;

void read(){
int a;
int i,j;

 fscanf(stdin,"%i",&n);
 for(i=0; i<n; i++) col0[i]=0;
for(i=0; i<n; i++)
   for(j=0; j<n; j++)
     {
       fscanf(stdin,"%i",&v[i][j]);
       col0[j] += v[i][j];
     }
 for(i=0; i<n; i++)
   for(j=0; j<n; j++)
      v[i][j]=col0[j]-v[i][j];
}

void privod(void){
int i,j,umin;
for(i=0; i<n; i++)
   for(j=0; j<n; j++)
      vmax = vmax > v[i][j] ? vmax : v[i][j];
   for(i=0; i<n; i++)
      for(j=0; j<n; j++)
         u[i][j] = v[i][j];
for(i=0; i<n; i++){
   umin=u[i][0];
   for(j=1; j<n; j++)
      umin = umin < u[i][j] ? umin : u[i][j];
   for(j=0; j<n; j++)
      u[i][j]-=umin;
   }
for(j=0; j<n; j++){
   umin=u[0][j];
   for(i=1; i<n; i++)
      umin = umin < u[i][j] ? umin : u[i][j];
   for(i=0; i<n; i++)
      u[i][j]-=umin;
   }
}

void mark0(){
int i,j;
for(i=0; i<n; i++)
   for(j=0; j<n; j++)
      cross0[i][j]=0;
for(i=0; i<n; i++)
   str0[i]=col0[i]=0;
for(i=0; i<n; i++)
   for(j=0; j<n; j++)
      if(u[i][j]==0)
         if(str0[i]==0 && col0[j]==0){
            cross0[i][j]=1;
            str0[i]=col0[j]=1;
            }
         else
            cross0[i][j]=-1;
}

int findcouple(int i){
int i1,j=0;
while(cross0[i][j]!=1) j++;
for(i1=0; i1<n; i1++)
   if(cross0[i1][j]==-1 && !usestr[i1]){
      if(!str0[i1]){
         str0[i1]=1;
         cross0[i1][j]=1;
         cross0[i][j]=-1;
         return 1;
         }
      else{
         usestr[i1]=1;
         if(findcouple(i1)){
            cross0[i1][j]=1;
            cross0[i][j]=-1;
            return 1;
            }
         }
      }
return 0;
}

int upcouple(){
int i,j;
for(i=0; i<n; i++)
   usestr[i]=0;
for(j=0; j<n; j++)
   if(!col0[j])
      for(i=0; i<n; i++)
         if(cross0[i][j]==-1){
            usestr[i]=1;
            if(findcouple(i)){
               col0[j]=1;
               cross0[i][j]=1;
               return 1;
               }
            else
               usestr[i]=0;
            }
return 0;
}

void maxcouple(){
while(upcouple());
}

int fin(){
int i;
for(i=0; i<n; i++)
   if(!str0[i])
      return 0;
return 1;
}

void minsupport(){
int i,j,b;
for(i=0; i<n; i++)
   strround[i]=colround[i]=0;
for(i=0; i<n; i++)
   strround[i]=1-str0[i];
b=1;
while(b){
   b=0;
   for(i=0; i<n; i++)
      if(strround[i])
         for(j=0; j<n; j++)
            if(cross0[i][j]==-1)
               colround[j]=1;
   for(j=0; j<n; j++)
      if(colround[j])
         for(i=0; i<n; i++)
            if(cross0[i][j]==1 && !strround[i]){
               b=1;
               strround[i]=1;
               }
   }
}

void rotate0(){
int i,j,min=vmax;
for(i=0; i<n; i++)
   if(strround[i])
      for(j=0; j<n; j++)
         if(!colround[j])
            if(min>u[i][j])
               min=u[i][j];
for(i=0; i<n; i++)
   if(!strround[i])
      for(j=0; j<n; j++)
         u[i][j]+=min;
for(j=0; j<n; j++)
   if(!colround[j])
      for(i=0; i<n; i++)
         u[i][j]-=min;
}

void answer(void){
int i,j,sum=0;
for(i=0; i<n; i++){
   for(j=0; j<n; j++)
      if(cross0[i][j]==1){
         sum+=v[i][j];
         break;
      }
   }
  fprintf(stdout,"%i\n",sum);
}

void method(void){
  privod();
  while(1){
   mark0();
   maxcouple();
   if(fin())
      break;
   minsupport();
   rotate0();
   }
   answer();
}

int main(void)
{
  read();
  method();
}


