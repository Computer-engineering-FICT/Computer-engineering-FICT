package com.lab111.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
* Клас представляє панель інструментів.
* @author Сергій Жиденко
*/
public class DiagToolBar extends JToolBar {
    private JButton addBtn;
    private JButton rmvBtn;
    private JLabel maxOYLabel;
    private JLabel gridValueLabel;
    private JTextField maxOYField;
    private JTextField gridValue;
    private DiagramMainPane mediator;


    /**
     * Створює тулбар
     * @param mediator головна панель.
     */
    public DiagToolBar (DiagramMainPane mediator) {
        super();
        this.mediator = mediator;
        this.setLayout(new FlowLayout(FlowLayout.LEFT));
        this.add(getAddBtn());
        this.add(getRmvBtn());
        this.addSeparator();
        this.add(getMaxOYLabel());
        this.add(getMaxOYField());
        this.add(getGridLabel());
        this.add(getGridValue());
    }

    /**
     * Створює кнопку додавання.
     * @return кнопка додавання.
     */
    public JButton getAddBtn () {
        if (addBtn == null) {
            addBtn = new JButton ();
            ImageIcon icon = new ImageIcon("images/list-add.png");
            addBtn.setIcon(icon);
            addBtn.setToolTipText("Add new element to the diagram");
            addBtn.setPreferredSize(new Dimension(30,30));
            addBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String[] row = new String[mediator.getCSVModel().getColumnCount()];
                    row[0] = new String("New ")+mediator.getCSVModel().getColumnCount();
                    row[1] = new String("2");
                    row[2] = new String("1.5");
                    row[3] = new String("1");
                    mediator.getCSVModel().addNewRow(row);
                }
            });

        }
        return addBtn;


    }

    /**
     * Створює кнопку видалення.
     * @return кнопка видалення.
     */
    public JButton getRmvBtn () {
        if (rmvBtn == null) {
            rmvBtn = new JButton ();
            ImageIcon icon = new ImageIcon ("images/edit-delete.png");
            rmvBtn.setIcon(icon);
            rmvBtn.setPreferredSize(new Dimension(30,30));
            rmvBtn.setToolTipText("Remove last element in a table");
            rmvBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mediator.getCSVModel().removeRow();
                }
            });
        }
        return rmvBtn;

    }


    /**
     * Мітка-повідомлення про введення макс. значення вісі Оу.
     * @return мітка, повідомлення про поле введення значення вісі Оу.
     */
    public JLabel getMaxOYLabel (){
        if (maxOYLabel == null) {
            maxOYLabel = new JLabel();
            ImageIcon icon = new ImageIcon("images/axis.png");
            maxOYLabel.setIcon(icon);
            maxOYLabel.setToolTipText("Set maximum OY value");
        }
        return maxOYLabel;

    }

    /**
     * Повертає мітку-повідомлення про введення значення сітки.
     * @return мітка з повідомлення про поле введення сітки.
     */
    public JLabel getGridLabel () {
        if (gridValueLabel == null) {
            gridValueLabel = new JLabel ();
            ImageIcon icon = new ImageIcon("images/measure.png");
            gridValueLabel.setIcon(icon);
            gridValueLabel.setToolTipText("Input a value of a grid to the text field on the right");
        }
        return gridValueLabel;
    }

    /**
     * Повертає поле для введення значення сітки.
     * @return поле для введення значення сітки.
     */
    public JTextField getGridValue () {
        if (gridValue == null) {
            gridValue = new JTextField (3);
            StockDiagramDrawer drw = (StockDiagramDrawer)(mediator.getRightPanel());
            gridValue.setText (drw.getGrid()+"");
            gridValue.setPreferredSize(new Dimension(35,20));

            gridValue.addKeyListener(new KeyAdapter() {
                @Override
                public void keyTyped(KeyEvent e) {
                    char key = e.getKeyChar();
                    if (!Character.isDigit(key) && key !='.')
                        e.consume();
                }

            });
            gridValue.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        ((StockDiagramDrawer)(mediator.getRightPanel())).setGrid (
                                Double.parseDouble(gridValue.getText()));
                    } catch (NumberFormatException ex) {
                        String msg = new String ("Incorrect value!");
                        JOptionPane.showMessageDialog(mediator.getFrame(), msg,
                                "Error occured", JOptionPane.ERROR_MESSAGE);
                    }
                    mediator.getRightPanel().repaint();
                }
            });
        }
        return gridValue;
    }

    /**
     * Повертає поле для введення макс. значення по осі Оу.
     * @return повідомлення про значення поля введення Оу.
     */
    public JTextField getMaxOYField () {
        if (maxOYField == null) {
            maxOYField = new JTextField (3);
            maxOYField.setText (((StockDiagramDrawer)(mediator.getRightPanel())).getMaxOY() + "");
            maxOYField.setPreferredSize(new Dimension (30,20));

            maxOYField.addKeyListener(new KeyAdapter() {
                @Override
                public void keyTyped(KeyEvent e) {
                    char key = e.getKeyChar();
                    if (!Character.isDigit(key) && key !='.') {
                        e.consume();
                    }
                }
            });

            maxOYField.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        ((StockDiagramDrawer)(mediator.getRightPanel())).
                                setMaxValue(Double.parseDouble(maxOYField.getText()));
                    } catch (NumberFormatException ex) {
                        String msg = new String ("Incorrect value!");
                        JOptionPane.showMessageDialog(mediator.getFrame(), msg,
                                "Error occured", JOptionPane.ERROR_MESSAGE);
                    }
                    mediator.getRightPanel().repaint();
                }
            });
        }
        return maxOYField;
    }

}
