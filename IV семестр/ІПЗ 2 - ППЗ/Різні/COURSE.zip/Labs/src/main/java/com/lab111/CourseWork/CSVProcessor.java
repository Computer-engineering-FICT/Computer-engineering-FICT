package com.lab111.CourseWork;

import java.io.*;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

/**
 *  Клас представляє собою набір методів для обробки даних.
 *  Всі методи є статичними, тож немає потреби інстанціювати клас для запису
 *  чи читання з файлу, або для парсингу файлу.
 *
 *  @author Сергій Жиденко
 *
 */
public class CSVProcessor implements Serializable{

    private static int exitCode;                                // Код виходу
    private static Settings settings = Settings.getInstance();  // Налаштування

    /**
     * Метод читає з файлу інформацію і записує її в текстовій формі до списку.
     * @param name ім'я файлу, з якого треба зчитати.
     * @return csvFileProcessed масив-список із зчитаними даними.
     * @throws IOException виключення введення-виведення.
     */
    public static ArrayList<String> read(String name) throws IOException {
        File csvFile = new File (name);
        if(!csvFile.exists()){
            throw new FileNotFoundException();
        }

        BufferedReader in = new BufferedReader(new FileReader(csvFile));
        String line;
        ArrayList<String> csvFileProcessed = new ArrayList<String>();
        while ((line=in.readLine())!= null) {
            csvFileProcessed.add(line);
        }

        in.close();
        return csvFileProcessed;
    }

    /**
     * Метод дозволяє здійснити запис у файл певних даних.
     * @param csvName ім'я файлу, в який необхідно здійснити запис.
     * @param columnNames імена заголовків таблиці.
     * @param data Дані, які необхідно записати.
     * @throws IOException Виключення введення-виведення.
     */
    public static void write(String csvName, String[] columnNames, String[][] data) throws IOException {
        File csvFile = new File(csvName);
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(csvFile)));
        if (!csvFile.exists())
            csvFile.createNewFile();
        String str = new String("");
        for (int i=0; i<columnNames.length; i++) {
            str+=columnNames[i]+";";
        }
        out.println(str);
        for (int i=0; i<data.length; i++) {
            str = new String("");
            for (int j=0; j<data[0].length; j++) {
                str+=data[i][j]+";";
            }
            out.println(str);
        }

        out.close();
    }

    /**
     * Метод здійснює запис у файл інформації
     * @param file файл, у який здійснюють запис.
     * @param csvFileProcessed Інформація, яку треба записати.
     * @throws IOException Виключення введення-виведення.
     */
    public static void write (File file, ArrayList<String> csvFileProcessed) throws IOException{
        PrintWriter out = new PrintWriter (new BufferedWriter(new FileWriter(file)));
        file.createNewFile();
        for (String s: csvFileProcessed) {
            out.println(s);
        }

        out.close();
    }

    /**
     * Метод призначений для серіалізації передаваного об'єкта у вигляді одного
     * файла.
     * @param file Файл, в який здійснюють серіалізацію.
     * @param csvFileProcessed Інформація, яку необхідно серіалізувати.
     * @throws IOException Виключення введення-виведення.
     */
    public static void serializeCSV(File file, ArrayList<String> csvFileProcessed) throws IOException {
        if (!file.exists())
            file.createNewFile();

        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));

        oos.writeObject(csvFileProcessed);
        oos.close();
    }

    /**
     * Метод призначений для десеріалізації даних.
     * @param file Файл, з якого зчитають об'єкт.
     * @param csvFileProcessed Об'єкт, який одержить десеріалізовану інформацію.
     * @return csvFileProcessed Об'єкт з інформацією.
     * @throws IOException Виключення введення-виведення.
     * @throws ClassNotFoundException Виключення, котре виникає у випадку невідповідності класів.
     */
    public static ArrayList<String> deserializeCSV(File file, ArrayList<String> csvFileProcessed)
            throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));

        csvFileProcessed = (ArrayList<String>) ois.readObject();
        ois.close();
        return csvFileProcessed;
    }


    /**
     * Метод здійснює парсинг інформації - розбір на складові частини і запис у двувимірний масив рядків.
     * @param csvFileProcessed Файл, котрий необхідно парсити.
     * @return parsedData Відпарсений двувимірний масив рядків.
     * @throws CSVParseException Виключення парсингу.
     */
    public static String[][] parseData(ArrayList<String> csvFileProcessed) throws CSVParseException {
        int rows = csvFileProcessed.size();
        Settings sets = Settings.getInstance();
        StringTokenizer tokenizer = new StringTokenizer(csvFileProcessed.get(0), sets.getProperty("delimeter"));

            int columns = tokenizer.countTokens();
            String[][] parsedData = new String[rows][columns];
        try {


            for (int i = 0; i < rows; i++) {
                tokenizer = new StringTokenizer(csvFileProcessed.get(i), sets.getProperty("delimeter"));
                if(tokenizer.countTokens()!=columns)
                    throw new CSVParseException("Wrong format of CSV-file");
                for (int j = 0; j < columns; j++) {

                    parsedData[i][j] = tokenizer.nextToken();
                }
            }
        } catch (NoSuchElementException e) {
            throw new CSVParseException();
        } catch (Exception e) {
            throw new CSVParseException();
        }
        if (settings.getProperty("diagramType").equals("StockDiagram")) {
            if (parsedData[0].length != 4) {
                String msg = new String("Wrong format of csv-file!");
                ErrorSender.throwError(msg);
                changeExitCode();
            }
        }
        return parsedData;
    }

    /**
     * Змінює код виходу.
     */
    public static void changeExitCode () {
        exitCode = 1;
    }

    /**
     * Повертає код виходу.
     * @return exitCode код виходу.
     */
    public static int getExitCode () {
        return exitCode;
    }




}
