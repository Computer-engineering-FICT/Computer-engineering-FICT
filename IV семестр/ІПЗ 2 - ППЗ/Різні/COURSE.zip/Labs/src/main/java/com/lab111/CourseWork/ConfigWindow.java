package com.lab111.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Клас представляє вікно опцій для користувача.
 * @author Сергій Жиденко
 */
public class ConfigWindow extends JDialog {
    // Різні елементи вікна
    private JButton okBtn;                  // Кнопка "ОК".
    private JButton cancelBtn;              // Кнопка "Вийти".
    private JPanel contentPane;             // головна панель.
    private JComboBox lookAndFeelBox;       // Компонент вибору стилю.
    private Settings conf;                  // Налаштування.
    private JLabel gridCLabel;              // Елемент кольору сітки.
    private JLabel elCLabel;                // Елемент кольору елементу.
    private DiagramFrame frame;             // Головне вікно програми.

    /**
     * Створює вікно опцій та здійснює початкову ініціалізацію.
     * @param frame Головне вікно додатку.
     */
    public ConfigWindow(DiagramFrame frame) {
        super();
        this.frame = frame;
        conf = Settings.getInstance();
        this.setSize(Integer.parseInt(conf.getProperty("optDialogWidth")),
                Integer.parseInt(conf.getProperty("optDialogHeight")));
        this.setLocationRelativeTo(frame);
        contentPane = new JPanel (new BorderLayout());

        this.setContentPane(contentPane);
        setResizable(false);
        JLabel lnfLabel = new JLabel ("Preferred style");
        JLabel gridCLabel = new JLabel ("Color of grid");
        JLabel elColor = new JLabel ("Color of elements");
        JPanel panel = new JPanel (new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.3;
        panel.add (lnfLabel, c);

        c.fill = GridBagConstraints.NONE;
        c.weightx = 0.7;
        c.gridx = 1;
        c.gridy = 0;
        panel.add (getLookAndFeelBox(), c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.3;
        c.gridx = 0;
        c.gridy = 1;
        panel.add (gridCLabel, c);

        c.fill = GridBagConstraints.NONE;
        c.weightx = 0.7;
        c.gridx = 1;
        c.gridy = 1;
        panel.add (getGridCLabel(), c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.3;
        c.gridx = 0;
        c.gridy = 2;
        panel.add (elColor, c);

        c.fill = GridBagConstraints.NONE;
        c.weightx = 0.7;
        c.gridx = 1;
        c.gridy = 2;
        panel.add (getElCLabel(), c);

        add(panel, BorderLayout.NORTH);

        JPanel buttons = new JPanel (new BorderLayout());
        buttons.add (getOkBtn(), BorderLayout.CENTER);
        buttons.add (getCancelBtn(), BorderLayout.EAST);
        add (buttons, BorderLayout.CENTER);
    }

    /**
     * Метод повертає (за необхідності - створює й налаштовує) компонент JComboBox, котрий
     * дозволяє обрати стиль (зовнішній вигляд) програмного додатку.
     * @return lookAndFeelBox компонент вибору стилю JComboBox.
     */
    private JComboBox getLookAndFeelBox () {
        if (lookAndFeelBox == null) {
            String[] variant = {"Default", "Metal", "Motif"};
            lookAndFeelBox = new JComboBox (variant);
            String selected = conf.getProperty("lookAndFeel");
            for (int i=0; i<variant.length; i++) {
                if (selected.equals(variant[i])) {
                    lookAndFeelBox.setSelectedIndex(i);
                }
            }
            lookAndFeelBox.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String name = (String)lookAndFeelBox.getSelectedItem();
                    frame.setLNF(name);
                    }


            });

        }
    return lookAndFeelBox;
    }

    /**
     * Метод повертає (за необхідності - створює й налаштовує) мітку вибору кольору сітки координатних осей.
     * @return gridCLabel компонент-мітка для вибору кольору сітки координатних осей.
     */
    private JLabel getGridCLabel () {
        if (gridCLabel == null) {
            gridCLabel = new JLabel();
            gridCLabel.setPreferredSize(new Dimension(15,15));
            gridCLabel.setBackground(Color.decode(conf.getProperty("gridColor")));
            gridCLabel.setOpaque(true);
            gridCLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    Color newColor = JColorChooser.showDialog(ConfigWindow.this, "Choose grid color",
                            gridCLabel.getBackground());
                    if (newColor !=null) {
                        gridCLabel.setBackground(newColor);
                }
            }
            });
        }
        return gridCLabel;
    }

    /**
     * Метод повертає (за необхідності - створює й налаштовує) мітку вибору кольору елементів.
     * @return elCLabel компонент-мітка кольору графічних елементів діаграми.
     */
    private JLabel getElCLabel () {
        if (elCLabel == null) {
            elCLabel = new JLabel();
            elCLabel.setPreferredSize(new Dimension(15, 15));
            elCLabel.setBackground(Color.decode(conf.getProperty("elementColor")));
            elCLabel.setOpaque(true);
            elCLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    Color newColor = JColorChooser.showDialog(ConfigWindow.this, "Choose element color",
                            elCLabel.getBackground());
                    if (newColor !=null) {
                        elCLabel.setBackground(newColor);
                    }
                }
            });
        }
        return elCLabel;

    }

    /**
     * Метод повертає (за необхідності - створює й налаштовує) кнопку "ОК", за якою відбувається збереження
     * налаштувань і вихід у головне вікно.
     * @return okBtn кнопка "ОК".
     */
    private JButton getOkBtn () {
        if (okBtn == null) {
            okBtn = new JButton ("OK");
            okBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    conf.setProperty("lookAndFeel", (String)lookAndFeelBox.getSelectedItem());
                    conf.setProperty("gridColor", Integer.toString(gridCLabel.getBackground().getRGB()));
                    conf.setProperty("elementColor", Integer.toString(elCLabel.getBackground().getRGB()));

                    conf.saveConf();
                    setVisible(false);
                }
            });
        }
        return okBtn;

    }

    /**
     * Метод повертає (за необхідності - створює й налаштовує) кнопку "Вихід".
     * @return cancelBtn Кнопка "Вихід".
     */
    private JButton getCancelBtn () {
        if (cancelBtn == null) {
            cancelBtn = new JButton ("Cancel");
            cancelBtn.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                }
            });
        }
        return cancelBtn;
    }


}
