package com.lab111.CourseWork;

import java.awt.event.MouseEvent;

/**
 * Конкретний контроллер стокової діаграми.
 * @author Сергій Жиденко
 */
public class StockDiagramController extends Controller {

    private int xPressed;                       // Координата х при натиску.
    private int yPressed;                       // Координата y при натиску.

    private int focusedElement = GraphicalElement.WRONG;    // Тип сфокусованого елементу
    private int focusedIndex = GraphicalElement.WRONG;       // Індекс сфокусованого елементу.
    private int focusedSwitch;                              // Сфокусований для обміну місцями.

    private double increaseRate;
    private Settings settings = Settings.getInstance();     // Налаштування.

    /**
     * Створює контролер.
     */
    public StockDiagramController() {
    }

    /**
     * Оброблює події при натисканні на кнопку.
     * @param e подія при натисканні на кнопку миші.
     */
    public void mousePressed (MouseEvent e) {
        xPressed = e.getX();
        yPressed = e.getY();
        focusedIndex = getDrawer().getFocused(xPressed, yPressed);
        focusedSwitch = getDrawer().getReadyToSwitch(e.getX(), e.getY());
        if (focusedIndex != GraphicalElement.WRONG) {
            focusedElement = getDrawer().getActive (xPressed,yPressed, focusedIndex);
        }
        increaseRate = 0;
    }


    /**
     * Оброблює подію при звільненні кнопки.
     * @param e подія при звільненні кнопки миші.
     */
    public void mouseReleased (MouseEvent e) {
        int ind = getDrawer().getReadyToSwitch(e.getX(), e.getY());
        focusedElement = GraphicalElement.WRONG;
        if (focusedIndex!=GraphicalElement.WRONG)
            increaseRate = 0;
        if (focusedIndex >0 && focusedIndex < getCSVM().getData().length)
            increaseRate = 0;
        if (ind >=0 && ind <=getCSVM().getData().length)
            getCSVM().switchElements(focusedSwitch, ind);
        getDrawer().repaint();

    }

    /**
     * Оброблює подію при русі мишки після натискання на кнопку.
     * @param e подія миші при пересуванні курсору при натиснутій клавіші.
     */
    public void mouseDragged (MouseEvent e) {
        if (focusedElement != GraphicalElement.WRONG && focusedIndex != GraphicalElement.WRONG) {
            switch (focusedElement) {
                case GraphicalElement.MOVE_ALL:
                    setCourses (focusedIndex, e.getY());
                    break;
                case GraphicalElement.MOVE_MAX:
                    setMaxCourse (focusedIndex, e.getY());
                    break;
                case GraphicalElement.MOVE_MIN:
                    setMinCourse (focusedIndex, e.getY());
                    break;
                case GraphicalElement.MOVE_CLOSE:
                    setCloseCourse (focusedIndex, e.getY());
                    break;
            }
            getCSVM().fireTableDataChanged();
            getDrawer().repaint();
        }

    }

    /**
     * Задає значення біржевих моделей відповідним чином.
     * @param ind індекс елементу для задання значення.
     * @param val значення.
     */
    public void setCourses (int ind, int val) {
        int delta =val - yPressed;
        double minCourse = Double.parseDouble((String)getCSVM().getValueAt(ind, 3));
        double maxCourse = Double.parseDouble((String)getCSVM().getValueAt(ind,1));

          if (((-delta /this.convOYtoRel() - increaseRate +
                  minCourse)>0 &&
                (-delta/this.convOYtoRel()-
                increaseRate+maxCourse) < getMaxOY())) {
            getCSVM().decrease(ind, increaseRate);
            increaseRate = -delta/(convOYtoRel());
            getCSVM().increase(ind, increaseRate);

        }
    }

    /**
     * Встановлює діаграму для заданого контролера.
     * @param diagDrw
     */
    public void setDrawer (DiagramDrawer diagDrw) {
        if (!(diagDrw instanceof StockDiagramDrawer)) {
            String msg = "Impossible to proceed, change controller and relaunch application";
            ErrorSender.throwError(msg);
            System.exit(0);
        }

        super.setDrawer(diagDrw);
    }

    /**
     * Встановлює нове максимальне значення моделі.
     * @param focusedIndex індекс елемента в моделі даних.
     * @param val значення для задання.
     */
    public void setMaxCourse (int focusedIndex, int val) {
        double realValue = (((StockDiagramDrawer)getDrawer()).getZeroY() - val)/((StockDiagramDrawer)getDrawer()).
                convOYToRel();
        if (realValue > Double.parseDouble((String)getCSVM().getValueAt(focusedIndex,2)) && realValue <=
                ((StockDiagramDrawer)getDrawer()).getMaxOY()) {

            if (realValue > Double.parseDouble((String)getCSVM().getValueAt(focusedIndex, 2)) && realValue <=
                getMaxOY()) {
                    getCSVM().setValueAt(focusedIndex,1,realValue);

            }
        }
    }

    /**
     * Встановлює значення елемента на момент закриття.
     * @param focusedIndex індекс елемента в моделі даних.
     * @param val значення для задання.
     */
    public void setCloseCourse (int focusedIndex, int val) {
        double realValue = (((StockDiagramDrawer)getDrawer()).getZeroY() - val)/((StockDiagramDrawer)getDrawer()).convOYToRel();
        if (realValue > Double.parseDouble((String)getCSVM().getValueAt(focusedIndex,3)) && realValue <=
                Double.parseDouble((String)getCSVM().getValueAt(focusedIndex,1))) {
            getCSVM().setValueAt(focusedIndex, 2, realValue);
        }
    }

    /**
     * Встановлює мінімальне значення елемента.
     * @param focusedIndex індекс елемента в моделі даних.
     * @param val значення для задання.
     */
    public void setMinCourse (int focusedIndex, int val) {
        double realValue = (((StockDiagramDrawer)getDrawer()).getZeroY() - val)/((StockDiagramDrawer)getDrawer()).
                convOYToRel();
        if (realValue > 0 && realValue <= Double.parseDouble((String)getCSVM().getValueAt(focusedIndex,2))) {
            getCSVM().setValueAt(focusedIndex, 3, realValue);
        }
    }

    /**
     * Конвертує "піксельне" значення в значення відносно максимального заданого в сітці.
     * @return відносне значення.
     */
    public double convOYtoRel () {
        return (getDrawer().getHeight() - Double.parseDouble(settings.getProperty("verticalIndent")) -
                Double.parseDouble(settings.getProperty("verticalIndent")))/getMaxOY();
    }

    /**
     * Повертає максимальне значення по осі Оу.
     * @return максимальне значення по Оу.
     */
    public double getMaxOY () {
        String[][] table = getCSVM().getData();
        int maxRow = table.length;
        int maxCol = table[0].length-1;
        int ind = 0;
		double max = 0;
		double[][] myDoubleTable = new double[maxRow][maxCol];
		for (int i = 0; i < maxRow; i++) {
			for (int j = 0; j < maxCol; j++) {
				if ((ind = table[i][j+1].indexOf('.')) == -1) {
					myDoubleTable[i][j] = Double.parseDouble(table[i][j+1]);
				} else
					myDoubleTable[i][j] = Double.parseDouble(table[i][j + 1].substring(0, ind)
									+ '.'
									+ table[i][j + 1].substring(ind + 1));

			}
		}

        double maxim = 0;
        for (int i=0; i<myDoubleTable.length; i++) {
            for (int j=0; j<myDoubleTable[0].length; j++) {
                if (maxim<myDoubleTable[i][j])
                    maxim=myDoubleTable[i][j];
            }
        }
        return maxim;
    }

}
