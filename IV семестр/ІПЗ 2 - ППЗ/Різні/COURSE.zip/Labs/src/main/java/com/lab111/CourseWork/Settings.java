package com.lab111.CourseWork;

import java.io.*;
import java.util.ArrayList;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;

/**
 * Клас-синглтон, призначений для маніпулювання з налаштуваннями. Вони використовуються всією програмою
 * для конфігурування різних компонентів.
 * @author Сергій Жиденко
 *
 */
public class Settings {
    private static Settings instance;                               // Об'єкт налаштувань.
    private Properties properties;                                  // Колекція, що зберігає пари значень.
    private File file;                                              // Файл, в котрий відбувається збереження.
    private static final String DEFAULT_FILENAME = "properties.xml";// Шлях до файлу.
    private ArrayList<ObserverIF> observers = new ArrayList<ObserverIF>();   // Спостерігачі. Слідкують за змінами налаштувань.

    /**
     * Здійснює створення та початкову ініціалізацію налаштувань.
     * НЕ доступний для прямого інстанціювання з зовнішніх класів.
     */
    private Settings() {
        this.properties = new Properties ();
        initialize();
    }

    /**
     * Метод повертає (за необхідністю - одноразово створює) об'єкт налаштувань. Одержання
     * налаштувань з інших класів виконується саме шляхом виклику даного методу.
     * @return instance Об'єкт налаштувань.
     */
    public static Settings getInstance() {
        if (instance == null) {
            instance = new Settings();
        }
        return instance;
    }

    /**
     * Метод здійснює ініціалізацію налаштувань.
     */
    private void initialize () {
        this.file = new File (DEFAULT_FILENAME);

        try {
            this.loadConf();
        }
        catch (InvalidPropertiesFormatException e){
            try {
                defaultInit();
            } catch (IOException e1) {
                String msg = new String ("Error while loading settings. Please restart application");
                ErrorSender.throwError(msg);
            }
        }
        catch (IOException e2) {
            try {
                defaultInit();
            }
            catch (IOException e3) {
                String msg = new String ("Error while loading setting. Please restart application");
                ErrorSender.throwError(msg);
            }
        }

    }

    /**
     * Метод здійснює завантаження параметрів з початковими стандартними параметрами.
     * @throws IOException Несподівана помилка при збереженні.
     */
    private void defaultInit () throws IOException {
        properties.put("delimeter", ";");
        properties.put("backgroundColor", "0xBBBBBB");
        properties.put("gridColor", "0x000000");
        properties.put("elementColor", "0x000000");
        properties.put("lookAndFeel", "Default");
        properties.put("mainFrameWidth","900");
        properties.put("mainFrameHeight", "600");
        properties.put("optDialogWidth", "210");
        properties.put("optDialogHeight", "120");
        properties.put("horizontalIndent", "20");
        properties.put("verticalIndent", "20");
        properties.put("gridValue", "1d");
        properties.put("defaultFilename", "temp.csv");
        properties.put("defaultString", "Default;1.5;1;0");
        properties.put("defaultHeader", "Date;max;close;min");
        properties.put("diagramType", "StockDiagram");
        properties.put("diameter", "15");
        properties.put("rangeBounds", "20");
        file = new File(DEFAULT_FILENAME);
        saveConf();

    }

    /**
     * Метод здійснює збереження налаштувань у файл.
     */
    public void saveConf () {
        try {
        if (!file.exists())
            file.createNewFile();

        properties.storeToXML(new BufferedOutputStream(new FileOutputStream(file)), "", "UTF-8");
        } catch (IOException e) {
            String msg = new String ("Unexpected error while saving properties. Try one more time.");
        }
    }

    /**
     * Метод здійснює завантаження налаштувань з файлу.
     * @throws InvalidPropertiesFormatException Формат налаштувань невірний.
     * @throws IOException Несподіванка помилка виведення.
     */
    private void loadConf () throws InvalidPropertiesFormatException, IOException {
        properties.loadFromXML(new BufferedInputStream(new FileInputStream(file)));
    }

    /**
     * Метод здійснює збереження (оновлення значення) певного параметру.
     * @param name Ім'я параметру, який бажають записати/змінити.
     * @param value Значення параметру, який бажають записати/змінити.
     */
    public void setProperty (String name, String value) {
        properties.put(name, value);
        if (name.equals("gridColor")||(name.equals("elementColor"))) {
            sendNotification();
        }
    }

    /**
     * Метод дозволяє одержати значення того чи іншого параметру.
     * @param name Ім'я параметру, значення якого бажають одержати.
     * @return value Значення параметру з ім'ям name.
     */
    public String getProperty (String name) {
        return properties.getProperty(name);

    }

    /**
     * Метод дозволяє класу налаштувань додати спостерігача.
     * @param observer Спостерігач, що слідкує за оновленням значень деяких параметрів.
     */
    public void attach (ObserverIF observer) {
        observers.add(observer);
    }

    /**
     * Метод видаляє спостерігача.
     * @param index Індекс спостерігача, котрого бажають видалити.
     */
    public void deattach (int index) {
        observers.remove(index);
    }

    /**
     * Метод відправляє спостерігачам оголошення про зміну певних параметрів.
     */
    public void sendNotification() {
        for (ObserverIF d:observers) {
            d.updateInfo ();
        }
    }

}
