package com.lab111.CourseWork;

import javax.swing.filechooser.FileFilter;
import java.io.File;

/**
 * Клас - фільтр для будь-якого формату. Встановлює фільтр, в контексті даної системи - для
 * вікон збереження-завантаження.
 * @author Сергій Жиденко
 *
 */
public class UniversalFilter extends FileFilter {
    private String filter;

    /**
     * Створює фільтр.
     * @param filter Рядок, за яким вібувається фільтрування.
     */
    public UniversalFilter(String filter) {
        this.filter = filter ;
    }

    /**
     * Приймає файл або ні в залежності від критерію фільтрування.
     * @param f Файл в файловій системі користувача.
     * @return flag True - якщо файл відповідає критеріям, false - якщо ні.
     */
    public boolean accept (File f) {
        if (f.isDirectory() || f.getName().indexOf(filter) != -1) {
            return true;
        }
        return false;
    }

    /**
     * Повертає опис даного фільтру.
     * @return опис фільтру.
     */
    public String getDescription () {
        return filter;
    }
}
