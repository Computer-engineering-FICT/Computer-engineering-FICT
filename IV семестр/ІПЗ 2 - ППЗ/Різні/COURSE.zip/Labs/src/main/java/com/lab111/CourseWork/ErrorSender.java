package com.lab111.CourseWork;

import javax.swing.*;

/**
 * Клас викликає вікно помилки з певним повідомленням.
 *
 * @author Сергій Жиденко.
 *
 */
public class ErrorSender {
    private static DiagramFrame frame;         // Головне вікно програмного додатку

    /**
     * Створює об'єкт для виклика повідомлень. Насправді, об'єкт необхідно ініціалізувати
     * лишень один раз, з метою заповнення поля "головного вікна".
     * @param frame Головне вікно програмного додатку.
     */
    public ErrorSender(DiagramFrame frame) {
        this.frame = (frame);
    }

    /**
     * Статичний клас для виклику діалогового вікна з повідомленням про помилку.
     * @param msg Повідомлення з інформацією про помилку.
     */
    public static void throwError (String msg) {
        JOptionPane.showMessageDialog(frame, msg, "Error occured", JOptionPane.ERROR_MESSAGE);
    }
}
