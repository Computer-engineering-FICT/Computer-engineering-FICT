package com.lab111.CourseWork;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.sun.java.swing.plaf.gtk.GTKLookAndFeel;
import com.sun.java.swing.plaf.motif.MotifLookAndFeel;

import javax.swing.*;
import javax.swing.plaf.metal.MetalLookAndFeel;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 *  Даний клас представляє головне вікно програми.
 *
 *  @author Сергій Жиденко
 */
public class DiagramFrame extends JFrame {

    // Компоненти у вікні
    private JMenuBar menuBar;                               // Компонент меню
    private JMenu fileMenu;                                 // Меню "Файл"
    private JMenu additionalMenu;                           // Меню "Додатково"
    private JMenuItem newFile, openFile, saveFile,
            saveDiagram, close, exit, options;              // Пункти меню
    private JTabbedPane tabbedPane;                         // Компонент вкладок
    private ConfigWindow settingsDialog;                    // Діалог опцій
    private Settings settings;                              // Налаштування
    private ErrorSender err;                                // Вивід помилки


    /**
     * Створює новий екземпляр класу та виконує початкову ініціалізацію.
     */
    public DiagramFrame() {
        super ();
        settings = Settings.getInstance();
        setTitle("Diagram Drawer Application");
        setSize(new Dimension(Integer.parseInt(settings.getProperty("mainFrameWidth")),
                Integer.parseInt(settings.getProperty("mainFrameHeight"))));
        setLocationByPlatform(true);
        setMenu();
        JPanel contentPane = new JPanel (new BorderLayout());
        this.setContentPane(contentPane);
        tabbedPane = new JTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);
        err = new ErrorSender(this);

    }

    /**
     * Метод здійснює ініціалізацію меню.
     */
    private void setMenu () {
        menuBar = new JMenuBar ();

        fileMenu = new JMenu ("File");
        additionalMenu = new JMenu("Additional");
        fileMenu.add (getNewFile());
        fileMenu.add (getOpenFile());
        fileMenu.addSeparator();
        fileMenu.add (getSaveFile());
        fileMenu.add (getSaveDiagram());
        fileMenu.addSeparator();
        fileMenu.add (getClose());
        fileMenu.add (getExit());
        additionalMenu.add (getOptions());
        menuBar.add(fileMenu);
        menuBar.add(additionalMenu);
        setJMenuBar(menuBar);
    }

    /**
     * Метод змінює активний стан деяких пунктів меню.
     * @param flag відповідний стан: активний/не_активний.
     */
    private void setMenuItemsStatus (boolean flag) {
        saveFile.setEnabled(flag);
        saveDiagram.setEnabled(flag);
        close.setEnabled(flag);
    }

    /**
     * Метод створює пункт меню "Створити новий файл". Додає пункту меню відповідну реакцію на дію.
     * @return newFile пункт меню "Створити новий файл".
     */
    private JMenuItem getNewFile () {
        if (newFile == null) {
            newFile = new JMenuItem ("New project");
            newFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.ALT_MASK));
            ImageIcon icon = new ImageIcon ("images/document-new.png");
            newFile.setIcon(icon);
            newFile.addActionListener (new ActionListener() {
                public void actionPerformed (ActionEvent e) {
                    DiagramMainPane dmp = new DiagramMainPane (DiagramFrame.this, new StockDiagramDrawer(),
                            new StockDiagramController());
                    Dimension dim = new Dimension(getContentPane().getWidth(), getContentPane().getHeight());
                    dmp.setPreferredSize(dim);
                    if (dmp.loadTable(null)) {
                        dmp.setName ("New");
                        tabbedPane.add (dmp);
                        tabbedPane.setSelectedComponent(dmp);
                    }
                    setMenuItemsStatus(true);
                    settings.attach(dmp.getRightPanel());
                    DiagramFrame.this.repaint ();
                }
            });
        }
        return newFile;
    }

    /**
     * Метод повертає (за необхідності - створює) пункт меню "Відкрити файл".
     * @return openFile пункт меню "Відкрити файл".
     */
    private JMenuItem getOpenFile () {
        if (openFile == null) {
            openFile = new JMenuItem ("Open project");
            openFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.ALT_MASK));
            ImageIcon icon = new ImageIcon ("images/document-open.png");
            openFile.setIcon(icon);
            openFile.addActionListener (new ActionListener () {
                public void actionPerformed (ActionEvent e) {
                    JFileChooser chooser = new JFileChooser ();
                    chooser.setFileFilter(new UniversalFilter(".csv"));
                    DiagramMainPane dmp;
                    if (chooser.showOpenDialog(DiagramFrame.this) == JFileChooser.APPROVE_OPTION) {
                        dmp = new DiagramMainPane (DiagramFrame.this, new StockDiagramDrawer(),
                                new StockDiagramController());
                        if (dmp.loadTable(chooser.getSelectedFile().getAbsolutePath())) {
                            dmp.setName(chooser.getSelectedFile().getName());
                            tabbedPane.add (dmp);
                            tabbedPane.setSelectedComponent (dmp);
                            settings.attach(dmp.getRightPanel());
                        }
                    }
                    setMenuItemsStatus(true);
                    DiagramFrame.this.repaint();
                }
            });
        }
        return openFile;
    }

    /**
     * Метод повертає (за необхідності - створює) пункт меню "Зберегти діаграму".
     * @return saveDiagram пункт меню "Зберегти діаграму".
     */
    private JMenuItem getSaveDiagram () {
        if (saveDiagram == null ) {
            saveDiagram = new JMenuItem ("Save diagram");
            saveDiagram.setEnabled(false);
            saveDiagram.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.ALT_MASK));
            ImageIcon icon = new ImageIcon("images/save-drawing.png");
            saveDiagram.setIcon(icon);
            saveDiagram.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    JFileChooser chooser = new JFileChooser ();
                    chooser.setFileFilter(new UniversalFilter(".jpg"));
                    if (chooser.showSaveDialog(DiagramFrame.this) == JFileChooser.APPROVE_OPTION) {
                        DiagramDrawer drawer = ((DiagramMainPane)tabbedPane.getSelectedComponent()).getRightPanel();
                        Dimension size = drawer.getSize();
                        try {
                            BufferedImage image = new BufferedImage(size.width, size.height,BufferedImage.TYPE_INT_RGB);
                            Graphics2D g2 = image.createGraphics();
                            drawer.paint(g2);
                            String imName = chooser.getSelectedFile().getAbsolutePath();
                            if (!imName.endsWith(".jpg")) {
                                imName+=".jpg";
                            }

                            OutputStream out = new FileOutputStream(imName);
                            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
                            encoder.encode(image);
                            out.close();

                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            });
        }
        return saveDiagram;

    }

    /**
     * Метод повертає (за необхідності - створює) пункт меню "Зберегти файл".
     * @return saveFile пункт меню "Зберегти файл".
     */
    private JMenuItem getSaveFile () {
        if (saveFile == null ) {
            saveFile = new JMenuItem ("Save project");
            saveFile.setEnabled(false);
            saveFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.ALT_MASK));
            ImageIcon icon = new ImageIcon ("images/save-as.png");
            saveFile.setIcon(icon);
            saveFile.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    DiagramMainPane dmp = (DiagramMainPane)tabbedPane.getSelectedComponent();
                    JFileChooser chooser = new JFileChooser ();
                    chooser.setFileFilter(new UniversalFilter(".csv"));
                    if (chooser.showSaveDialog(DiagramFrame.this) == JFileChooser.APPROVE_OPTION) {
                        File file = chooser.getSelectedFile();
                        try {
                            String csvName = file.getAbsolutePath();
                            if (!csvName.endsWith(".csv")) {
                                csvName+=".csv";
                            }
                            CSVProcessor.write(csvName,
                                    dmp.getCSVModel().getColumnNames(), dmp.getCSVModel().getData());
                        }
                        catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        JOptionPane.showMessageDialog(DiagramFrame.this, "Saved succesfully",
                                "", JOptionPane.INFORMATION_MESSAGE);

                    }
                }
            });
        }
        return saveFile;


    }

    /**
     * Метод повертає (за необхідності - створює) пункт меню "Закрити вкладку".
     * @return close Пункт меню "Закрити вкладку".
     */
    private JMenuItem getClose () {
        if (close == null) {
            close = new JMenuItem ("Close");
            close.setEnabled(false);
            close.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.ALT_MASK));
            close.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    settings.deattach(tabbedPane.getSelectedIndex());
                    tabbedPane.remove(tabbedPane.getSelectedComponent());

                    if (tabbedPane.getSelectedComponent()==null)
                        setMenuItemsStatus(false);
                }
            });
        }
        return close;

    }

    /**
     * Метод повертає (за необхідності - створює) пункт меню "Вийти".
     * @return exit пункт меню "Вийти".
     */
    private JMenuItem getExit () {
        if (exit == null) {
            exit = new JMenuItem ("Exit");
            ImageIcon icon = new ImageIcon ("images/exit.png");
            exit.setIcon(icon);
            exit.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            });
        }
        return exit;

    }

    /**
     * Метод повертає (за необхідності - створює) пункт меню "Опції".
     * @return options Пункт меню "Опції".
     */
    private JMenuItem getOptions () {
        if (options == null) {
            options = new JMenuItem ("Options");
            ImageIcon icon = new ImageIcon("images/properties.png");
            options.setIcon(icon);
            options.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
            options.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (settingsDialog == null) {
                        settingsDialog = new ConfigWindow(DiagramFrame.this);
                    }
                    settingsDialog.setVisible(true);


                }
            });
        }
        return options;
    }

    /**
     * Метод задає стиль програмного додатку.
     * @param name Ім'я стилю.
     */
    public void setLNF (String name) {
        if (name.equals("Default")) {
            name = UIManager.getSystemLookAndFeelClassName();
            try {
                UIManager.setLookAndFeel(new GTKLookAndFeel());
            } catch (Exception ex) {
                String msg = new String ("Can't load a design");
                throwError(msg);
            }
            SwingUtilities.updateComponentTreeUI(this);
        }
        else if (name.equals("Metal")) {
            try {
                UIManager.setLookAndFeel(new MetalLookAndFeel());
            }
            catch (Exception ex) {
                String msg = new String ("Can't load a design");
                throwError(msg);
            }
            SwingUtilities.updateComponentTreeUI(this);
        }
        else if (name.equals("Motif")){
            try {
                UIManager.setLookAndFeel(new MotifLookAndFeel());
            }
            catch (Exception ex) {
                String msg = new String ("Can't load a design");
                throwError(msg);
            }
            SwingUtilities.updateComponentTreeUI(this);
                }
    }

    /**
     * Метод виконує запуск додатку.
     * @param args
     */
    public static void main (String[] args) {
        Settings stngs = Settings.getInstance();
//        stngs.initialize();
        final String name = stngs.getProperty("lookAndFeel");
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                DiagramFrame window = new DiagramFrame ();
                window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                window.setLNF(name);

                window.setVisible(true);

            }
        });

    }

    /**
     * Метод виводить віконце з повідомленням про помилку.
     * @param msg Зміст повідомлення помилки.
     */
    private void throwError (String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error has occured",
                                    JOptionPane.ERROR_MESSAGE);

    }
}
