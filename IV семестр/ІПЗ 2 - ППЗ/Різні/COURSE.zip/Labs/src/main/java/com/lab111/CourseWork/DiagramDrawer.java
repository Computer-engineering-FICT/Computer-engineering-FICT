package com.lab111.CourseWork;

import javax.swing.*;
import java.awt.*;

/**
 * Абстрактний клас, котрий є частиною реалізації стратегії по використанню
 * будь-яких побудовників діаграм.
 * @author Сергій Жиденко
 *
 */
public abstract class DiagramDrawer extends JPanel implements ObserverIF{
    private CSVModel csvM;                       // Модель даних
    private Controller csvC;                     // Контролер.

    /**
     * Метод здійснює малювання діаграми.
     * @param g об'єкт, що виконує малювання.
     */
    public abstract void draw (Graphics g);

    /**
     * Метод для встановлення нової моделі даних.
     * @param model Модель даних
     */
    public void setCSVModel (CSVModel model) {
        this.csvM = model;
    }

    /**
     * Метод для встановлення нового контролера.
     * @param csvC Контролер.
     */
    public void setCSVController (Controller csvC) {
        this.csvC = csvC;
    }

    /**
     * Метод повертає модель даних
     * @return csvM Модель даних.
     */
    public CSVModel getCSVModel () {
        return this.csvM;
    }

    /**
     * Метод повертає контролер.
     * @return csvC Контролер.
     */
    public Controller getCSVController() {
        return this.csvC;
    }

    /**
     * Метод здійснює оновлення інформації.
     */
    public abstract void update ();

    /**
     * Метод повертає значення, котре відповідає індексу сфокусованого
     * елемента діаграми.
     * @param x Координата x.
     * @param y Координата y.
     * @return Індекс сфокусованого елемента.
     */
    public abstract int getFocused (int x, int y);

    /**
     * Метод повертає значення, котре відповідає індексу об'єкта, з котрим
     * може відбутись переміна місць. Метод є надлишковим, не обов'язковим
     * для реалізації/застосування, тож повертає значенн-"загляшку" за
     * замовчанням.
     * @param x Координата х.
     * @param y Координата y.
     * @return Індекс елемента, з котрим може відбутись обмін.
     */
    public int getReadyToSwitch (int x, int y){
        return -1;
    }

    /**
     * Метод повертає тип сфокусованого елемента. Метод є надлишковим,
     * не обов'язковим для застосування. В максимальному випадку, коли
     * необхідно розбирати й розділяти окремі складові граф. діаграми,
     * він є дуже важливим і необхідним. За замовчанням повертає значення-
     * "заглушку".
     * @param x Координата x.
     * @param y Координата y.
     * @param ind Індекс елемента.
     * @return Тип елемента.
     */
    public int getActive (int x, int y, int ind) {
        return -1;
    }
}
