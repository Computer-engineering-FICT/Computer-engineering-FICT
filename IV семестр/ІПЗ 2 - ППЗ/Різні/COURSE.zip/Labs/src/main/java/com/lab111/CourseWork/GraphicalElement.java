package com.lab111.CourseWork;

import java.awt.*;

/**
 * Клас представляє графічний елемент, що відображається на діаграмі. Мотивація виділення
 * графічного елементу в окремий клас досить відчутна - елемент "стоковий" є досить складним і потребує
 * розглядання його як окремої структури.
 * @author Сергій Жиденко
 */
public class GraphicalElement {
    private String date;                    // ім'я елементу.
    private int xMax, yMax;                 // Координати максимуму.
    private int xMin, yMin;                 // Координати мінімуму.
    private int xClose, yClose;             // Координати закриття.
    private int zeroX, zeroY;               // Координати початку системи координат
    private int step;                       // крок.
    private Settings settings = Settings.getInstance();

    private int diameter = Integer.parseInt(settings.getProperty("diameter"));
    private int rangeBounds = Integer.parseInt(settings.getProperty("rangeBounds"));

    /**
     * Константа ідентифікує, що сфокусовані всі компоненти елемента.
     */
    public static final int MOVE_ALL = 0;

    /**
     * Константа показує, що можна змінювати максимальне значення біржового елементу.
     */
    public static final int MOVE_MAX = 1;

    /**
     * Константа показує, що можна змінювати мінімальне значення біржового елементу.
     */
    public static final int MOVE_MIN = 2;

    /**
     * Константа показує, що можна змінювати значення стокового елементу на момент закриття.
     */
    public static final int MOVE_CLOSE = 3;

    /**
     * Константа показує, що нічого не сфокусовано.
     */
    public static final int WRONG = -1;

    /**
     * Створює елемент.
     */
    public GraphicalElement () {}

    /**
     * Ініціалізує графічний елемент.
     * @param date ім'я стокового елементу.
     * @param xMax Позиція макс. значення елемента на осі x
     * @param yMax Позиція елемента на осі y
     * @param xMin Позиція мін. значення елемента на осі х
     * @param yMin Позиція мін. значення елемента на осі y
     * @param xClose Позиція значення на момент закриття на осі x
     * @param yClose Позиція значення на момент закриття на осі y
     * @param zeroX Точка х початку координат
     * @param zeroY Точка у початку координат
     * @param step Крок в сітці координатній.
     */
    public void init (String date, int xMax, int yMax, int xMin, int yMin, int xClose, int yClose,
                             int zeroX, int zeroY, int step) {
        setDate(date);
        setxMax(xMax);
        setyMax(yMax);
        setxMin(xMin);
        setyMin(yMin);
        setxClose(xClose);
        setyClose(yClose);
        setZeroX(zeroX);
        setZeroY(zeroY);
        setStep(step);

    }

    /**
     * Метод здійснює малювання даного графічного елемента.
     * @param g
     */
    public void drawElement (Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.drawLine(xMax, yMax, xMin, yMin);
        g2.fillArc(xClose - diameter / 2, yClose - diameter / 2, diameter, diameter, 0, 360);
        g2.drawString (date, xMin, zeroY + 15);
    }

    /**
     * Метод повертає, чи є сфокусований елемент.
     * @param x Координата х
     * @param y Координата у.
     * @return логічне значення.
     */
    public boolean isFocused (int x, int y) {
        if ((x>xMax - rangeBounds && y > yMax - rangeBounds && x < xMin + rangeBounds && y< yMin + rangeBounds) ||
                (x>xMax && x<xMax + step && y> zeroY)) {
            return true;
        }
        return false;

    }

    /**
     * Повертає, чи даний елемент призначений для обміну з іншим.
     * @param x Координата х
     * @param y Координата у
     * @return логічне значення.
     */
    public boolean isForSwitch (int x, int y) {
        if (x>xMin - step/2 && x<xMin + step/2 && y<zeroY) {
            return true;
        }
        return false;
    }

    /**
     * Повертає код тої частини елементу, що є сфокусованою.
     * @param x Координата х
     * @param y Координата у.
     * @return код сфокусованої частини елементу.
     */
    public int status (int x, int y) {
        if ((y>yMax+rangeBounds && y<yClose - rangeBounds) || (y<yMin-diameter/2 && y>yClose+rangeBounds)) {
            return MOVE_ALL;
        }
        else if (y<yMax+rangeBounds)
            return MOVE_MAX;
        else if (y>yMin-rangeBounds && y<=zeroY)
            return MOVE_MIN;
        else if (y>yClose - 2*rangeBounds && y<yClose+2*rangeBounds)
            return MOVE_CLOSE;
        else
            return WRONG;

    }

    /**
     * Повертає ім'я елементу.
     * @return Ім'я елементу
     */
    public String getDate() {
        return date;
    }

    /**
     * Повертає координату макс. по Х
     * @return xMax координата макс. по Х.
     */
    public int getxMax() {
        return xMax;
    }

    /**
     * Повертає координату макс. по у.
     * @return yMax координата макс. по у.
     */
    public int getyMax() {
        return yMax;
    }

    /**
     * Повертає координату мінімума по Х.
     * @return xMin координата мінімума по Х.
     */
    public int getxMin() {
        return xMin;
    }

    /**
     * Повертає координату мін. по У.
     * @return координата мін по У.
     */
    public int getyMin() {
        return yMin;
    }

    /**
     * Повертає координату знаення закриття по Х.
     * @return координата значення закриття по Х.
     */
    public int getxClose() {
        return xClose;
    }

    /**
     * Повертає координату значення закриття по У.
     * @return координата значення закриття по y.
     */
    public int getyClose() {
        return yClose;
    }

    /**
     * Повертає координату початку коорд. сітки по х.
     * @return координата початку координатної сітки по х.
     */
    public int getZeroX() {
        return zeroX;
    }

    /**
     * Повертає координату початку координатної сітки по у.
     * @return координата початку координатної сітки по у.
     */
    public int getZeroY() {
        return zeroY;
    }

    /**
     * Повертає крок сітки.
     * @return крок в сітці.
     */
    public int getStep() {
        return step;
    }

    /**
     * Повертає діаметер показника значення закриття.
     * @return діаметер показника значення закриття.
     */
    public int getDiameter() {
        return diameter;
    }


    /**
     * Встановлює ім'я елемента.
     * @param date ім'я елементу.
     */
    public void setDate (String date) {
        this.date = date;
    }

    /**
     * Встановлює координату макс. по х.
     * @param xMax координата макс. по Х.
     */
    public void setxMax(int xMax) {
        this.xMax = xMax;
    }

    /**
     * Встановлює координату макс. по У.
     * @param yMax координата макс. по У.
     */
    public void setyMax(int yMax) {
        this.yMax = yMax;
    }

    /**
     * Встановлює координату мін. по Х.
     * @param xMin координата мін. по Х.
     */
    public void setxMin(int xMin) {
        this.xMin = xMin;
    }

    /**
     * Встановлює координату мін. по У.
     * @param yMin координата мін по У.
     */
    public void setyMin(int yMin) {
        this.yMin = yMin;
    }

    /**
     * Встановлює координату х значення на момент закриття.
     * @param xClose координата х значення на момент закриття.
     */
    public void setxClose(int xClose) {
        this.xClose = xClose;
    }

    /**
     * Встановлює координату у значення на момент закриття.
     * @param yClose координата у значення на момент закриття.
     */
    public void setyClose(int yClose) {
        this.yClose = yClose;
    }

    /**
     * Встановлює початок координат.
     * @param zeroX початок координат
     */
    public void setZeroX(int zeroX) {
        this.zeroX = zeroX;
    }

    /**
     * Встановлює початок координат (У).
     * @param zeroY початок координат
     */
    public void setZeroY(int zeroY) {
        this.zeroY = zeroY;
    }

    /**
     * Встановлює крок в сітці.
     * @param step крок в сітці.
     */
    public void setStep(int step) {
        this.step = step;
    }

    /**
     * Встановлює діаметер показника значення на момент закриття.
     * @param diameter діаметер показника значення на момент закриття.
     */
    public void setDiameter(int diameter) {
        this.diameter = diameter;
    }

}
