package com.lab111.CourseWork;

import javax.swing.table.AbstractTableModel;

/**
 * Клас представляє модель даних.
 * @author Сергій Жиденко.
 */
public class CSVModel extends AbstractTableModel {

    private String[] columnNames;                        // Імена заголовків таблиці.
    private String[][] data;                             // Основна інформація.

    /**
     * Створює модель даних, ініціалізуючи її заданим масивом з інформацією.
     * @param data Масив з інформацією.
     */
    public CSVModel (String[][] data) {
        this.data = new String[data.length-1][data[0].length];
        columnNames = new String[data[0].length];

        for (int i=1; i<data.length; i++) {
            for (int j=0; j<data[0].length; j++) {
                this.data[i-1][j]=data[i][j];
            }
        }

        for (int i=0; i<data[0].length; i++) {
            columnNames[i]=data[0][i];
        }

    }

    /**
     * Метод повертає кількість колонок у масиві.
     * @return кількість колонок.
     */
    public int getColumnCount () {
        return columnNames.length;
    }

    /**
     * Метод повертає кількість рядків у масиві.
     * @return Кількість рядків.
     */
    public int getRowCount () {
        return data.length;
    }

    /**
     * Метод повертає об'єкт з масиву даних, що містить дана модель.
     * @param row Номер рядка.
     * @param column Номер колонки.
     * @return Об'єкт.
     */
    public Object getValueAt (int row, int column) {
        return data[row][column];
    }

    /**
     * Повертає масив з іменами колонок.
     * @return масив з іменами колонок.
     */
    public String[] getColumnNames () {
        return columnNames;
    }

    /**
     * Повертає назву певної колонки.
     * @param c
     * @return заголовок колонки
     */
    public String getColumnName (int c) {
        return columnNames[c];
    }

    /**
     * Метод повертає масив з інформацією.
     * @return масив з інформацією, що її містить дана модель.
     */
    public String[][] getData () {
        return data;
    }

    /**
     * Метод дає можливість задати значення в певній колонці, в певному рядку таблиці.
     * @param row Рядок в таблиці даних.
     * @param col Колонка в таблиці даних.
     * @param val Значення, яке хочуть занести до таблиці.
     */
    public void setValueAt (int row, int col, double val) {
        data[row][col] = Double.toString(val);

    }

    /**
     * Змінює місцями дані в таблиці.
     * @param focused Індекс першого елементу.
     * @param ind Індекс другого елементу.
     */
    public void switchElements(int focused, int ind) {
        if (focused != GraphicalElement.WRONG) {
            String[] temp = new String[data[0].length];
            for (int i=0; i<data[0].length; i++) {
                temp[i] = data[focused][i];
                data[focused][i] = data[ind][i];
                data[ind][i] = temp[i];
            }
        }
        fireTableDataChanged();
    }

    /**
     * Метод зменшує всі значення в таблиці на вказане число.
     * @param ind Індекс числа в таблиці.
     * @param decrRate Значення, на яке зменшують.
     */
    public void decrease (int ind, double decrRate) {
        for (int i=1; i<data[0].length; i++) {
            data[ind][i] = Double.toString(Double.parseDouble(data[ind][i])-decrRate);
        }
    }

     /**
     * Метод збільшує всі значення в таблиці на вказане число.
     * @param ind Індекс числа в таблиці.
     * @param incrRate Значення, на яке збільшують.
     */
     public void increase (int ind, double incrRate) {
        for (int i=1; i<data[0].length; i++) {
            data[ind][i] = Double.toString(Double.parseDouble(data[ind][i])+incrRate);
        }
    }

    /**
     * Метод додає новий рядок до таблиці даних.
     * @param row Рядок, який додають.
     */
    public void addNewRow (String[] row) {
        String[][] newData = new String[data.length+1][columnNames.length];
        for (int i=0; i<data.length; i++) {
            for (int j=0; j<data[0].length; j++) {
                newData[i][j] = data[i][j];
            }
        }
        for (int i=0; i<columnNames.length; i++) {
            newData[data.length][i] = row[i];
        }
        data = newData;
        fireTableDataChanged();
    }

    /**
     * Метод видаляє останній рядок із таблиці даних.
     */
    public void removeRow () {
        if (data.length!=0) {
        String[][] newData = new String[data.length-1][columnNames.length];
        for (int i=0; i<data.length-1; i++) {
            for (int j=0; j<data[0].length; j++) {
                newData[i][j] = data[i][j];
            }
        }
        data = newData;
        fireTableDataChanged();
        }
    }

}
