package com.lab111.CourseWork;

import java.awt.event.MouseAdapter;

/**
 * Абстрактний клас контролера. Контролер загалом призначений для обробки подій, що виникають
 * при роботі з візуальним представленням. Зміна моделі відбувається не представленням, але
 * через контролер.
 * Даний абстрактний клас призначений для того, щоб створити уніфікований інтерфейс для
 * створення інших класів-контролерів.
 * @author Сергій Жиденко

 */
public abstract class Controller extends MouseAdapter {
    private CSVModel model;                         // Модель.
    private DiagramDrawer drawer;                   // Представлення.

    /**
     * Створює контролер.
     */
    public Controller () {}

    /**
     * Задає візуальне представлення, що "контролюється".
     * @param diagDrw
     */
    public void setDrawer (DiagramDrawer diagDrw) {
        this.drawer = diagDrw;
    }

    /**
     * Встановлює модель для них.
     * @param model
     */
    public void setCsvM (CSVModel model) {
        this.model = model;
    }

    /**
     * Повертає представлення
     * @return drawer візуальне представлення.
     */
    public DiagramDrawer getDrawer () {
        return drawer;
    }

    /**
     * Повертає модель.
     * @return model Модель.
     */
    public CSVModel getCSVM () {
        return model;
    }


}
