package com.lab111.CourseWork;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Клас представляє собою основну панель програми.
 * Містить основні компоненти, котрі розкривають зміст
 * програмного додатку.
 * @author Сергій Жиденко
 */
public class DiagramMainPane extends JPanel {
    private CSVModel model;                   // Модель даних.
    private Controller controller;            // Контролер
    private DiagramFrame frame;               // Головне вікно програмного додатку.
    private JTable table;                     // Таблиця, котра відображає дані.
    private JSplitPane split;                 // Розділювач компонентів.
    private JPanel leftPanel;                 // Ліва частина основної панелі.
    private DiagramDrawer rightPanel;         // Права частина основної панелі.
    private JToolBar toolBar;                 // Панель інструментів.
    private String[][] data;                  // Інформація.
    private Settings settings;                // Налаштування.

    /**
     * Створює основну панель.
     * @param frame Головне вікно програмного додатку.
     * @param rightPanel Права частина (побудовник діаграм) панелі.
     * @param controller Контролер.
     */
    public DiagramMainPane (DiagramFrame frame, DiagramDrawer rightPanel, Controller controller) {
        super();
        settings = Settings.getInstance();
        this.frame = frame;
        this.setLayout(new BorderLayout());
        this.rightPanel = rightPanel;
        this.controller = controller;
    }

    /**
     * Метод виконує ініціалізацію основної панелі.
     */
    public void initialize () {
        getCSVModel();
        getTable();
        getCSVController();
        getLeftPanel();
        getRightPanel();
        getSplitPane();
        add (getSplitPane());

        rightPanel.setCSVModel(getCSVModel());
        rightPanel.setCSVController(getCSVController());

        controller.setCsvM(this.getCSVModel());
        controller.setDrawer(getRightPanel());

        model.addTableModelListener(getTable());
        table.setModel(getCSVModel());

        if (getRightPanel() instanceof StockDiagramDrawer) {
        toolBar = new DiagToolBar (this);
        add(toolBar, BorderLayout.PAGE_START);
        }
    }

    /**
     * Метод повертає розділювач лівої і правої частини панелі.
     * @return
     */
    private JSplitPane getSplitPane () {
        if (split == null) {
            split = new JSplitPane();
            split.setDividerLocation(frame.getContentPane().getWidth()-frame.getContentPane().getWidth()*2/3);
            split.add(getRightPanel(), JSplitPane.RIGHT);
            split.add(getLeftPanel(), JSplitPane.LEFT);
        }
        return split;
    }

    /**
     * Метод повертає діаграму.
     * @return rightPanel Панель діаграми.
     */
    public DiagramDrawer getRightPanel () {
        return rightPanel;
    }

    /**
     * Метод повертає (за необхідності - створює) таблицю даних.
     * @return table Таблиця, що відображає інформацію.
     */
    public JTable getTable () {
        if (table == null) {
            table = new JTable ();
        }
        return table;
    }

    /**
     * Метод повертає модель.
     * @return model модель даних.
     */
    public CSVModel getCSVModel () {
        if (model == null) {
            model = new CSVModel(data);
        }
        return model;
    }

    /**
     * Метод повертає контроллер.
     * @return controller контроллер.
     */
    public Controller getCSVController () {
        return controller;
    }

    /**
     * Ліва частина основної панелі, містить таблицю.
     * @return leftPanel Ліва частина основної панелі.
     */
    public JPanel getLeftPanel () {
        if (leftPanel == null) {
            leftPanel = new JPanel(new BorderLayout());
            JScrollPane scrollTbl = new JScrollPane (getTable(), ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            leftPanel.add (scrollTbl);


        }
        return leftPanel;
    }

    /**
     * Повертає головне вікно програмного додатку.
     * @return frame головне вікно додатку.
     */
    public DiagramFrame getFrame () {
        return frame;
    }

    /**
     * Метод здійснює завантаження (відкриття або створення) файлу для роботи з діаграмами.
     * @param fileName ім'я файлу, з котрого читають.
     * @return логічне значення.
     */
    public boolean loadTable (String fileName) {
        if (fileName == null) {
            ArrayList<String> list = new ArrayList<String>();
            list.add (settings.getProperty("defaultHeader"));
            list.add(settings.getProperty("defaultString"));
            fileName = settings.getProperty("defaultFilename");
            File tempFile = new File(fileName);
            try {
                CSVProcessor.write(tempFile, list);
            }
            catch (IOException ex) {
                ErrorSender.throwError("Unsuccesful. Try one more time.");
                return false;
            }
        }
        try {
            final ArrayList<String> list = CSVProcessor.read(fileName);
            Runnable run = new Runnable() {
                public void run() {
                    try {
                        data = CSVProcessor.parseData(list);
                    } catch (CSVParseException e) {
                        ErrorSender.throwError("Error while parsing file. Try parsing one" +
                                "more time.");
                        CSVProcessor.changeExitCode();

                    } catch (Exception e) {
                        ErrorSender.throwError("Unexpected error. Try one more time.");
                        CSVProcessor.changeExitCode();
                    }

                }
            };
            Thread t = new Thread(run);
            t.start();
            try {
                t.join();
            } catch (InterruptedException e) {
                ErrorSender.throwError("Unexpected error. Try one more time.");
                CSVProcessor.changeExitCode();
            }

            if (CSVProcessor.getExitCode()==0) {
                this.initialize();
                return true;
            }
            return false;
        } catch (IOException ex) {
            ErrorSender.throwError("Unexpected error. Try one more time");
        }
        return false;
    }

}
