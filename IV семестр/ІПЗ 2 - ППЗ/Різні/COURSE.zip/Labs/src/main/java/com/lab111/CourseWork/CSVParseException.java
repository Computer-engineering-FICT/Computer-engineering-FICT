package com.lab111.CourseWork;

/**
 * Клас представляє собою виключення, котре виникає при помилці під час парсингу даних.
 * @author Сергій Жиденко
 */
public class CSVParseException extends Exception {
    /**
     * Створює стандартне виключення.
     */
    public CSVParseException () {
        super ();
    }

    /**
     * Створює виключення з повідомленням про помилку.
     * @param message
     */
    public CSVParseException(String message) {
        super(message);
    }

}
