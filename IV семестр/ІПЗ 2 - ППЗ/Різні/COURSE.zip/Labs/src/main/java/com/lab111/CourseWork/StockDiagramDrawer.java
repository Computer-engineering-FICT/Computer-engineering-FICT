package com.lab111.CourseWork;

import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import java.awt.*;
import java.util.ArrayList;

/**
 * Клас представляє собою конкретний тип діаграми. А саме - діаграми біржової.
 * Здійснює представлення даних моделі у вигляді діаграми заданого типу.
 *
 * @author Сергій Жиденко
 *
 */
public class StockDiagramDrawer extends DiagramDrawer implements TableModelListener {

    private int maxY;                       // Максимальне значення в пікселях по У.
    private int zeroX;                      // Координата початку коорд. сітки по Х.

    private int horizontalIndent;           // Відступ зліва до координатної сітки.
    private int verticalIndent;             // Відступ згори до координатної сітки.
    private double maxValue;                // Максимальне значення відносне по ОУ.

    private String[][] table;               // Таблиця даних.
    private ArrayList<GraphicalElement> ge; // Масив графічних елементів.

    private double gridVal;                 // Значення сітки.
    private Color elements, grid;           // Колір сітки та граф. елементів.
    private int number;                     // Кількість графічних елементів.
    private Settings set;                   // Налаштування.


    /**
     * Створює панель діаграми з певними початковими значеннями, але без заданої моделі даних.
     */
    public StockDiagramDrawer() {
        super();
        set = Settings.getInstance();
        this.setGrid (Double.parseDouble(set.getProperty("gridValue")));
        horizontalIndent = Integer.parseInt(set.getProperty("horizontalIndent"));
        verticalIndent = Integer.parseInt(set.getProperty("verticalIndent"));
        setGridColor(set.getProperty("gridColor"));
        setElementColor(set.getProperty("elementColor"));

        this.maxY=verticalIndent;
        this.zeroX=horizontalIndent;
    }

    /**
     * Метод будує діаграму.
     * @param g об'єкт, що виконує малювання.
     */
    public void draw(Graphics g) {

        g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,9));
        drawXOY(g);
        if (table.length!=0) {
        g.setColor(elements);
        String[][] tempData = getCSVModel().getData();
        double[][] changedData = convertToDoubleTable(tempData);
        for (int i=0; i<number; i++) {
            ge.get(i).init(
                tempData[i][0],
                getStep()*(i+1)+horizontalIndent,
                getZeroY()-(int)(changedData[i][0]* convOYToRel()),
                getStep()*(i+1)+horizontalIndent,
                getZeroY()-(int)(changedData[i][2]* convOYToRel()),
                getStep()*(i+1)+horizontalIndent,
                getZeroY()-(int)(changedData[i][1]* convOYToRel()),
                getZeroX(),
                getZeroY(),
                getStep()
            );
            ge.get(i).drawElement(g);

        }
        }
    }

    /**
     * Метод малює координатну сітку.
     * @param g об'єкт, що здійснює малювання.
     */
    private void drawXOY (Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.getColor("BLACK"));
        // Building an XOY-axis:
        g2.drawLine(getMaxX()-13 ,getZeroY() - 5, getMaxX(), getZeroY()); // "+50" to make X-axis long enough to place arrow
		g2.drawLine(getMaxX()-13 ,getZeroY() + 5, getMaxX(), getZeroY()); // "+5", "-5" defines length of arrow
		g2.drawLine(getZeroX() - 5,getMaxY()+ 13, getZeroX(),getMaxY());  // "-25" to make Y
		g2.drawLine(getZeroX() + 5,getMaxY()+ 13, getZeroX(),getMaxY());
		g2.drawLine(getZeroX(),getZeroY(),getMaxX(),getZeroY());             // Building an X-axis
		g2.drawLine(getZeroX(),getZeroY(),getZeroX(),getMaxY());             // Building a Y-axis

        int number = 0;
        int temp;

        if (getGrid()!=0 && table.length!=0) {
            double numDoub = getMaxOY()/getGrid();
            number = (int)numDoub;
            if (numDoub-number>0.1)
                number++;
            if (number == 0 && getMaxOY() > getGrid())
                number = 1;
        }

        g2.drawString ("0", getZeroX()-horizontalIndent, getZeroY());
        for (int i=1; i<= number; i++) {
            temp = (int) (getZeroY()-i* convOYToRel()*getGrid());

            System.out.println("convOYToRel "+ convOYToRel());
            g2.drawString(""+i*getGrid(), getZeroX() - horizontalIndent, temp);
            g2.setColor(grid);
            g2.drawLine(getZeroX(), temp, getMaxX(), temp);
        }
    }


    /**
     * Метод, котрий викликається автоматично для перемалювання діаграми.
     * @param g
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    /**
     * Переведення з піксельного значення у відносне.
     * @return відносне значення
     */
    public double convOYToRel() {
        return (getZeroY()-getMaxY())/getMaxOY();
    }

    /**
     * Повертає в пікселях кінець координатної вісі х.
     * @return значення кінця координатної осі х.
     */
    private int getMaxX() {
        return (getWidth()-3*horizontalIndent);
    }

    /**
     * Повертає в пікселях максимальне значення по коорд. осі У.
     * @return макс. значення по координатній осі У.
     */
    public int getMaxY(){
		return maxY;
	}

    /**
     * Повертає значення початку координатної осі Х.
     * @return значення початку координатної осі Х.
     */
	public int getZeroX(){
		return zeroX;
	}

    /**
     * Повертає значення початку координатної осі У.
     * @return значення початку координатної осі у.
     */
	public int getZeroY(){
		return (getHeight() - verticalIndent);
	}

    /**
     * Повертає "крок" до наступного елемента.
     * @return
     */
	private int getStep(){
		return (int)(getMaxX()/(getCSVModel().getData().length+1));
	}

    /**
     * Повертає максимальне значення по осі Оу у ВІДНОСНИХ одиницях.
     * @return максимальне значення по осі Oy.
     */
    public double getMaxOY () {
        double[][] myTable = convertToDoubleTable(getCSVModel().getData());
        double temp = findMaxValue(myTable);
        if (maxValue < temp)
            return temp;
        return maxValue;
    }

    /**
     * Повертає значення сітки.
     * @return значення сітки.
     */
    public double getGrid () {
        return gridVal;
    }

    /**
     * Встановлює значення сітки.
     * @param gridVal значення сітки.
     */
    public void setGrid (double gridVal) {
        this.gridVal = gridVal ;
    }

    /**
     * Встановлює модель даних.
     * @param csvM модель даних.
     */
    public void setCSVModel (CSVModel csvM) {
        super.setCSVModel(csvM);
        getCSVModel().addTableModelListener(this);
        update ();
    }

    /**
     * Оновлює інформацію про діаграму.
     */
    public void update () {
        table = getCSVModel().getData();
        double[][] changedToDoubleTable = convertToDoubleTable(table);
        this.maxValue=findMaxValue(changedToDoubleTable);
        ge = new ArrayList<GraphicalElement>();
        for (int i=0; i<table.length; i++) {
            ge.add (new GraphicalElement());
        }
        number = ge.size();

    }

    /**
     * Встановлює контролер.
     * @param csvC Контролер.
     */
    public void setCSVController (Controller csvC) {
        super.setCSVController(csvC);
        this.addMouseListener(getCSVController());
        this.addMouseMotionListener(getCSVController());
    }

    /**
     * Оброблює зміну діаграми при зміні моделі.
     * @param e подія зміни таблиці.
     */
    public void tableChanged (TableModelEvent e) {
        table = getCSVModel().getData();


        ge = new ArrayList<GraphicalElement>();
        for (int i=0; i<getCSVModel().getData().length; i++) {
            ge.add(new GraphicalElement());
        }

        setNumber();

        this.repaint();
    }

    /**
     * Встановлює кількість графічних елементів.
     */
    public void setNumber () {
        this.number = getCSVModel().getData().length;
    }

    /**
     * Метод здійснює пошук максимального значення.
     * @param table таблиця, по якій відбувається пошук.
     * @return максимальне значення.
     */
    public double findMaxValue (double[][] table) {
        double max = 0;
        for (int i=0; i<table.length; i++) {
            for (int j=0; j<table[0].length; j++) {
                if (max<table[i][j])
                    max=table[i][j];
            }
        }
        return max;
    }

    /**
     * Задає максимальне значення.
     * @param maxValue максимальне значення.
     */
    public void setMaxValue (double maxValue) {
        this.maxValue = maxValue;
    }

    /**
     * Повертає індекс сфокусованого елемента.
     * @param x Координата x.
     * @param y Координата y.
     * @return індекс сфокусованого елемента.
     */
    public int getFocused (int x, int y) {
        int focusedIndex = GraphicalElement.WRONG;
        for (int i=0; i<getNumber(); i++) {
            if (ge.get(i).isFocused(x,y)) {
                focusedIndex = i;
                return focusedIndex;
            }
        }
        return focusedIndex;
    }

    /**
     * Повертає індекс елемента, з яким може відбутись обмін.
     * @param x Координата х.
     * @param y Координата y.
     * @return індекс готового до обміну елемента.
     */
    public int getReadyToSwitch (int x, int y) {
        int focusedSwitch = GraphicalElement.WRONG;
        for (int i=0; i<getNumber(); i++) {
            if (ge.get(i).isForSwitch(x,y)) {
                focusedSwitch = i;
                return focusedSwitch;
            }
        }
        return focusedSwitch;

    }

    /**
     * Повертає тип активного елемента.
     * @param x Координата x.
     * @param y Координата y.
     * @param ind Індекс елемента.
     * @return тип активного елемента.
     */
    public int getActive (int x, int y, int ind) {
        return ge.get(ind).status(x,y);
    }

    /**
     * Повертає кількість графічних елементів.
     * @return кількість графічних елементів.
     */
    public int getNumber () {
        return number;
    }

    /**
     * Здійснює конвертацію таблиці з рядків у таблицю з дійсних чисел.
     * @param table таблиця, яку необхідно конвертувати.
     * @return сконвертована таблиця.
     */
    public double[][] convertToDoubleTable(String[][] table) {
		int maxRow = table.length;
        int maxCol = table[0].length-1;
        int ind = 0;
		double max = 0;
		double[][] myDoubleTable = new double[maxRow][maxCol];
		for (int i = 0; i < maxRow; i++) {
			for (int j = 0; j < maxCol; j++) {
				if ((ind = table[i][j+1].indexOf('.')) == -1) {
					myDoubleTable[i][j] = Double.parseDouble(table[i][j+1]);
				} else
					myDoubleTable[i][j] = Double.parseDouble(table[i][j + 1].substring(0, ind)
									+ '.'
									+ table[i][j + 1].substring(ind + 1));

			}
		}

		return myDoubleTable;
	}

    /**
     * Встановлює колір сітки.
     * @param color колір сітки.
     */
    public void setGridColor (String color) {
        this.grid = Color.decode(color);
    }

    /**
     * Встановлює колір елементів.
     * @param color колір елементів.
     */
    public void setElementColor (String color) {
        this.elements = Color.decode(color);
    }

    /**
     * Оновлює інформацію про кольори сітки та елементів.
     */
    public void updateInfo () {
        setGridColor(set.getProperty("gridColor"));
        setElementColor(set.getProperty("elementColor"));
        this.repaint();
    }





}
