/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

/**
 *
 * @author diuk
 */
public class Sumator {
    public static byte add(RegisterSet in1, RegisterSet in2, RegisterSet out, byte CI)
            throws UncompatibleSizeException{
        if((in1.getSize()!=in2.getSize())||(in1.getSize()!=out.getSize()))
            throw new UncompatibleSizeException();
        byte [] ain1 = in1.getArray();
        byte [] ain2 = in2.getArray();
        int size = out.getSize();
        byte [] aout = new byte[size];

        byte c = CI;
        for (int i = size-1; i >= 0; i--) {
            byte a = (byte)(ain1[i]+ain2[i]+c);
            aout[i] = (byte)(a%2);
            c = (byte)(a/2);
        }
        out.setArray(aout);
        return c;
    }

    public static byte add(Register in1, Register in2, Register out, byte CI)
            throws UncompatibleSizeException{
        return add(new RegisterSet(in1), new RegisterSet(in2), new RegisterSet(out), CI);
    }
}
