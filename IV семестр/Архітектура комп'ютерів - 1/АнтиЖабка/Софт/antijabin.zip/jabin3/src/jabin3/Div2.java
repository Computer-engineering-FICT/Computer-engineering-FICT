/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

import java.io.*;

/**
 *
 * @author diuk
 */
public class Div2{
    public static void mul(Register rg3, Register rg2, Register rg1)
            throws UncompatibleSizeException, Exception{
        PrintStream pw = new PrintStream(new FileOutputStream("div2.html"));
        pw.println("<htlm><body<table border=\"1\" cellspacing=\"0\" width=\"70%\" bordercolor=\"green\">");
        pw.println("<tr><td>"+rg3+"</td><td>"+rg2+"</td><td>"+rg1+"</td></tr>");
        while(rg3.getHigher()!=1){
             pw.println("<tr><td>"+rg3+"</td><td>"+rg2+"<br>");
            if (rg2.getHigher()==0){
                rg1.changeCode();
                rg3.shl(Sumator.add(rg1, rg2, rg2, (byte)0));
                pw.println(rg1+"<hr>");
                rg1.changeCode();
            } else{
                rg3.shl(Sumator.add(rg1, rg2, rg2, (byte)0));
                pw.println(rg1+"<hr>");
            }
             rg1.shr();
             pw.println(rg2+"</td><td>"+rg1+"</td></tr>");
        }
        pw.println("</table></body></html>");
        pw.close();
    }
}
