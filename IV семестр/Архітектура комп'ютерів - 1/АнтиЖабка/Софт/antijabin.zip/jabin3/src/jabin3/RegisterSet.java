/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

import java.util.Arrays;

/**
 *
 * @author diuk
 */
public class RegisterSet {
    private Register[] regs;
    private int size;

    public RegisterSet(Register ... args){
        regs = args;
        size = 0;
        for(Register r : regs){
            size += r.getArray().length;
        }
    }

    public int getSize(){
        return size;
    }

    public byte[] getArray(){
        int ind =0;
        byte[] b;
        byte [] out;
        out = new byte[size];
        ind = 0;
        for (Register r : regs){
            b = r.getArray();
            System.arraycopy(b, 0, out, ind, b.length);
            ind += b.length;
        }
        return out;
    }

    public void setArray(byte [] arr) throws UncompatibleSizeException{
        if (arr.length!=size)
            throw new UncompatibleSizeException();
        int ind = 0;
        for (Register r: regs){
            r.setArray(Arrays.copyOfRange(arr, ind, ind+r.getSize()));
            ind += r.getSize();
        }
    }

    public void shl(){
        byte c = 0;
        for(int i=regs.length-1; i>=0; i--){
            c = regs[i].shl(c);
        }
    }

    public void shr(){
        byte c = 0;
        for(int i=0; i<regs.length; i++){
            c = regs[i].shr(c);
        }
    }

    @Override
    public String toString(){
        String s="";
        for (int i = 0; i < regs.length; i++) {
            s+=regs[i].toString();
        }
        return s;
    }
}
