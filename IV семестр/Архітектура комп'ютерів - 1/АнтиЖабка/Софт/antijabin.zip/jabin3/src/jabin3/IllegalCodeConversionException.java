/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

/**
 *
 * @author diuk
 */
public class IllegalCodeConversionException extends Exception {
    public IllegalCodeConversionException(){
        super();
    }

    public IllegalCodeConversionException(String msg){
        super(msg);
    }
}
