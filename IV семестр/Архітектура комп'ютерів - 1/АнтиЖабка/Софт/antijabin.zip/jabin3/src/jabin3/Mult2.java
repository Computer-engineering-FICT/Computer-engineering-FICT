/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

import java.io.*;

/**
 *
 * @author diuk
 */
public class Mult2{
    public static void mul(Register rg3, Register rg2, Register rg1)
            throws UncompatibleSizeException, Exception{
        PrintStream pw = new PrintStream(new FileOutputStream("mult2.html"));
        pw.println("<htlm><body<table border=\"1\" cellspacing=\"0\" width=\"70%\" bordercolor=\"green\">");
        pw.println("<tr><td>"+rg1+"</td><td>"+rg2+"</td><td>"+rg3+"</td></tr>");
        for (int ct = rg2.getSize(); ct>0; ct--){
        pw.println("<tr>");
        pw.println("<td>"+rg1+"<br>");
            if (rg2.getLower()==1){
                Sumator.add(rg3, rg1, rg1, (byte)0);
                pw.println(rg3+"<br><hr>");
                pw.println(rg1+"</td>");
            }
            rg2.shr();
            rg3.shl();
            pw.println("<td>"+rg2+"</td>");
            pw.println("<td>"+rg3+"</td>");
            pw.println("</tr>");
        }
        pw.println("</table></body></html>");
        pw.close();
    }
}
