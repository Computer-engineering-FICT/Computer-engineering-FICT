/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

/**
 *
 * @author diuk
 */
public class UncompatibleSizeException extends Exception {
    public UncompatibleSizeException(){
        super();
    }

    public UncompatibleSizeException(String msg){
        super(msg);
    }
}
