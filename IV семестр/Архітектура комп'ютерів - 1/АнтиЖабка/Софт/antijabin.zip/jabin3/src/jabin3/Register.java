/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

import java.util.Arrays;

/**
 *
 * @author diuk
 */
public class Register {
    private byte [] elements;
    private boolean dk;

    public Register(String s){
        dk=false;
        elements = new byte[s.length()];
        for (int i = 0; i < elements.length; i++) {
            if (s.charAt(i)=='1')
                elements[i] = 1;
            else
                elements[i] = 0;
        }
    }

    public Register(int i){
        dk=false;
        elements = new byte[i];
        Arrays.fill(elements, (byte)0);
    }

    public Register(byte[] ... arrs){
        dk=false;
        int size =0;
        for(byte []b : arrs){
            size += b.length;
        }
        elements = new byte[size];
        size = 0;
        for (byte []b : arrs){
            System.arraycopy(b, 0, elements, size, b.length);
            size += b.length;
        }
    }

    public Register(Register ... arrs){
        dk=false;
        int size =0;
        byte[] b;
        for(Register r : arrs){
            b = r.getArray();
            size += b.length;
        }
        elements = new byte[size];
        size = 0;
        for (Register r : arrs){
            b = r.getArray();
            System.arraycopy(b, 0, elements, size, b.length);
            size += b.length;
        }
    }

    public byte shl(byte CI){
        byte CO = elements[0];
        System.arraycopy(elements, 1, elements, 0, elements.length-1);
        elements[elements.length-1]=CI;
        return CO;
    }

    public byte shr(byte CI){
        byte CO = elements[elements.length-1];
        System.arraycopy(elements, 0, elements, 1, elements.length-1);
        elements[0]=CI;
        return CO;
    }

    public void shl(){
        shl((byte)(dk?1:0));
    }

    public void shr(){
        shr((byte)(dk?1:0));
    }

    public void setArray(byte [] arr){
        elements = arr;
    }

    public byte getBitAt(int ind){
        return elements[ind];
    }

    public void setBitAt(int ind, byte b){
        elements[ind] = b;
    }

    public byte[] getArray(){
        return Arrays.copyOf(elements, elements.length);
    }

    public int getSize(){
        return elements.length;
    }

    public byte getLower(){
        return elements[elements.length-1];
    }

   public byte getHigher(){
       return elements[0];
   }

   public void changeCode() throws IllegalCodeConversionException{
       dk = !dk;
       boolean was = false;
       for(int i=elements.length-1; i>=0; i--){
           if(elements[i]==1){
               if(!was)
                   was = true;
                else
                   elements[i]=0;
           } else{
               if(was)
                   elements[i]=1;
           }
       }
   }



    @Override
    public String toString(){
        String s = "";
        for (int i = 0; i < elements.length; i++) {
            s+=elements[i];
        }
        return s;
    }
}
