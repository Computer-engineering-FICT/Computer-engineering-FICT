/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

/**0010010001000110100000000000000
 *
 * @author diuk
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        divide1();
        divide2();
    }

    public static void divide1() throws Exception{
        Register r1 = new Register("00101000010000001");
        Register r2 = new Register("00100100010001101");
        Register r3 = new Register("0000000000000000");
        Div1.mul(r3, r2, r1);
        System.out.println(r3);
    }

    public static void divide2() throws Exception{
        Register r1 = new Register("0010100001000000100000000000000");
        Register r2 = new Register("0010010001000110100000000000000");
        Register r3 = new Register("0000000000000000");
        Div2.mul(r3, r2, r1);
        System.out.println(r3);
    }

}
