/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jabin3;

import java.io.*;

/**
 *
 * @author diuk
 */
public class Mult3{
    public static void mul(Register rg3, Register rg2, Register rg1)
            throws UncompatibleSizeException, Exception{
        PrintStream pw = new PrintStream(new FileOutputStream("mult3.html"));
        pw.println("<htlm><body<table border=\"1\" cellspacing=\"0\" width=\"70%\" bordercolor=\"green\">");
        pw.println("<tr><td>"+rg2+"</td><td>"+rg1+"</td><td>"+rg3+"</td></tr>");
        RegisterSet r2r1 = new RegisterSet(rg2, rg1);
        Register zero = new Register(rg2.getSize());
        RegisterSet rs3 = new RegisterSet(zero, rg3);
        for (int i = rg2.getSize(); i>0; i--){        
            if(rg2.getHigher()==1){
                pw.println("<tr>");
                pw.println("<td>"+rg2+"</td><td>"+rg1+"<br>");
                Sumator.add(r2r1, rs3, r2r1, (byte)0);               
                pw.println(rg3+"<hr>"+rg1+"</td>");
                pw.println("<td>"+rg3+"</td>"+"</tr>");
            }
            r2r1.shl();
            pw.println("<tr><td>"+rg2+"</td><td>"+rg1+"</td><td>"+rg3+"</td></tr>");
        }
        pw.println("</table></body></html>");
        pw.close();
    }
}
